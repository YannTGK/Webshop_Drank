-- MySQL dump 10.13  Distrib 8.0.33, for Linux (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	8.0.33-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` int NOT NULL,
  `ownerId` int DEFAULT NULL,
  `countryCode` varchar(255) NOT NULL,
  `administrativeArea` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `organizationTaxId` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_miqmzjzwlejnqqdxdavcheqxqzwlmvrczhfz` (`ownerId`),
  CONSTRAINT `fk_jdhbxcdizwfyeivddbdcqsjaquseukqspirm` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_miqmzjzwlejnqqdxdavcheqxqzwlmvrczhfz` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `pluginId` int DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT '1',
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_gxjhccvhtcqrbkmvilhidrikkmdmppstrioo` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_ehmwxzsbbxikekfhibynogjzoksojddgnqgg` (`dateRead`),
  KEY `fk_vbkkrbsbojhiizkckwltfhxjjwyrtvlereyh` (`pluginId`),
  CONSTRAINT `fk_vbkkrbsbojhiizkckwltfhxjjwyrtvlereyh` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vpjedqeyiyywdrsjfozppbtfiylezyrvcjiv` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexdata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sessionId` int NOT NULL,
  `volumeId` int NOT NULL,
  `uri` text,
  `size` bigint unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT '0',
  `recordId` int DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT '0',
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_dpjiwmruqcvlvjmsnmwvwqdvsujxczohavkj` (`sessionId`,`volumeId`),
  KEY `idx_rrywiurlslisotqqjcgoblfuvygshplxepyy` (`volumeId`),
  CONSTRAINT `fk_kytmiujejzrgvabwndaldvskrxnrgwpwsawl` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lchlwdlalcumlatgebdgievdnfektpybhtsg` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexdata`
--

LOCK TABLES `assetindexdata` WRITE;
/*!40000 ALTER TABLE `assetindexdata` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexingsessions`
--

DROP TABLE IF EXISTS `assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexingsessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text,
  `totalEntries` int DEFAULT NULL,
  `processedEntries` int NOT NULL DEFAULT '0',
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `listEmptyFolders` tinyint(1) DEFAULT '0',
  `isCli` tinyint(1) DEFAULT '0',
  `actionRequired` tinyint(1) DEFAULT '0',
  `processIfRootEmpty` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexingsessions`
--

LOCK TABLES `assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `assetindexingsessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets` (
  `id` int NOT NULL,
  `volumeId` int DEFAULT NULL,
  `folderId` int NOT NULL,
  `uploaderId` int DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `alt` text,
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `size` bigint unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_yayjirytlphpkyrbcznklegpofbrxcqvhmxu` (`filename`,`folderId`),
  KEY `idx_agsfmiedbyhiygwzwhswpekmcogeyztnesbi` (`folderId`),
  KEY `idx_efuahpjjialcrmzhjefofpkdwgovudefhxxx` (`volumeId`),
  KEY `fk_xqgnwfdtvbkfianwxoraiipallantnjumygd` (`uploaderId`),
  CONSTRAINT `fk_gushlcgghxxwwnugzneezypjtgvbcghwaeuw` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_koxwyafocrfoausbsqxkcltxmoclcuazoacz` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ovjmhmzaovyuexlsvourujexqwvwlxcrfkjy` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xqgnwfdtvbkfianwxoraiipallantnjumygd` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
INSERT INTO `assets` VALUES (143,2,2,1,'Coca-Cola.jpg','image',NULL,379,1181,94058,NULL,NULL,NULL,'2024-01-05 23:21:27','2024-01-05 23:21:27','2024-01-05 23:21:38'),(169,2,2,1,'absolut_vodka.webp','image',NULL,210,663,13314,NULL,NULL,NULL,'2024-01-06 00:05:19','2024-01-06 00:05:19','2024-01-06 00:05:22'),(170,2,2,1,'Fanta_bb.jpg','image',NULL,714,1344,67297,NULL,NULL,NULL,'2024-01-06 00:05:33','2024-01-06 00:05:33','2024-01-06 00:05:36'),(171,2,2,1,'jack_daniels.webp','image',NULL,210,663,22084,NULL,NULL,NULL,'2024-01-06 00:05:41','2024-01-06 00:05:41','2024-01-06 00:05:44'),(172,2,2,1,'The_famous_grouse.webp','image',NULL,178,682,17382,NULL,NULL,NULL,'2024-01-06 00:05:50','2024-01-06 00:05:50','2024-01-06 00:05:54'),(173,2,2,1,'smirnof_vodka.webp','image',NULL,182,682,20384,NULL,NULL,NULL,'2024-01-06 00:06:10','2024-01-06 00:06:10','2024-01-06 00:06:14'),(185,3,5,1,'About_frontpage.jpg','image',NULL,3640,5096,4073881,NULL,NULL,NULL,'2024-01-06 00:17:50','2024-01-06 00:17:50','2024-01-06 00:18:05'),(186,3,5,1,'apperitief.png','image',NULL,1093,1635,3466063,NULL,NULL,NULL,'2024-01-06 00:17:52','2024-01-06 00:17:52','2024-01-06 00:18:05'),(187,3,5,1,'assortiment.jpg','image',NULL,4127,6190,4916728,NULL,NULL,NULL,'2024-01-06 00:17:54','2024-01-06 00:17:54','2024-01-06 00:18:05'),(188,3,5,1,'Bottle_Jack.jpg','image',NULL,3456,5184,5239291,NULL,NULL,NULL,'2024-01-06 00:17:57','2024-01-06 00:17:57','2024-01-06 00:18:05'),(189,3,5,1,'Drinking_orange.jpg','image',NULL,4160,6240,2711346,NULL,NULL,NULL,'2024-01-06 00:17:58','2024-01-06 00:17:59','2024-01-06 00:18:05'),(190,3,5,1,'TVGD_logo.png','image',NULL,1051,400,95187,NULL,NULL,NULL,'2024-01-06 00:17:59','2024-01-06 00:17:59','2024-01-06 00:18:05'),(191,4,6,1,'led_us_her.avif','image',NULL,2069,1381,827864,NULL,0,0,'2024-01-06 00:20:40','2024-01-06 00:20:40','2024-01-06 00:21:15'),(192,4,6,1,'ons_verhaal.jpg','image',NULL,2624,3936,1980868,NULL,NULL,NULL,'2024-01-06 00:20:41','2024-01-06 00:20:41','2024-01-06 00:21:16'),(193,4,6,1,'vereniging.avif','image',NULL,2070,1380,601176,NULL,NULL,NULL,'2024-01-06 00:21:08','2024-01-06 00:21:08','2024-01-06 00:21:16'),(194,4,6,1,'About_frontpage.jpg','image',NULL,3640,5096,4073588,NULL,NULL,NULL,'2024-01-06 00:21:45','2024-01-06 00:21:45','2024-01-06 00:21:48'),(199,4,6,1,'passion_led_us_here.jpg','image',NULL,2500,1669,937292,NULL,NULL,NULL,'2024-01-10 20:49:53','2024-01-10 20:49:53','2024-01-10 20:49:53'),(200,4,6,1,'ons_vereniging.jpg','image',NULL,1200,800,134316,NULL,NULL,NULL,'2024-01-10 20:50:20','2024-01-10 20:50:20','2024-01-10 20:50:20');
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_iogyljgsbirdgjfsfeksovnzrcqredyegoml` (`groupId`),
  KEY `fk_zjggpadbuoffelhansggcyzpfjesvcwvmalh` (`parentId`),
  CONSTRAINT `fk_bysxhxkukaxivjxpimvfxotcnrrpnandxevm` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tynreryronhojdkhuatpgpunoqmdoakapqjz` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zjggpadbuoffelhansggcyzpfjesvcwvmalh` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_psanjiydemgdguchdzltyyhycqacrgrbevtr` (`name`),
  KEY `idx_zepwiafopduxcxmrckdkplzflbauqtfnbxih` (`handle`),
  KEY `idx_ffgdpgigpwhsfvufrderctaaxrnsjdfwywli` (`structureId`),
  KEY `idx_tkcamuplrhnmwcyyunoeubuxrcrdznnojcgi` (`fieldLayoutId`),
  KEY `idx_tznjqxeqpyngfqnecfatczimudtdnznartta` (`dateDeleted`),
  CONSTRAINT `fk_uxkrfghamodyxvwwqikyhnfnoesrbfitpygt` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_yjxccrfeyrgjbdhuhngamlwdwcascgmuxetn` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_rmddlhviskczamlsbpbqjyylbmydmgybkher` (`groupId`,`siteId`),
  KEY `idx_kuregjkrnjosurdcvgcyuhdgyylcirojvhyf` (`siteId`),
  CONSTRAINT `fk_fpnlbqepevyyeqqboovhgqpqgnqiimgcrtxx` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ykodqudsesgexhzigjhttjacejwdzphmqzhm` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedattributes` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_qgkmciefhdkvyukzuatqszsmultepqupvmcn` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_kncpqojvxwogvaoxfuvfumlnvndbcyjngyxf` (`siteId`),
  KEY `fk_vsafnhjdvrevtjtapibyhvkfmlguzqddfhgc` (`userId`),
  CONSTRAINT `fk_kexelngnfjkqyzxmufqijexqdqayewpoabag` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_kncpqojvxwogvaoxfuvfumlnvndbcyjngyxf` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_vsafnhjdvrevtjtapibyhvkfmlguzqddfhgc` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
INSERT INTO `changedattributes` VALUES (3,1,'authorId','2024-01-05 17:07:36',0,1),(3,1,'uri','2024-01-05 17:09:15',0,1),(16,1,'enabled','2024-01-05 18:44:43',0,1),(16,1,'uri','2024-01-05 22:38:35',0,1),(92,1,'fieldLayoutId','2024-01-11 16:57:59',0,1),(92,1,'postDate','2024-01-05 21:48:48',0,1),(92,1,'slug','2024-01-05 21:46:09',0,1),(92,1,'title','2024-01-05 21:46:09',0,1),(92,1,'typeId','2024-01-11 16:57:59',0,1),(92,1,'uri','2024-01-05 21:46:09',0,1),(94,1,'fieldLayoutId','2024-01-11 16:57:38',0,1),(94,1,'postDate','2024-01-05 21:49:16',0,1),(94,1,'slug','2024-01-05 21:49:06',0,1),(94,1,'title','2024-01-05 21:49:06',0,1),(94,1,'typeId','2024-01-11 16:57:38',0,1),(94,1,'uri','2024-01-05 21:49:06',0,1),(102,1,'fieldLayoutId','2024-01-11 16:57:22',0,1),(102,1,'postDate','2024-01-05 21:52:00',0,1),(102,1,'slug','2024-01-05 21:51:51',0,1),(102,1,'title','2024-01-05 21:52:55',0,1),(102,1,'typeId','2024-01-11 16:57:22',0,1),(102,1,'uri','2024-01-05 21:51:51',0,1),(111,1,'fieldLayoutId','2024-01-11 16:56:51',0,1),(111,1,'postDate','2024-01-05 21:55:59',0,1),(111,1,'slug','2024-01-05 21:54:42',0,1),(111,1,'title','2024-01-05 21:54:42',0,1),(111,1,'typeId','2024-01-11 16:56:51',0,1),(111,1,'uri','2024-01-05 21:54:42',0,1),(113,1,'postDate','2024-01-05 21:56:25',0,1),(113,1,'slug','2024-01-05 21:56:19',0,1),(113,1,'title','2024-01-05 21:56:19',0,1),(113,1,'uri','2024-01-05 21:56:19',0,1),(117,1,'fieldLayoutId','2024-01-05 22:10:26',0,1),(117,1,'postDate','2024-01-05 21:59:07',0,1),(117,1,'slug','2024-01-05 21:57:39',0,1),(117,1,'title','2024-01-05 21:57:39',0,1),(117,1,'typeId','2024-01-05 22:10:26',0,1),(117,1,'uri','2024-01-05 21:57:39',0,1),(201,1,'postDate','2024-01-10 22:10:35',0,1),(201,1,'slug','2024-01-10 22:10:35',0,1),(201,1,'title','2024-01-10 22:10:35',0,1),(201,1,'uri','2024-01-10 22:10:35',0,1),(203,1,'postDate','2024-01-10 22:10:49',0,1),(203,1,'slug','2024-01-10 22:10:49',0,1),(203,1,'title','2024-01-10 22:11:14',0,1),(203,1,'uri','2024-01-10 22:10:49',0,1);
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedfields` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `fieldId` int NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`),
  KEY `idx_uqnxcdclpoyjzvhpwaxmfscvwzhxdcfldbxa` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_tdjpuanbosbibgonxehsgmsomtdjquocljjf` (`siteId`),
  KEY `fk_dashymjbczaiubdtewnhdikndzpyuawfyscl` (`fieldId`),
  KEY `fk_uzbkytiqxpfbewqzusxuwjilsvnwwtrulpro` (`userId`),
  CONSTRAINT `fk_dashymjbczaiubdtewnhdikndzpyuawfyscl` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tdjpuanbosbibgonxehsgmsomtdjquocljjf` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_uzbkytiqxpfbewqzusxuwjilsvnwwtrulpro` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_zdreqhidaexjzgsziqckfruugcahltzadfnm` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
INSERT INTO `changedfields` VALUES (3,1,8,'2024-01-05 23:53:16',0,1),(3,1,9,'2024-01-05 23:53:16',0,1),(3,1,10,'2024-01-05 23:53:16',0,1),(3,1,13,'2024-01-05 23:47:20',0,1),(16,1,8,'2024-01-05 19:10:27',0,1),(16,1,9,'2024-01-05 23:51:07',0,1),(16,1,10,'2024-01-05 19:19:58',0,1),(16,1,13,'2024-01-05 19:04:51',0,1),(92,1,1,'2024-01-05 21:46:55',0,1),(92,1,2,'2024-01-05 21:59:48',0,1),(92,1,3,'2024-01-05 21:49:46',0,1),(92,1,4,'2024-01-05 21:46:56',0,1),(92,1,5,'2024-01-05 21:53:23',0,1),(92,1,14,'2024-01-06 00:08:43',0,1),(92,1,15,'2024-01-10 22:13:51',0,1),(94,1,1,'2024-01-05 21:50:46',0,1),(94,1,2,'2024-01-05 22:00:14',0,1),(94,1,3,'2024-01-05 21:49:33',0,1),(94,1,4,'2024-01-05 21:50:46',0,1),(94,1,5,'2024-01-05 22:00:14',0,1),(94,1,14,'2024-01-06 00:08:21',0,1),(94,1,15,'2024-01-10 22:13:37',0,1),(102,1,1,'2024-01-05 21:52:55',0,1),(102,1,2,'2024-01-05 21:59:31',0,1),(102,1,3,'2024-01-05 21:52:00',0,1),(102,1,4,'2024-01-05 21:52:55',0,1),(102,1,5,'2024-01-11 16:57:22',0,1),(102,1,14,'2024-01-06 00:08:10',0,1),(102,1,15,'2024-01-10 22:13:23',0,1),(111,1,1,'2024-01-05 21:55:54',0,1),(111,1,2,'2024-01-05 21:59:16',0,1),(111,1,3,'2024-01-05 21:54:51',0,1),(111,1,4,'2024-01-05 21:55:57',0,1),(111,1,5,'2024-01-05 21:55:54',0,1),(111,1,14,'2024-01-06 00:08:00',0,1),(111,1,15,'2024-01-10 22:13:09',0,1),(113,1,1,'2024-01-05 21:57:23',0,1),(113,1,3,'2024-01-05 21:56:25',0,1),(113,1,4,'2024-01-05 21:57:23',0,1),(113,1,5,'2024-01-05 21:57:23',0,1),(113,1,14,'2024-01-06 00:07:45',0,1),(113,1,15,'2024-01-10 22:12:57',0,1),(117,1,1,'2024-01-06 16:51:36',0,1),(117,1,3,'2024-01-05 21:57:44',0,1),(117,1,4,'2024-01-05 21:57:55',0,1),(117,1,5,'2024-01-10 22:50:58',0,1),(117,1,14,'2024-01-06 00:07:35',0,1),(117,1,15,'2024-01-10 22:12:43',0,1);
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content`
--

DROP TABLE IF EXISTS `content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `content` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_introduction_fzsqwxge` text,
  `field_pageCoppy_wixbjycs` text,
  `field_priceDrinks_zfzzucta` decimal(12,2) DEFAULT NULL,
  `field_alcoholPercentage_rksiqext` int DEFAULT NULL,
  `field_informationDrinks_bnfajgjp` text,
  `field_infoAbout_tqqdapum` text,
  `field_onsAssortiment_eufivvyq` text,
  `field_enkelAlcohol_rctpvesc` text,
  `field_whatWeAreAllAbout_kbjjojsw` text,
  `field_test_bqwgakef` text,
  `field_header1_lwhrkzwq` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_mhzsqtxxjhjbrnsmokdowabnyvkaqenhwyes` (`elementId`,`siteId`),
  KEY `idx_apqbjdnnmlmuxzzjecaatewiggvsmgknokcy` (`siteId`),
  KEY `idx_lbpqfmwvpyxhxotwymsagojcyobvjjmatwyg` (`title`),
  CONSTRAINT `fk_ncnbdqpnielrlhcdimmyhqjdowhrpxxqxgpa` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_rllbwlvhsjlgmvatoccvqbnryevvsyunzxvq` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=230 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content`
--

LOCK TABLES `content` WRITE;
/*!40000 ALTER TABLE `content` DISABLE KEYS */;
INSERT INTO `content` VALUES (1,1,1,NULL,'2023-12-26 19:45:34','2023-12-26 19:45:34','bd9f959c-190f-48b3-96cd-23a25efe3b70',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,2,1,NULL,'2024-01-05 15:27:20','2024-01-06 00:32:56','16991d76-ea7e-46da-aebd-3657214436f6',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(3,3,1,'About us','2024-01-05 15:47:11','2024-01-06 17:54:36','f4dc8d21-25fa-4d10-a9ac-594ebf405105',NULL,NULL,NULL,NULL,NULL,NULL,'<div class=\"red\">Welkom</div>\n<p>Welkom in THE VERY GOOD DRINKS – waar drank koning is. We zijn meer dan enkel een drank bedrijf; we zijn een hippe leuke en lekkere comunity met als missie het brengen van de lekkerste dranken</p>','<div class=\"red\">Ons verhaal</div>\n<p>We zijn ontstaan uit het brein van onze oprichter Yann Tagakou. <br />Opgericht in 2024, zijn we begonnen aan een reis om iedereen aan drank te voorzien. Sindsdien zijn we uitgegroeid tot een kleine startup die het halen wilt</p>','<div class=\"red\">Contact</div>\n<p>Phone: +32494739154<br />Mail: TheVeryGoodDrinks@gmail.com</p>\n<p>Attenhovenstraat 47, 3400 Landen</p>',NULL,'<p>ABOUT</p>\n<div class=\"red\">\"The very good drinks\"</div>'),(4,4,1,'About us','2024-01-05 15:47:11','2024-01-05 17:09:16','2cf7527f-4375-45bd-8569-3932bcf11382',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(5,5,1,'About us','2024-01-05 15:47:11','2024-01-05 17:09:16','38b75984-f9c6-46e7-b23f-f56624cb64f7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(6,6,1,NULL,'2024-01-05 16:35:04','2024-01-06 00:32:56','f6b49ecd-2153-4239-993e-ae6593bf5c20',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(7,7,1,'About us','2024-01-05 17:04:19','2024-01-05 17:09:16','bd0ec941-c6af-4ea7-83ba-9046dc71748c',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(8,8,1,'About us','2024-01-05 17:06:33','2024-01-05 17:09:16','f2d9c38f-f09c-4ed4-a8fa-78d1a37e9579',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(9,9,1,'About us','2024-01-05 17:07:12','2024-01-05 17:09:16','cc1ac47e-cf80-42ed-9196-e2dfac1fa000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(10,10,1,'About us','2024-01-05 17:07:36','2024-01-05 17:09:16','935b7567-acc2-483c-b464-6d8536f29c4d',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(11,11,1,'About us','2024-01-05 17:07:36','2024-01-05 17:09:16','29bb3d31-6eff-45b5-87b9-fd95f4dec1a2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(12,12,1,'About us','2024-01-05 17:08:38','2024-01-05 17:09:16','de4b0e65-dd90-4896-94e5-475c90980c81',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(13,13,1,'About us','2024-01-05 17:08:38','2024-01-05 17:09:16','07143703-6a10-4383-a50c-caa0d53bcb99',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(14,14,1,'About us','2024-01-05 17:09:15','2024-01-05 17:09:16','5b93c455-eac5-4830-a475-7693079b4e9d',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(15,15,1,'About us','2024-01-05 17:09:15','2024-01-05 17:09:16','7b2fef16-88e2-4128-91e1-70926020ef1e',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(16,16,1,'home','2024-01-05 17:43:07','2024-01-06 17:49:03','8acdef58-9b77-4ecb-8a6a-4f12ba3f0800',NULL,NULL,NULL,NULL,NULL,NULL,'<h2>ons</h2>\n<div class=\"red\">\"Assortiment\"</div>\n<p>Heb jij een feest of denk je een kleine avond te organiseren. Twijfel dan zeker niet om ons assortiment te bekijken. We beloven je de beste kwaliteit aan dranken en de meeste keuze. Zowel met als zonder alcohol</p>','<h2>enkel</h2>\n<div class=\"red\">Alcohol</div>\n<p>Wil je je een avond organiseren met drank? Kijk dan zeker door ons assortiment met alcohol. Voor iedereen is er iets. <br /><br />Vergeet niet ons vakmanschap drink je met verstand.</p>','<h2>what we are all</h2>\n<div class=\"red\">About</div>\n<p>Eerst en vooral wij zijn de nummer 1 website in drankverkoop. Maar we zijn meer dan dat. Ondek dit allemaal.</p>',NULL,'<p>Welcome to</p>\n<div class=\"red\">\"The very good drinks\"</div>'),(23,23,1,'home','2024-01-05 17:55:32','2024-01-05 22:38:36','622653f3-1591-4e9b-8df5-51aac93fba52',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(24,24,1,'home','2024-01-05 17:57:01','2024-01-05 22:38:36','996a3533-4438-4614-8e1f-c36332cf3b2b',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(26,26,1,'home','2024-01-05 17:59:13','2024-01-05 22:38:36','0df01275-b8d0-4296-ba4f-6cf487e38ca7',NULL,NULL,NULL,NULL,NULL,NULL,'<h1>afazf</h1>\n<p> </p>','<p>jfod</p>',NULL,NULL,NULL),(27,27,1,'home','2024-01-05 18:03:07','2024-01-05 22:38:36','ee82fb73-2d6c-4ee7-9c30-447dd4033f44',NULL,NULL,NULL,NULL,NULL,NULL,'<h1>afazf</h1>\n<p> </p>','<p>jfod</p>',NULL,NULL,NULL),(29,29,1,'home','2024-01-05 18:04:26','2024-01-05 22:38:36','d138f443-5035-4aef-afdd-e20bb59903f7',NULL,NULL,NULL,NULL,NULL,NULL,'<h1>afazf</h1>\n<p> </p>','<p>jfod</p>',NULL,NULL,NULL),(30,30,1,'home','2024-01-05 18:04:59','2024-01-05 22:38:36','21a8a89f-c036-4b9d-b57b-83e551d4569f',NULL,NULL,NULL,NULL,NULL,NULL,'<h1>afazf</h1>\n<p> </p>','<p>jfod</p>',NULL,NULL,NULL),(32,32,1,'home','2024-01-05 18:06:05','2024-01-05 22:38:36','d5f6553b-2d8e-47b0-ac30-938d835407ab',NULL,NULL,NULL,NULL,NULL,NULL,'<h1>afazf</h1>\n<p> </p>','<p>jfod</p>',NULL,NULL,NULL),(34,34,1,'home','2024-01-05 18:06:29','2024-01-05 22:38:36','2552fb67-a3f6-411c-8ed6-7e8ea395c321',NULL,NULL,NULL,NULL,NULL,NULL,'<h1>afazf</h1>\n<p> </p>','<p>jfod</p>',NULL,NULL,NULL),(36,36,1,'home','2024-01-05 18:07:13','2024-01-05 22:38:36','c81451e2-2c6a-4ee5-9ab5-d2fa1d94a0f9',NULL,NULL,NULL,NULL,NULL,NULL,'<h1>afazf</h1>\n<p> </p>','<p>jfod</p>',NULL,NULL,NULL),(38,38,1,'home','2024-01-05 18:07:44','2024-01-05 22:38:36','343efd03-2a5c-4cca-b1f9-7f3249c4ecbc',NULL,NULL,NULL,NULL,NULL,NULL,'<h1>afazf</h1>\n<p> </p>','<p>jfod</p>',NULL,NULL,NULL),(40,40,1,'home','2024-01-05 18:09:56','2024-01-05 22:38:36','d47a84a9-2369-4eb1-8fcd-f4b594cabd4a',NULL,NULL,NULL,NULL,NULL,NULL,'<h1>afazf</h1>\n<p> </p>','<p>jfod</p>',NULL,NULL,NULL),(41,41,1,'home','2024-01-05 18:10:11','2024-01-05 22:38:36','b33b78a1-974f-4642-aa44-ba23058a6a83',NULL,NULL,NULL,NULL,NULL,NULL,'<h1>afazf</h1>\n<p> </p>','<p>jfod</p>',NULL,NULL,NULL),(43,43,1,'home','2024-01-05 18:11:25','2024-01-05 22:38:36','d8ef88a5-e814-45c9-b2a9-c92ed31d855c',NULL,NULL,NULL,NULL,NULL,NULL,'<h1>afazf</h1>\n<p> </p>','<p>jfod</p>',NULL,NULL,NULL),(45,45,1,'home','2024-01-05 18:11:41','2024-01-05 22:38:36','d1220060-9b63-468c-bd01-4127eb7cc412',NULL,NULL,NULL,NULL,NULL,NULL,'<h1>afazf</h1>\n<p> </p>','<p>jfod</p>',NULL,NULL,NULL),(47,47,1,'home','2024-01-05 18:11:53','2024-01-05 22:38:36','756d05a2-5df8-4504-b87a-ad99d115b3da',NULL,NULL,NULL,NULL,NULL,NULL,'<h1>afazf</h1>\n<p> </p>','<p>jfod</p>',NULL,NULL,NULL),(49,49,1,'home','2024-01-05 18:13:04','2024-01-05 22:38:36','a527c34b-3490-4de9-b7e2-f072ba6d0648',NULL,NULL,NULL,NULL,NULL,NULL,'<h1>afazf</h1>\n<p> </p>','<p>jfod</p>',NULL,NULL,NULL),(50,50,1,'home','2024-01-05 18:19:48','2024-01-05 22:38:36','aeb4e152-f2a7-4805-89e2-de2086d675a2',NULL,NULL,NULL,NULL,NULL,NULL,'<h1>afazf</h1>\n<p> </p>','<p>jfod</p>',NULL,NULL,NULL),(52,52,1,'home','2024-01-05 18:30:39','2024-01-05 22:38:36','4242fab9-1e7f-4e8b-856b-8fec4d8c27fe',NULL,NULL,NULL,NULL,NULL,NULL,'<h1>afazf</h1>\n<p> </p>','<p>jfod</p>',NULL,NULL,NULL),(54,54,1,'home','2024-01-05 18:35:14','2024-01-05 22:38:36','602c0104-d1b9-41e5-bf55-950237bd6eb0',NULL,NULL,NULL,NULL,NULL,NULL,'<h1>afazf</h1>\n<p> </p>','<p>jfod</p>',NULL,NULL,NULL),(56,56,1,'home','2024-01-05 18:36:54','2024-01-05 22:38:36','25853493-21f7-4be9-828a-a80adffda3a2',NULL,NULL,NULL,NULL,NULL,NULL,'<h1>afazf</h1>\n<p> </p>','<p>jfod</p>',NULL,NULL,NULL),(58,58,1,'home','2024-01-05 18:38:52','2024-01-05 22:38:36','a569d091-f638-400c-bff3-ba1b237d0420',NULL,NULL,NULL,NULL,NULL,NULL,'<h1>afazf</h1>\n<p> </p>','<p>jfod</p>',NULL,NULL,NULL),(59,59,1,'home','2024-01-05 18:39:34','2024-01-05 22:38:36','580495f2-0144-427d-a0c6-800abff1ffa9',NULL,NULL,NULL,NULL,NULL,NULL,'<h1>afazf</h1>\n<p> </p>','<p>jfod</p>',NULL,NULL,NULL),(61,61,1,'home','2024-01-05 18:41:10','2024-01-05 22:38:36','40d8e04b-f902-4bb2-85bf-7d88d5b42f3f',NULL,NULL,NULL,NULL,NULL,NULL,'<h1>afazf</h1>\n<p> </p>','<p>jfod</p>',NULL,NULL,NULL),(62,62,1,'home','2024-01-05 18:44:28','2024-01-05 22:38:37','8f7a8e21-91b0-4995-b788-da72e97c5924',NULL,NULL,NULL,NULL,NULL,NULL,'<h1>afazf</h1>\n<p> </p>','<p>jfod</p>',NULL,NULL,NULL),(64,64,1,'home','2024-01-05 18:44:43','2024-01-05 22:38:37','78f89b6b-9e1e-493f-a41a-87f21dfcfad1',NULL,NULL,NULL,NULL,NULL,NULL,'<h1>afazf</h1>\n<p> </p>','<p>jfod</p>',NULL,NULL,NULL),(66,66,1,'home','2024-01-05 18:47:43','2024-01-05 22:38:37','ed51662c-8fe1-4ee0-97d9-fb39860481f7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'<p>Hallo allses goed</p>'),(67,67,1,'home','2024-01-05 18:50:21','2024-01-05 22:38:37','68312e07-d6f8-4a8f-8afd-26da67c69d1e',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'<p>Hallo allses goed</p>'),(69,69,1,'home','2024-01-05 18:54:05','2024-01-05 22:38:37','195ee446-d49b-4413-8627-dc24515264c1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'<p>Welcome to </p>\n<div class=\"red\">\"The very good drinks\"</div>'),(71,71,1,'home','2024-01-05 18:55:34','2024-01-05 22:38:37','86a2e15c-91d0-4b09-91c2-45a85f537fef',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'<h1>Welcome to</h1>\n<div class=\"red\">\"The very good drinks\"</div>'),(73,73,1,'home','2024-01-05 18:56:27','2024-01-05 22:38:37','811b68c4-3a41-4d18-88a7-5a4104af9e34',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'<p>Welcome to </p>\n<div class=\"red\">\"The very good drinks\"</div>'),(74,74,1,'home','2024-01-05 18:58:08','2024-01-05 22:38:37','f8ad0dd3-f7b0-4dfd-84a9-1ea0281318d4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'<p>Welcome to</p>\n<div class=\"red\">\"The very good drinks\"</div>'),(76,76,1,'home','2024-01-05 18:58:39','2024-01-05 22:38:37','16f5ab32-043c-414f-a841-5d184ed0f928',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'<h1>Welcome to</h1>\n<div class=\"red\">\"The very good drinks\"</div>'),(77,77,1,'home','2024-01-05 18:59:02','2024-01-05 22:38:37','afcce955-4478-4605-b293-333d3f60464a',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'<h1>Welcome to</h1>\n<div class=\"red\">\"The very good drinks\"</div>'),(79,79,1,'home','2024-01-05 18:59:40','2024-01-05 22:38:37','0a849083-9bc8-4927-b1b6-d0db3aedb763',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'<p>Welcome to </p>\n<div class=\"red\">\"The very good drinks\"</div>'),(81,81,1,'home','2024-01-05 19:04:51','2024-01-05 22:38:37','4d0660c5-79d5-409d-b113-a9e6cbc619f9',NULL,NULL,NULL,NULL,NULL,NULL,'<p>ons</p><div class=\"red\">\"Assortiment\"</div><p>Heb jij een feest of denk je een kleine avond te organiseren. Twijfel dan zeker niet om ons assortiment te bekijken. We beloven je de beste kwaliteit aan dranken en de meeste keuze. Zowel met als zonder alcohol</p>','<p><br /></p>','<p><br /></p>',NULL,'<p>Welcome to</p>\n<div class=\"red\">\"The very good drinks\"</div>'),(83,83,1,'home','2024-01-05 19:08:12','2024-01-05 22:38:37','bca90d63-519f-4355-9441-f18aaa8f8d4f',NULL,NULL,NULL,NULL,NULL,NULL,'<p>ons</p>\n<div class=\"red\">\"Assortiment\"</div>\n<p>Heb jij een feest of denk je een kleine avond te organiseren. Twijfel dan zeker niet om ons assortiment te bekijken. We beloven je de beste kwaliteit aan dranken en de meeste keuze. Zowel met als zonder alcohol</p>',NULL,NULL,NULL,'<p>Welcome to</p>\n<div class=\"red\">\"The very good drinks\"</div>'),(85,85,1,'home','2024-01-05 19:10:27','2024-01-05 22:38:37','fadd4d42-e300-48b9-a5f2-b113d1ca1dbe',NULL,NULL,NULL,NULL,NULL,NULL,'<h2>ons</h2>\n<div class=\"red\">\"Assortiment\"</div>\n<p>Heb jij een feest of denk je een kleine avond te organiseren. Twijfel dan zeker niet om ons assortiment te bekijken. We beloven je de beste kwaliteit aan dranken en de meeste keuze. Zowel met als zonder alcohol</p>',NULL,NULL,NULL,'<p>Welcome to</p>\n<div class=\"red\">\"The very good drinks\"</div>'),(87,87,1,'home','2024-01-05 19:13:45','2024-01-05 22:38:37','715cf1c8-9a75-4439-a07e-b40e9f60e2d4',NULL,NULL,NULL,NULL,NULL,NULL,'<h2>ons</h2>\n<div class=\"red\">\"Assortiment\"</div>\n<p>Heb jij een feest of denk je een kleine avond te organiseren. Twijfel dan zeker niet om ons assortiment te bekijken. We beloven je de beste kwaliteit aan dranken en de meeste keuze. Zowel met als zonder alcohol</p>','<p>&lt;h2&gt;enkel&lt;/h2&gt;<br />&lt;div class=\"red\"&gt;\"Alcohol\"&lt;/div&gt;<br />&lt;p&gt; Wil je je een avond organiseren met drank? Kijk dan zeker door ons assortiment met alcohol. Voor iedereen is er iets. &lt;br&gt; &lt;br&gt; Vergeet niet ons vakmanschap drink je met verstand.</p>\n<p>&lt;/p&gt;</p>',NULL,NULL,'<p>Welcome to</p>\n<div class=\"red\">\"The very good drinks\"</div>'),(89,89,1,'home','2024-01-05 19:15:28','2024-01-05 22:38:37','641605db-229c-4f62-b787-3e30b8affaa8',NULL,NULL,NULL,NULL,NULL,NULL,'<h2>ons</h2>\n<div class=\"red\">\"Assortiment\"</div>\n<p>Heb jij een feest of denk je een kleine avond te organiseren. Twijfel dan zeker niet om ons assortiment te bekijken. We beloven je de beste kwaliteit aan dranken en de meeste keuze. Zowel met als zonder alcohol</p>','<h2>enkel</h2>\n<div class=\"red\">Alcohol</div>\n<p>Wil je je een avond organiseren met drank? Kijk dan zeker door ons assortiment met alcohol. Voor iedereen is er iets. <br /><br />Vergeet niet ons vakmanschap drink je met verstand.</p>',NULL,NULL,'<p>Welcome to</p>\n<div class=\"red\">\"The very good drinks\"</div>'),(91,91,1,'home','2024-01-05 19:19:58','2024-01-05 22:38:37','6cefa811-1bb0-4281-b97f-55fdd2fbe186',NULL,NULL,NULL,NULL,NULL,NULL,'<h2>ons</h2>\n<div class=\"red\">\"Assortiment\"</div>\n<p>Heb jij een feest of denk je een kleine avond te organiseren. Twijfel dan zeker niet om ons assortiment te bekijken. We beloven je de beste kwaliteit aan dranken en de meeste keuze. Zowel met als zonder alcohol</p>','<h2>enkel</h2>\n<div class=\"red\">Alcohol</div>\n<p>Wil je je een avond organiseren met drank? Kijk dan zeker door ons assortiment met alcohol. Voor iedereen is er iets. <br /><br />Vergeet niet ons vakmanschap drink je met verstand.</p>','<h2>what we are all</h2>\n<div class=\"red\">About</div>\n<p>Eerst en vooral wij zijn de nummer 1 website in drankverkoop. Maar we zijn meer dan dat. Ondek dit allemaal.</p>',NULL,'<p>Welcome to</p>\n<div class=\"red\">\"The very good drinks\"</div>'),(92,92,1,'Smirnoff vodka','2024-01-05 21:45:37','2024-01-11 16:57:59','58ddac90-96c4-433c-a43b-79989c05e35c','<p>Geniet je graag van Smirnoff Vodka? Kies dan voor deze Smirnoff Vodka 1 liter fles.</p>',NULL,20.95,40,'<p>Smirnoff No.21 is een iconische wodka die bekend staat om zijn unieke mix van graanalcohol en zuiver gedestilleerd water. De wodka wordt gemaakt van 100% graan en wordt gedistilleerd en gefilterd door middel van houtskool. Het resultaat is een zachte en zuivere wodka met een subtiele graansmaak en een licht peperige afdronk. Smirnoff is opgericht in Rusland in 1864 en heeft sindsdien een wereldwijde reputatie opgebouwd als een van de beste wodka-merken ter wereld. De Smirnoff No.21 is de meest populaire wodka van het merk en wordt wereldwijd verkocht.</p>',NULL,NULL,NULL,NULL,NULL,NULL),(93,93,1,'Smirnoff vodka','2024-01-05 21:48:48','2024-01-06 16:18:01','11b80527-a94a-406a-8a5b-493740ef29ac','<p>Geniet je graag van Smirnoff Vodka? Kies dan voor deze Smirnoff Vodka 1 liter fles.</p>',NULL,2095.00,40,'<p>Smirnoff is the world\'s No.1 vodka, triple distilled and ten times filtered for a smooth, versatile and gold award-winning taste. With its unrivalled ingenuity born from brave beginnings, this iconic, trailblazing spirit is now enjoyed in over 130 countries worldwide, whether on the rocks, in a perfectly chilled Smirnoff Ice or as the hero of your guest\'s favourite cocktail.</p>\n<p>Since those early years of innovation, Smirnoff established itself as more than just a vodka, becoming a trailblazing instigator of many socialising and drinking trends. As a brand forever ahead of its time, Smirnoff infiltrated the United States as a white whiskey, ignited the cocktail revolution of the 1950s, invented Smirnoff Ice, and led the flavoured vodka revolution. A brand known to shake things up and do things a bit differently, Smirnoff has always been ahead of its time and driven cross-cultural appeal throughout its history.</p>',NULL,NULL,NULL,NULL,NULL,NULL),(94,94,1,'Absolut vodka','2024-01-05 21:48:58','2024-01-11 16:57:38','a0c80d66-5ab8-4bba-a6d6-4f589ce6c12a','<p>Absolut Vodka 1 liter is de meest bekende wodka toebehorend aan dit Zweedse wodkamerk.</p>',NULL,20.95,35,'<p>Wodka is een kleurloos zuiver distillaat, vaak afkomstig uit Rusland, Polen of Zweden. Vodka heeft geen rijpingsproces zoals de meeste andere gedestilleerde dranken en behoort hierdoor tot een van de zuiverste van de familie. Doordat het destillaat wordt opgeslagen met houtskool, worden alle onreinheden geabsorbeerd. Wodka betekent in het Russisch \'watertje\', wodka is daar een afleiding van. Veel merken geven de voorkeur aan \'vodka\' omdat het er authentieker uit ziet, puur omwille van de marketing.</p>',NULL,NULL,NULL,NULL,NULL,NULL),(95,95,1,'Absolut vodka','2024-01-05 21:49:16','2024-01-06 16:18:01','91aeeb02-c40b-42e8-8bef-6e315810e7de',NULL,NULL,2095.00,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(97,97,1,'Absolut vodka','2024-01-05 21:49:33','2024-01-06 16:18:01','c1d5507a-f628-40d3-b873-47c67e44226d',NULL,NULL,20.95,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(99,99,1,'Smirnoff vodka','2024-01-05 21:49:46','2024-01-06 16:18:01','9616a1b2-8f00-4a55-b58b-6fda7a8e121c','<p>Geniet je graag van Smirnoff Vodka? Kies dan voor deze Smirnoff Vodka 1 liter fles.</p>',NULL,20.95,40,'<p>Smirnoff is the world\'s No.1 vodka, triple distilled and ten times filtered for a smooth, versatile and gold award-winning taste. With its unrivalled ingenuity born from brave beginnings, this iconic, trailblazing spirit is now enjoyed in over 130 countries worldwide, whether on the rocks, in a perfectly chilled Smirnoff Ice or as the hero of your guest\'s favourite cocktail.</p>\n<p>Since those early years of innovation, Smirnoff established itself as more than just a vodka, becoming a trailblazing instigator of many socialising and drinking trends. As a brand forever ahead of its time, Smirnoff infiltrated the United States as a white whiskey, ignited the cocktail revolution of the 1950s, invented Smirnoff Ice, and led the flavoured vodka revolution. A brand known to shake things up and do things a bit differently, Smirnoff has always been ahead of its time and driven cross-cultural appeal throughout its history.</p>',NULL,NULL,NULL,NULL,NULL,NULL),(101,101,1,'Absolut vodka','2024-01-05 21:50:46','2024-01-06 16:18:01','4dd11190-ed9d-47d4-851e-babfe5531450','<p>Absolut Vodka 1 liter is de meest bekende wodka toebehorend aan dit Zweedse wodkamerk.</p>',NULL,20.95,35,'<p>Smirnoff No.21 is een iconische wodka die bekend staat om zijn unieke mix van graanalcohol en zuiver gedestilleerd water. De wodka wordt gemaakt van 100% graan en wordt gedistilleerd en gefilterd door middel van houtskool. Het resultaat is een zachte en zuivere wodka met een subtiele graansmaak en een licht peperige afdronk. Smirnoff is opgericht in Rusland in 1864 en heeft sindsdien een wereldwijde reputatie opgebouwd als een van de beste wodka-merken ter wereld. De Smirnoff No.21 is de meest populaire wodka van het merk en wordt wereldwijd verkocht.</p>',NULL,NULL,NULL,NULL,NULL,NULL),(102,102,1,'Jack Daniels','2024-01-05 21:51:41','2024-01-11 16:57:22','1e82bc3e-a007-4083-a884-c5619544df75','<p>Jack Daniels 1 is de meest populaire whiskey van het assortiment van dit geliefde Amerikaanse whiskeymerk.</p>',NULL,32.95,25,'<p>Sinds 1866 komt iedere druppel Jack Daniel’s whiskey uit het dorpje Lynchburg, diep op het platteland van Tennessee, Amerika. De Jack Daniel’s distilleerderij is de oudste geregistreerde distilleerderij van Amerika en is destijds begonnen door Jasper Newton ‘Jack’ Daniel.</p>\n<p>Jack Daniel\'s is, zoals de meesten denken, geen bourbon whiskey, maar Tennessee whiskey. De basisregels van bourbon of Amerikaanse whiskey worden gerespecteerd, maar daarnaast kent Jack Daniel’s whiskey een uniek extra element dat al sinds de oprichting van de distilleerderij (dit jaar 150 jaar geleden) wordt toegepast. De whiskey wordt na distillatie namelijk gefilterd door een drie meter dikke laag houtskool, wat zorgt voor de bekende zachtheid. Jack Daniel’s Tennessee Whiskey kent een licht fruitige mix van karamel, vanille, specerijen en geroosterd eiken. Aanbevolen drinkwijze is puur, on the rocks of gemixt met cola.</p>',NULL,NULL,NULL,NULL,NULL,NULL),(103,103,1,'JACK DANIELS','2024-01-05 21:52:00','2024-01-06 16:18:01','c510f289-6d36-460b-b29c-89d1c01f3bce',NULL,NULL,32.95,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(105,105,1,'Jack Daniels','2024-01-05 21:52:55','2024-01-06 16:18:01','35691937-e5f1-41b3-8ec9-2882c377262f','<p>Jack Daniels 1 is de meest populaire whiskey van het assortiment van dit geliefde Amerikaanse whiskeymerk.</p>',NULL,32.95,25,'<p>Sinds 1866 komt iedere druppel Jack Daniel’s whiskey uit het dorpje Lynchburg, diep op het platteland van Tennessee, Amerika. De Jack Daniel’s distilleerderij is de oudste geregistreerde distilleerderij van Amerika en is destijds begonnen door Jasper Newton ‘Jack’ Daniel.</p>\n<p>Jack Daniel\'s is, zoals de meesten denken, geen bourbon whiskey, maar Tennessee whiskey. De basisregels van bourbon of Amerikaanse whiskey worden gerespecteerd, maar daarnaast kent Jack Daniel’s whiskey een uniek extra element dat al sinds de oprichting van de distilleerderij (dit jaar 150 jaar geleden) wordt toegepast. De whiskey wordt na distillatie namelijk gefilterd door een drie meter dikke laag houtskool, wat zorgt voor de bekende zachtheid. Jack Daniel’s Tennessee Whiskey kent een licht fruitige mix van karamel, vanille, specerijen en geroosterd eiken. Aanbevolen drinkwijze is puur, on the rocks of gemixt met cola.</p>',NULL,NULL,NULL,NULL,NULL,NULL),(106,106,1,'Absolut vodka','2024-01-05 21:53:12','2024-01-06 16:18:01','2b826fe5-5300-4263-a303-67b138f0d6a5','<p>Absolut Vodka 1 liter is de meest bekende wodka toebehorend aan dit Zweedse wodkamerk.</p>',NULL,20.95,35,'<p>Smirnoff No.21 is een iconische wodka die bekend staat om zijn unieke mix van graanalcohol en zuiver gedestilleerd water. De wodka wordt gemaakt van 100% graan en wordt gedistilleerd en gefilterd door middel van houtskool. Het resultaat is een zachte en zuivere wodka met een subtiele graansmaak en een licht peperige afdronk. Smirnoff is opgericht in Rusland in 1864 en heeft sindsdien een wereldwijde reputatie opgebouwd als een van de beste wodka-merken ter wereld. De Smirnoff No.21 is de meest populaire wodka van het merk en wordt wereldwijd verkocht.</p>',NULL,NULL,NULL,NULL,NULL,NULL),(108,108,1,'Smirnoff vodka','2024-01-05 21:53:23','2024-01-06 16:18:01','cfdfb804-1ce0-4916-9434-27ff4066844b','<p>Geniet je graag van Smirnoff Vodka? Kies dan voor deze Smirnoff Vodka 1 liter fles.</p>',NULL,20.95,40,'<p>Smirnoff No.21 is een iconische wodka die bekend staat om zijn unieke mix van graanalcohol en zuiver gedestilleerd water. De wodka wordt gemaakt van 100% graan en wordt gedistilleerd en gefilterd door middel van houtskool. Het resultaat is een zachte en zuivere wodka met een subtiele graansmaak en een licht peperige afdronk. Smirnoff is opgericht in Rusland in 1864 en heeft sindsdien een wereldwijde reputatie opgebouwd als een van de beste wodka-merken ter wereld. De Smirnoff No.21 is de meest populaire wodka van het merk en wordt wereldwijd verkocht.</p>',NULL,NULL,NULL,NULL,NULL,NULL),(109,109,1,'Absolut vodka','2024-01-05 21:54:00','2024-01-06 16:18:02','c6f10272-33b3-4482-a075-25fe7011c878','<p>Absolut Vodka 1 liter is de meest bekende wodka toebehorend aan dit Zweedse wodkamerk.</p>',NULL,20.95,35,'<p>Wodka is een kleurloos zuiver distillaat, vaak afkomstig uit Rusland, Polen of Zweden. Vodka heeft geen rijpingsproces zoals de meeste andere gedestilleerde dranken en behoort hierdoor tot een van de zuiverste van de familie. Doordat het destillaat wordt opgeslagen met houtskool, worden alle onreinheden geabsorbeerd. Wodka betekent in het Russisch \'watertje\', wodka is daar een afleiding van. Veel merken geven de voorkeur aan \'vodka\' omdat het er authentieker uit ziet, puur omwille van de marketing.</p>',NULL,NULL,NULL,NULL,NULL,NULL),(111,111,1,'The Famous Grouse','2024-01-05 21:54:13','2024-01-11 16:56:50','f0d5d6a2-ce3c-4dc1-99df-9038f0696f03','<p>Famous Grouse 1 liter is een Blended Scotch whisky die al jaren tot de meest verkochte in zijn soort behoort.</p>',NULL,25.94,37,'<p>amous Grouse, een Schotse whisky die bekend staat om zijn kwaliteit en verfijnde smaak, heeft wereldwijd een enorme populariteit verworven onder whisky-liefhebbers. Met zijn rijke geschiedenis, unieke smaak en effectieve marketingstrategie heeft Famous Grouse zich weten te positioneren als een van de meest geliefde whiskymerken ter wereld. Lees hier alles over Famouse Grouse whisky en kom erachter waarom dit merk zo succesvol is.</p>',NULL,NULL,NULL,NULL,NULL,NULL),(112,112,1,'The Famous Grouse','2024-01-05 21:55:59','2024-01-06 16:18:02','a69064a9-889e-439f-a3af-6168bf519207','<p>Famous Grouse 1 liter is een Blended Scotch whisky die al jaren tot de meest verkochte in zijn soort behoort.</p>',NULL,25.94,37,'<p>amous Grouse, een Schotse whisky die bekend staat om zijn kwaliteit en verfijnde smaak, heeft wereldwijd een enorme populariteit verworven onder whisky-liefhebbers. Met zijn rijke geschiedenis, unieke smaak en effectieve marketingstrategie heeft Famous Grouse zich weten te positioneren als een van de meest geliefde whiskymerken ter wereld. Lees hier alles over Famouse Grouse whisky en kom erachter waarom dit merk zo succesvol is.</p>',NULL,NULL,NULL,NULL,NULL,NULL),(113,113,1,'Coca-cola','2024-01-05 21:56:14','2024-01-10 22:12:57','4b705a0e-221d-44f4-8fbb-d933d0e2f942','<p>De eerste cola was Coca-Cola, een alcoholvrije imitatie door John Pemberton, van de Vin Mariani die door Angelo Mariani was bedacht.</p>',NULL,8.49,0,'<p>Op 8 mei 1886 serveerde Dr. John Styth Pemberton de eerste Coca‑Cola ter wereld in zijn apotheek in Atlanta, Georgia. Sinds dat eerste iconische drankje zijn we uitgegroeid tot een \'total beverage company\' - ons portfolio biedt voor ieder wat wils en dat voor elk moment van de dag.</p>\n<p>Dagelijks worden in meer dan 200 landen en regio\'s ruim 2,1 miljard van onze frisdranken gedronken. De 700.000 medewerkers van The Coca‑Cola Company en ruim 225 bottelpartners bezorgen de verfrissende dranken overal in de wereld.</p>',NULL,NULL,NULL,NULL,NULL,NULL),(114,114,1,'Coca-cola','2024-01-05 21:56:25','2024-01-06 16:18:02','f2188330-80ec-42f3-bc9e-44f595c47b05',NULL,NULL,8.49,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(116,116,1,'Coca-cola','2024-01-05 21:57:23','2024-01-06 16:18:02','3dc94477-9e99-4a84-8874-e5be8074a972','<p>De eerste cola was Coca-Cola, een alcoholvrije imitatie door John Pemberton, van de Vin Mariani die door Angelo Mariani was bedacht.</p>',NULL,8.49,0,'<p>Op 8 mei 1886 serveerde Dr. John Styth Pemberton de eerste Coca‑Cola ter wereld in zijn apotheek in Atlanta, Georgia. Sinds dat eerste iconische drankje zijn we uitgegroeid tot een \'total beverage company\' - ons portfolio biedt voor ieder wat wils en dat voor elk moment van de dag.</p>\n<p>Dagelijks worden in meer dan 200 landen en regio\'s ruim 2,1 miljard van onze frisdranken gedronken. De 700.000 medewerkers van The Coca‑Cola Company en ruim 225 bottelpartners bezorgen de verfrissende dranken overal in de wereld.</p>',NULL,NULL,NULL,NULL,NULL,NULL),(117,117,1,'Fanta BlueBerry 12','2024-01-05 21:57:27','2024-01-10 22:50:58','1c95d031-90f0-426e-ab3e-9c4ca0273425','<p>De eerste cola was FANTA, een alcoholvrije imitatie door John Pemberton, van de Vin Mariani die door Angelo Mariani was bedacht</p>',NULL,10.30,0,'<p>Zoals je weet is het drinken van Fanta Orange, dankzij zijn authentieke smaak, een unieke ervaring! Maar wat je misschien nog niet wist, is dat, wanneer je Fanta Orange drinkt, je eigenlijk volop geniet van een drank met sinaasappelsap* met natuurlijke aroma’s. Welcome to the fun, natuurlijk!</p>\n<p>*Uit sapconcentraat</p>\n<p>**Fanta Orange recepten kunnen verschillen in Europa</p>',NULL,NULL,NULL,NULL,NULL,NULL),(118,118,1,'Fanta BlueBerry 12','2024-01-05 21:59:07','2024-01-06 16:18:02','c5fd4f65-6074-42c9-805d-78d4c23aea2e','<p>De eerste cola was Coca-Cola, een alcoholvrije imitatie door John Pemberton, van de Vin Mariani die door Angelo Mariani was bedacht</p>',NULL,10.30,0,'<p>Zoals je weet is het drinken van Fanta Orange, dankzij zijn authentieke smaak, een unieke ervaring! Maar wat je misschien nog niet wist, is dat, wanneer je Fanta Orange drinkt, je eigenlijk volop geniet van een drank met sinaasappelsap* met natuurlijke aroma’s. Welcome to the fun, natuurlijk!</p>\n<p>*Uit sapconcentraat</p>\n<p>**Fanta Orange recepten kunnen verschillen in Europa</p>',NULL,NULL,NULL,NULL,NULL,NULL),(120,120,1,'The Famous Grouse','2024-01-05 21:59:16','2024-01-06 16:18:02','afca64ad-7bad-48c5-a671-346dc386d4b1','<p>Famous Grouse 1 liter is een Blended Scotch whisky die al jaren tot de meest verkochte in zijn soort behoort.</p>',NULL,25.94,37,'<p>amous Grouse, een Schotse whisky die bekend staat om zijn kwaliteit en verfijnde smaak, heeft wereldwijd een enorme populariteit verworven onder whisky-liefhebbers. Met zijn rijke geschiedenis, unieke smaak en effectieve marketingstrategie heeft Famous Grouse zich weten te positioneren als een van de meest geliefde whiskymerken ter wereld. Lees hier alles over Famouse Grouse whisky en kom erachter waarom dit merk zo succesvol is.</p>',NULL,NULL,NULL,NULL,NULL,NULL),(121,121,1,'The Famous Grouse','2024-01-05 21:59:22','2024-01-06 16:18:02','d6d5acb0-bc7f-4a5d-b34d-7e327b81b0e4','<p>Famous Grouse 1 liter is een Blended Scotch whisky die al jaren tot de meest verkochte in zijn soort behoort.</p>',NULL,25.94,37,'<p>amous Grouse, een Schotse whisky die bekend staat om zijn kwaliteit en verfijnde smaak, heeft wereldwijd een enorme populariteit verworven onder whisky-liefhebbers. Met zijn rijke geschiedenis, unieke smaak en effectieve marketingstrategie heeft Famous Grouse zich weten te positioneren als een van de meest geliefde whiskymerken ter wereld. Lees hier alles over Famouse Grouse whisky en kom erachter waarom dit merk zo succesvol is.</p>',NULL,NULL,NULL,NULL,NULL,NULL),(123,123,1,'Jack Daniels','2024-01-05 21:59:31','2024-01-06 16:18:02','0d25c10a-42df-462d-84b6-e0a9109670a9','<p>Jack Daniels 1 is de meest populaire whiskey van het assortiment van dit geliefde Amerikaanse whiskeymerk.</p>',NULL,32.95,25,'<p>Sinds 1866 komt iedere druppel Jack Daniel’s whiskey uit het dorpje Lynchburg, diep op het platteland van Tennessee, Amerika. De Jack Daniel’s distilleerderij is de oudste geregistreerde distilleerderij van Amerika en is destijds begonnen door Jasper Newton ‘Jack’ Daniel.</p>\n<p>Jack Daniel\'s is, zoals de meesten denken, geen bourbon whiskey, maar Tennessee whiskey. De basisregels van bourbon of Amerikaanse whiskey worden gerespecteerd, maar daarnaast kent Jack Daniel’s whiskey een uniek extra element dat al sinds de oprichting van de distilleerderij (dit jaar 150 jaar geleden) wordt toegepast. De whiskey wordt na distillatie namelijk gefilterd door een drie meter dikke laag houtskool, wat zorgt voor de bekende zachtheid. Jack Daniel’s Tennessee Whiskey kent een licht fruitige mix van karamel, vanille, specerijen en geroosterd eiken. Aanbevolen drinkwijze is puur, on the rocks of gemixt met cola.</p>',NULL,NULL,NULL,NULL,NULL,NULL),(125,125,1,'Smirnoff vodka','2024-01-05 21:59:48','2024-01-06 16:18:02','c00ebf0c-a9b6-472e-9a01-f6cf8d687917','<p>Geniet je graag van Smirnoff Vodka? Kies dan voor deze Smirnoff Vodka 1 liter fles.</p>',NULL,20.95,40,'<p>Smirnoff No.21 is een iconische wodka die bekend staat om zijn unieke mix van graanalcohol en zuiver gedestilleerd water. De wodka wordt gemaakt van 100% graan en wordt gedistilleerd en gefilterd door middel van houtskool. Het resultaat is een zachte en zuivere wodka met een subtiele graansmaak en een licht peperige afdronk. Smirnoff is opgericht in Rusland in 1864 en heeft sindsdien een wereldwijde reputatie opgebouwd als een van de beste wodka-merken ter wereld. De Smirnoff No.21 is de meest populaire wodka van het merk en wordt wereldwijd verkocht.</p>',NULL,NULL,NULL,NULL,NULL,NULL),(126,126,1,'Jack Daniels','2024-01-05 21:59:53','2024-01-06 16:18:02','476d3145-722e-4807-8ca5-c05fb5042e8a','<p>Jack Daniels 1 is de meest populaire whiskey van het assortiment van dit geliefde Amerikaanse whiskeymerk.</p>',NULL,32.95,25,'<p>Sinds 1866 komt iedere druppel Jack Daniel’s whiskey uit het dorpje Lynchburg, diep op het platteland van Tennessee, Amerika. De Jack Daniel’s distilleerderij is de oudste geregistreerde distilleerderij van Amerika en is destijds begonnen door Jasper Newton ‘Jack’ Daniel.</p>\n<p>Jack Daniel\'s is, zoals de meesten denken, geen bourbon whiskey, maar Tennessee whiskey. De basisregels van bourbon of Amerikaanse whiskey worden gerespecteerd, maar daarnaast kent Jack Daniel’s whiskey een uniek extra element dat al sinds de oprichting van de distilleerderij (dit jaar 150 jaar geleden) wordt toegepast. De whiskey wordt na distillatie namelijk gefilterd door een drie meter dikke laag houtskool, wat zorgt voor de bekende zachtheid. Jack Daniel’s Tennessee Whiskey kent een licht fruitige mix van karamel, vanille, specerijen en geroosterd eiken. Aanbevolen drinkwijze is puur, on the rocks of gemixt met cola.</p>',NULL,NULL,NULL,NULL,NULL,NULL),(127,127,1,'Smirnoff vodka','2024-01-05 21:59:58','2024-01-06 16:18:02','a0bb83ba-46b1-44de-8949-38686d467ed0','<p>Geniet je graag van Smirnoff Vodka? Kies dan voor deze Smirnoff Vodka 1 liter fles.</p>',NULL,20.95,40,'<p>Smirnoff No.21 is een iconische wodka die bekend staat om zijn unieke mix van graanalcohol en zuiver gedestilleerd water. De wodka wordt gemaakt van 100% graan en wordt gedistilleerd en gefilterd door middel van houtskool. Het resultaat is een zachte en zuivere wodka met een subtiele graansmaak en een licht peperige afdronk. Smirnoff is opgericht in Rusland in 1864 en heeft sindsdien een wereldwijde reputatie opgebouwd als een van de beste wodka-merken ter wereld. De Smirnoff No.21 is de meest populaire wodka van het merk en wordt wereldwijd verkocht.</p>',NULL,NULL,NULL,NULL,NULL,NULL),(128,128,1,'The Famous Grouse','2024-01-05 22:00:04','2024-01-06 16:18:02','f0e18622-deb3-44a0-8dd0-fe94ca5fbb02','<p>Famous Grouse 1 liter is een Blended Scotch whisky die al jaren tot de meest verkochte in zijn soort behoort.</p>',NULL,25.94,37,'<p>amous Grouse, een Schotse whisky die bekend staat om zijn kwaliteit en verfijnde smaak, heeft wereldwijd een enorme populariteit verworven onder whisky-liefhebbers. Met zijn rijke geschiedenis, unieke smaak en effectieve marketingstrategie heeft Famous Grouse zich weten te positioneren als een van de meest geliefde whiskymerken ter wereld. Lees hier alles over Famouse Grouse whisky en kom erachter waarom dit merk zo succesvol is.</p>',NULL,NULL,NULL,NULL,NULL,NULL),(129,129,1,'Jack Daniels','2024-01-05 22:00:07','2024-01-06 16:18:02','35d17ec2-11a9-4583-a976-89b337411f19','<p>Jack Daniels 1 is de meest populaire whiskey van het assortiment van dit geliefde Amerikaanse whiskeymerk.</p>',NULL,32.95,25,'<p>Sinds 1866 komt iedere druppel Jack Daniel’s whiskey uit het dorpje Lynchburg, diep op het platteland van Tennessee, Amerika. De Jack Daniel’s distilleerderij is de oudste geregistreerde distilleerderij van Amerika en is destijds begonnen door Jasper Newton ‘Jack’ Daniel.</p>\n<p>Jack Daniel\'s is, zoals de meesten denken, geen bourbon whiskey, maar Tennessee whiskey. De basisregels van bourbon of Amerikaanse whiskey worden gerespecteerd, maar daarnaast kent Jack Daniel’s whiskey een uniek extra element dat al sinds de oprichting van de distilleerderij (dit jaar 150 jaar geleden) wordt toegepast. De whiskey wordt na distillatie namelijk gefilterd door een drie meter dikke laag houtskool, wat zorgt voor de bekende zachtheid. Jack Daniel’s Tennessee Whiskey kent een licht fruitige mix van karamel, vanille, specerijen en geroosterd eiken. Aanbevolen drinkwijze is puur, on the rocks of gemixt met cola.</p>',NULL,NULL,NULL,NULL,NULL,NULL),(130,130,1,'Absolut vodka','2024-01-05 22:00:14','2024-01-06 16:18:03','23ecccf8-c184-4c62-bb44-e8b9cc8049b0','<p>Absolut Vodka 1 liter is de meest bekende wodka toebehorend aan dit Zweedse wodkamerk.</p>',NULL,20.95,35,'<p>Wodka is een kleurloos zuiver distillaat, vaak afkomstig uit Rusland, Polen of Zweden. Vodka heeft geen rijpingsproces zoals de meeste andere gedestilleerde dranken en behoort hierdoor tot een van de zuiverste van de familie. Doordat het destillaat wordt opgeslagen met houtskool, worden alle onreinheden geabsorbeerd. Wodka betekent in het Russisch \'watertje\', wodka is daar een afleiding van. Veel merken geven de voorkeur aan \'vodka\' omdat het er authentieker uit ziet, puur omwille van de marketing.</p>',NULL,NULL,NULL,NULL,NULL,NULL),(131,131,1,'Fanta BlueBerry 12','2024-01-05 22:01:12','2024-01-06 16:18:03','fcba18a8-c7cf-4b0e-919f-c5894aa728e0','<p>De eerste cola was Coca-Cola, een alcoholvrije imitatie door John Pemberton, van de Vin Mariani die door Angelo Mariani was bedacht</p>',NULL,10.30,0,'<p>Zoals je weet is het drinken van Fanta Orange, dankzij zijn authentieke smaak, een unieke ervaring! Maar wat je misschien nog niet wist, is dat, wanneer je Fanta Orange drinkt, je eigenlijk volop geniet van een drank met sinaasappelsap* met natuurlijke aroma’s. Welcome to the fun, natuurlijk!</p>\n<p>*Uit sapconcentraat</p>\n<p>**Fanta Orange recepten kunnen verschillen in Europa</p>',NULL,NULL,NULL,NULL,NULL,NULL),(133,133,1,'Fanta BlueBerry 12','2024-01-05 22:10:26','2024-01-06 16:18:03','22aba838-b400-4404-bde5-5dc580d17883','<p>De eerste cola was Coca-Cola, een alcoholvrije imitatie door John Pemberton, van de Vin Mariani die door Angelo Mariani was bedacht</p>',NULL,10.30,0,'<p>Zoals je weet is het drinken van Fanta Orange, dankzij zijn authentieke smaak, een unieke ervaring! Maar wat je misschien nog niet wist, is dat, wanneer je Fanta Orange drinkt, je eigenlijk volop geniet van een drank met sinaasappelsap* met natuurlijke aroma’s. Welcome to the fun, natuurlijk!</p>\n<p>*Uit sapconcentraat</p>\n<p>**Fanta Orange recepten kunnen verschillen in Europa</p>',NULL,NULL,NULL,NULL,NULL,NULL),(134,134,1,'The Famous Grouse','2024-01-05 22:19:55','2024-01-05 22:19:55','834bd0cb-da78-4683-9abd-dab8cf2e8f2d','<p>Famous Grouse 1 liter is een Blended Scotch whisky die al jaren tot de meest verkochte in zijn soort behoort.</p>',NULL,25.94,37,'<p>amous Grouse, een Schotse whisky die bekend staat om zijn kwaliteit en verfijnde smaak, heeft wereldwijd een enorme populariteit verworven onder whisky-liefhebbers. Met zijn rijke geschiedenis, unieke smaak en effectieve marketingstrategie heeft Famous Grouse zich weten te positioneren als een van de meest geliefde whiskymerken ter wereld. Lees hier alles over Famouse Grouse whisky en kom erachter waarom dit merk zo succesvol is.</p>',NULL,NULL,NULL,NULL,NULL,NULL),(135,135,1,'The Famous Grouse','2024-01-05 22:19:55','2024-01-05 22:19:55','7e27eef4-1ba8-4c97-b5b9-fa2429309119','<p>Famous Grouse 1 liter is een Blended Scotch whisky die al jaren tot de meest verkochte in zijn soort behoort.</p>',NULL,25.94,37,'<p>amous Grouse, een Schotse whisky die bekend staat om zijn kwaliteit en verfijnde smaak, heeft wereldwijd een enorme populariteit verworven onder whisky-liefhebbers. Met zijn rijke geschiedenis, unieke smaak en effectieve marketingstrategie heeft Famous Grouse zich weten te positioneren als een van de meest geliefde whiskymerken ter wereld. Lees hier alles over Famouse Grouse whisky en kom erachter waarom dit merk zo succesvol is.</p>',NULL,NULL,NULL,NULL,NULL,NULL),(137,137,1,'home','2024-01-05 22:37:19','2024-01-05 22:38:37','3a62c6e4-d74b-4fd3-9b11-aef2f11bd8dc',NULL,NULL,NULL,NULL,NULL,NULL,'<h2>ons</h2>\n<div class=\"red\">\"Assortiment\"</div>\n<p>Heb jij een feest of denk je een kleine avond te organiseren. Twijfel dan zeker niet om ons assortiment te bekijken. We beloven je de beste kwaliteit aan dranken en de meeste keuze. Zowel met als zonder alcohol</p>','<h2>enkel</h2>\n<div class=\"red\">Alcohol</div>\n<p>Wil je je een avond organiseren met drank? Kijk dan zeker door ons assortiment met alcohol. Voor iedereen is er iets. <br /><br />Vergeet niet ons vakmanschap drink je met verstand.</p>','<h2>what we are all</h2>\n<div class=\"red\">About</div>\n<p>Eerst en vooral wij zijn de nummer 1 website in drankverkoop. Maar we zijn meer dan dat. Ondek dit allemaal.</p>',NULL,'<p>Welcome to</p>\n<div class=\"red\">\"The very good drinks\"</div>'),(138,138,1,'home','2024-01-05 22:37:19','2024-01-05 22:38:37','5886fb61-413d-4d49-9906-09b34c6058d7',NULL,NULL,NULL,NULL,NULL,NULL,'<h2>ons</h2>\n<div class=\"red\">\"Assortiment\"</div>\n<p>Heb jij een feest of denk je een kleine avond te organiseren. Twijfel dan zeker niet om ons assortiment te bekijken. We beloven je de beste kwaliteit aan dranken en de meeste keuze. Zowel met als zonder alcohol</p>','<h2>enkel</h2>\n<div class=\"red\">Alcohol</div>\n<p>Wil je je een avond organiseren met drank? Kijk dan zeker door ons assortiment met alcohol. Voor iedereen is er iets. <br /><br />Vergeet niet ons vakmanschap drink je met verstand.</p>','<h2>what we are all</h2>\n<div class=\"red\">About</div>\n<p>Eerst en vooral wij zijn de nummer 1 website in drankverkoop. Maar we zijn meer dan dat. Ondek dit allemaal.</p>',NULL,'<p>Welcome to</p>\n<div class=\"red\">\"The very good drinks\"</div>'),(139,139,1,'home','2024-01-05 22:37:54','2024-01-05 22:38:37','e94afcd5-c631-46cd-b8b6-1edb4ef07637',NULL,NULL,NULL,NULL,NULL,NULL,'<h2>ons</h2>\n<div class=\"red\">\"Assortiment\"</div>\n<p>Heb jij een feest of denk je een kleine avond te organiseren. Twijfel dan zeker niet om ons assortiment te bekijken. We beloven je de beste kwaliteit aan dranken en de meeste keuze. Zowel met als zonder alcohol</p>','<h2>enkel</h2>\n<div class=\"red\">Alcohol</div>\n<p>Wil je je een avond organiseren met drank? Kijk dan zeker door ons assortiment met alcohol. Voor iedereen is er iets. <br /><br />Vergeet niet ons vakmanschap drink je met verstand.</p>','<h2>what we are all</h2>\n<div class=\"red\">About</div>\n<p>Eerst en vooral wij zijn de nummer 1 website in drankverkoop. Maar we zijn meer dan dat. Ondek dit allemaal.</p>',NULL,'<p>Welcome to</p>\n<div class=\"red\">\"The very good drinks\"</div>'),(140,140,1,'home','2024-01-05 22:37:54','2024-01-05 22:38:37','193baa5e-36c9-4573-8cbd-be96a3d087e6',NULL,NULL,NULL,NULL,NULL,NULL,'<h2>ons</h2>\n<div class=\"red\">\"Assortiment\"</div>\n<p>Heb jij een feest of denk je een kleine avond te organiseren. Twijfel dan zeker niet om ons assortiment te bekijken. We beloven je de beste kwaliteit aan dranken en de meeste keuze. Zowel met als zonder alcohol</p>','<h2>enkel</h2>\n<div class=\"red\">Alcohol</div>\n<p>Wil je je een avond organiseren met drank? Kijk dan zeker door ons assortiment met alcohol. Voor iedereen is er iets. <br /><br />Vergeet niet ons vakmanschap drink je met verstand.</p>','<h2>what we are all</h2>\n<div class=\"red\">About</div>\n<p>Eerst en vooral wij zijn de nummer 1 website in drankverkoop. Maar we zijn meer dan dat. Ondek dit allemaal.</p>',NULL,'<p>Welcome to</p>\n<div class=\"red\">\"The very good drinks\"</div>'),(141,141,1,'home','2024-01-05 22:38:56','2024-01-05 22:38:56','bddec1e8-4047-4f3d-8500-cc4a1372e663',NULL,NULL,NULL,NULL,NULL,NULL,'<h2>ons</h2>\n<div class=\"red\">\"Assortiment\"</div>\n<p>Heb jij een feest of denk je een kleine avond te organiseren. Twijfel dan zeker niet om ons assortiment te bekijken. We beloven je de beste kwaliteit aan dranken en de meeste keuze. Zowel met als zonder alcohol</p>','<h2>enkel</h2>\n<div class=\"red\">Alcohol</div>\n<p>Wil je je een avond organiseren met drank? Kijk dan zeker door ons assortiment met alcohol. Voor iedereen is er iets. <br /><br />Vergeet niet ons vakmanschap drink je met verstand.</p>','<h2>what we are all</h2>\n<div class=\"red\">About</div>\n<p>Eerst en vooral wij zijn de nummer 1 website in drankverkoop. Maar we zijn meer dan dat. Ondek dit allemaal.</p>',NULL,'<p>Welcome to</p>\n<div class=\"red\">\"The very good drinks\"</div>'),(142,142,1,'home','2024-01-05 22:38:56','2024-01-05 22:38:56','f09dd1fa-c346-4afe-bb35-e2de8c99e7b8',NULL,NULL,NULL,NULL,NULL,NULL,'<h2>ons</h2>\n<div class=\"red\">\"Assortiment\"</div>\n<p>Heb jij een feest of denk je een kleine avond te organiseren. Twijfel dan zeker niet om ons assortiment te bekijken. We beloven je de beste kwaliteit aan dranken en de meeste keuze. Zowel met als zonder alcohol</p>','<h2>enkel</h2>\n<div class=\"red\">Alcohol</div>\n<p>Wil je je een avond organiseren met drank? Kijk dan zeker door ons assortiment met alcohol. Voor iedereen is er iets. <br /><br />Vergeet niet ons vakmanschap drink je met verstand.</p>','<h2>what we are all</h2>\n<div class=\"red\">About</div>\n<p>Eerst en vooral wij zijn de nummer 1 website in drankverkoop. Maar we zijn meer dan dat. Ondek dit allemaal.</p>',NULL,'<p>Welcome to</p>\n<div class=\"red\">\"The very good drinks\"</div>'),(143,143,1,'Coca Cola','2024-01-05 23:21:27','2024-01-05 23:21:38','63491b6b-301b-4b8c-88eb-731dd1d97274',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(144,144,1,'About us','2024-01-05 23:32:48','2024-01-05 23:32:48','54447ac9-4844-4286-9346-f0276edc97e7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(146,146,1,'About us','2024-01-05 23:38:13','2024-01-05 23:38:13','89764ab1-3146-4015-a1e8-e89f4b37a222',NULL,NULL,NULL,NULL,NULL,NULL,'<h2>Ons verhaal</h2>\n<p>We zijn ontstaan uit het brein van onze oprichter Yann Tagakou. </p>\n<p>Opgericht in 2024, zijn we begonnen aan een reis om iedereen aan drank te voorzien. Sindsdien zijn we uitgegroeid tot een kleine startup die het halen wilt.</p>','<h2>Welcome</h2>\n<p>Welkom in THE VERY GOOD DRINKS – waar drank koning is. We zijn meer dan enkel een drank bedrijf; we zijn een hippe leuke en lekkere comunity met als missie het brengen van de lekkerste dranken.</p>','<h2>Contact</h2>\n<p>Phone: +32494739154<br />Mail: TheVeryGoodDrinks@gmail.com</p>\n<p>Attenhovenstraat 47, 3400 Landen</p>',NULL,NULL),(147,147,1,'About us','2024-01-05 23:39:11','2024-01-05 23:39:11','822de3fe-e468-4df2-bdcc-24d6d306fe18',NULL,NULL,NULL,NULL,NULL,NULL,'<h2>Ons verhaal</h2>\n<p>We zijn ontstaan uit het brein van onze oprichter Yann Tagakou. </p>\n<p>Opgericht in 2024, zijn we begonnen aan een reis om iedereen aan drank te voorzien. Sindsdien zijn we uitgegroeid tot een kleine startup die het halen wilt.</p>','<h2>Welcome</h2>\n<p>Welkom in THE VERY GOOD DRINKS – waar drank koning is. We zijn meer dan enkel een drank bedrijf; we zijn een hippe leuke en lekkere comunity met als missie het brengen van de lekkerste dranken.</p>','<h2>Contact</h2>\n<p>Phone: +32494739154<br />Mail: TheVeryGoodDrinks@gmail.com</p>\n<p>Attenhovenstraat 47, 3400 Landen</p>',NULL,NULL),(149,149,1,'About us','2024-01-05 23:40:25','2024-01-05 23:40:25','96a43209-8b91-4595-98b0-9d9952c9a593',NULL,NULL,NULL,NULL,NULL,NULL,'<h2>Welcome</h2>\n<p>Welkom in THE VERY GOOD DRINKS – waar drank koning is. We zijn meer dan enkel een drank bedrijf; we zijn een hippe leuke en lekkere comunity met als missie het brengen van de lekkerste dranken.</p>','<h2>Ons verhaal</h2>\n<p>We zijn ontstaan uit het brein van onze oprichter Yann Tagakou. </p>\n<p>Opgericht in 2024, zijn we begonnen aan een reis om iedereen aan drank te voorzien. Sindsdien zijn we uitgegroeid tot een kleine startup die het halen wilt.</p>','<h2>Contact</h2>\n<p>Phone: +32494739154<br />Mail: TheVeryGoodDrinks@gmail.com</p>\n<p>Attenhovenstraat 47, 3400 Landen</p>',NULL,NULL),(151,151,1,'About us','2024-01-05 23:40:45','2024-01-05 23:40:45','97a6cc1a-30af-440d-83fe-8d159b5bd828',NULL,NULL,NULL,NULL,NULL,NULL,'<h2>Welkom</h2>\n<p>Welkom in THE VERY GOOD DRINKS – waar drank koning is. We zijn meer dan enkel een drank bedrijf; we zijn een hippe leuke en lekkere comunity met als missie het brengen van de lekkerste dranken.</p>','<h2>Ons verhaal</h2>\n<p>We zijn ontstaan uit het brein van onze oprichter Yann Tagakou. </p>\n<p>Opgericht in 2024, zijn we begonnen aan een reis om iedereen aan drank te voorzien. Sindsdien zijn we uitgegroeid tot een kleine startup die het halen wilt.</p>','<h2>Contact</h2>\n<p>Phone: +32494739154<br />Mail: TheVeryGoodDrinks@gmail.com</p>\n<p>Attenhovenstraat 47, 3400 Landen</p>',NULL,NULL),(152,152,1,'About us','2024-01-05 23:42:11','2024-01-05 23:42:11','71d81389-003b-476c-bdf6-8a9dad8a0965',NULL,NULL,NULL,NULL,NULL,NULL,'<h2>Welkom</h2>\n<p>Welkom in THE VERY GOOD DRINKS – waar drank koning is. We zijn meer dan enkel een drank bedrijf; we zijn een hippe leuke en lekkere comunity met als missie het brengen van de lekkerste dranken.</p>','<h2>Ons verhaal</h2>\n<p>We zijn ontstaan uit het brein van onze oprichter Yann Tagakou. </p>\n<p>Opgericht in 2024, zijn we begonnen aan een reis om iedereen aan drank te voorzien. Sindsdien zijn we uitgegroeid tot een kleine startup die het halen wilt.</p>','<h2>Contact</h2>\n<p>Phone: +32494739154<br />Mail: TheVeryGoodDrinks@gmail.com</p>\n<p>Attenhovenstraat 47, 3400 Landen</p>',NULL,NULL),(154,154,1,'About us','2024-01-05 23:43:40','2024-01-05 23:43:40','e5d6c57d-ca74-4a48-a4d0-7d8f449cfc6c',NULL,NULL,NULL,NULL,NULL,NULL,'<h2>Welkom</h2>\n<p>Welkom in THE VERY GOOD DRINKS – waar drank koning is. We zijn meer dan enkel een drank bedrijf; we zijn een hippe leuke en lekkere comunity met als missie het brengen van de lekkerste dranken.</p>','<h2>Ons verhaal</h2>\n<p>We zijn ontstaan uit het brein van onze oprichter Yann Tagakou. </p>\n<p>Opgericht in 2024, zijn we begonnen aan een reis om iedereen aan drank te voorzien. Sindsdien zijn we uitgegroeid tot een kleine startup die het halen wilt.</p>','<h2>Contact</h2>\n<p>Phone: +32494739154<br />Mail: TheVeryGoodDrinks@gmail.com</p>\n<p>Attenhovenstraat 47, 3400 Landen</p>',NULL,NULL),(155,155,1,'About us','2024-01-05 23:44:56','2024-01-05 23:44:56','5774bea6-9824-4486-847c-c7bd28980489',NULL,NULL,NULL,NULL,NULL,NULL,'<h2>Welkom</h2>\n<p>Welkom in THE VERY GOOD DRINKS – waar drank koning is. We zijn meer dan enkel een drank bedrijf; we zijn een hippe leuke en lekkere comunity met als missie het brengen van de lekkerste dranken.</p>','<h2>Ons verhaal</h2>\n<p>We zijn ontstaan uit het brein van onze oprichter Yann Tagakou. </p>\n<p>Opgericht in 2024, zijn we begonnen aan een reis om iedereen aan drank te voorzien. Sindsdien zijn we uitgegroeid tot een kleine startup die het halen wilt.</p>','<h2>Contact</h2>\n<p>Phone: +32494739154<br />Mail: TheVeryGoodDrinks@gmail.com</p>\n<p>Attenhovenstraat 47, 3400 Landen</p>',NULL,'<h1>About</h1>\n<h1>\"THE VERY GOOD DRINKS\"</h1>'),(157,157,1,'About us','2024-01-05 23:46:25','2024-01-05 23:46:25','9c576f04-465f-41e5-83ea-4df8eeb90f8e',NULL,NULL,NULL,NULL,NULL,NULL,'<h2>Welkom</h2>\n<p>Welkom in THE VERY GOOD DRINKS – waar drank koning is. We zijn meer dan enkel een drank bedrijf; we zijn een hippe leuke en lekkere comunity met als missie het brengen van de lekkerste dranken.</p>','<h2>Ons verhaal</h2>\n<p>We zijn ontstaan uit het brein van onze oprichter Yann Tagakou. </p>\n<p>Opgericht in 2024, zijn we begonnen aan een reis om iedereen aan drank te voorzien. Sindsdien zijn we uitgegroeid tot een kleine startup die het halen wilt.</p>','<h2>Contact</h2>\n<p>Phone: +32494739154<br />Mail: TheVeryGoodDrinks@gmail.com</p>\n<p>Attenhovenstraat 47, 3400 Landen</p>',NULL,'<h1>About</h1>\n<p> </p>\n<h1>\"THE VERY GOOD DRINKS\"</h1>'),(158,158,1,'home','2024-01-05 23:46:45','2024-01-05 23:46:45','5a968df5-8e2a-43f0-81fa-bfa11a21f8a8',NULL,NULL,NULL,NULL,NULL,NULL,'<h2>ons</h2>\n<div class=\"red\">\"Assortiment\"</div>\n<p>Heb jij een feest of denk je een kleine avond te organiseren. Twijfel dan zeker niet om ons assortiment te bekijken. We beloven je de beste kwaliteit aan dranken en de meeste keuze. Zowel met als zonder alcohol</p>','<h2>enkel</h2>\n<div class=\"red\">Alcohol</div>\n<p>Wil je je een avond organiseren met drank? Kijk dan zeker door ons assortiment met alcohol. Voor iedereen is er iets. <br /><br />Vergeet niet ons vakmanschap drink je met verstand.</p>','<h2>what we are all</h2>\n<div class=\"red\">About</div>\n<p>Eerst en vooral wij zijn de nummer 1 website in drankverkoop. Maar we zijn meer dan dat. Ondek dit allemaal.</p>',NULL,'<p>Welcome to</p>\n<div class=\"red\">\"The very good drinks\"</div>'),(160,160,1,'About us','2024-01-05 23:46:57','2024-01-05 23:46:57','14f05ff7-d894-4fe5-ad86-118dda50bd06',NULL,NULL,NULL,NULL,NULL,NULL,'<h2>Welkom</h2>\n<p>Welkom in THE VERY GOOD DRINKS – waar drank koning is. We zijn meer dan enkel een drank bedrijf; we zijn een hippe leuke en lekkere comunity met als missie het brengen van de lekkerste dranken.</p>','<h2>Ons verhaal</h2>\n<p>We zijn ontstaan uit het brein van onze oprichter Yann Tagakou. </p>\n<p>Opgericht in 2024, zijn we begonnen aan een reis om iedereen aan drank te voorzien. Sindsdien zijn we uitgegroeid tot een kleine startup die het halen wilt.</p>','<h2>Contact</h2>\n<p>Phone: +32494739154<br />Mail: TheVeryGoodDrinks@gmail.com</p>\n<p>Attenhovenstraat 47, 3400 Landen</p>',NULL,'<p>Welcome to</p>\n<div class=\"red\">\"The very good drinks\"</div>'),(162,162,1,'About us','2024-01-05 23:47:20','2024-01-05 23:47:20','a2dee390-1035-4ed0-ac93-0e132c9269b9',NULL,NULL,NULL,NULL,NULL,NULL,'<h2>Welkom</h2>\n<p>Welkom in THE VERY GOOD DRINKS – waar drank koning is. We zijn meer dan enkel een drank bedrijf; we zijn een hippe leuke en lekkere comunity met als missie het brengen van de lekkerste dranken.</p>','<h2>Ons verhaal</h2>\n<p>We zijn ontstaan uit het brein van onze oprichter Yann Tagakou. </p>\n<p>Opgericht in 2024, zijn we begonnen aan een reis om iedereen aan drank te voorzien. Sindsdien zijn we uitgegroeid tot een kleine startup die het halen wilt.</p>','<h2>Contact</h2>\n<p>Phone: +32494739154<br />Mail: TheVeryGoodDrinks@gmail.com</p>\n<p>Attenhovenstraat 47, 3400 Landen</p>',NULL,'<p>ABOUT</p>\n<div class=\"red\">\"The very good drinks\"</div>'),(163,163,1,'home','2024-01-05 23:49:07','2024-01-05 23:49:07','5fc14b9a-b112-4205-837f-3ab24ac43c51',NULL,NULL,NULL,NULL,NULL,NULL,'<h2>ons</h2>\n<div class=\"red\">\"Assortiment\"</div>\n<p>Heb jij een feest of denk je een kleine avond te organiseren. Twijfel dan zeker niet om ons assortiment te bekijken. We beloven je de beste kwaliteit aan dranken en de meeste keuze. Zowel met als zonder alcohol</p>','<h2>enkel</h2>\n<div class=\"red\">Alcohol</div>\n<p>Wil je je een avond organiseren met drank? Kijk dan zeker door ons assortiment met alcohol. Voor iedereen is er iets. <br /><br />Vergeet niet ons vakmanschap drink je met verstand.</p>','<h2>what we are all</h2>\n<div class=\"red\">About</div>\n<p>Eerst en vooral wij zijn de nummer 1 website in drankverkoop. Maar we zijn meer dan dat. Ondek dit allemaal.</p>',NULL,'<p>Welcome to</p>\n<div class=\"red\">\"The very good drinks\"</div>'),(165,165,1,'About us','2024-01-05 23:49:53','2024-01-05 23:49:53','fd039290-1dd5-40df-92bf-e9ebd0e1a346',NULL,NULL,NULL,NULL,NULL,NULL,'<div class=\"red\">Welkom</div>\n<p>Welkom in THE VERY GOOD DRINKS – waar drank koning is. We zijn meer dan enkel een drank bedrijf; we zijn een hippe leuke en lekkere comunity met als missie het brengen van de lekkerste dranken</p>','<h2>Ons verhaal</h2>\n<p>We zijn ontstaan uit het brein van onze oprichter Yann Tagakou. </p>\n<p>Opgericht in 2024, zijn we begonnen aan een reis om iedereen aan drank te voorzien. Sindsdien zijn we uitgegroeid tot een kleine startup die het halen wilt.</p>','<h2>Contact</h2>\n<p>Phone: +32494739154<br />Mail: TheVeryGoodDrinks@gmail.com</p>\n<p>Attenhovenstraat 47, 3400 Landen</p>',NULL,'<p>ABOUT</p>\n<div class=\"red\">\"The very good drinks\"</div>'),(166,166,1,'home','2024-01-05 23:51:07','2024-01-05 23:51:07','cf74bf60-1925-4bf0-9ce3-6e306758d237',NULL,NULL,NULL,NULL,NULL,NULL,'<h2>ons</h2>\n<div class=\"red\">\"Assortiment\"</div>\n<p>Heb jij een feest of denk je een kleine avond te organiseren. Twijfel dan zeker niet om ons assortiment te bekijken. We beloven je de beste kwaliteit aan dranken en de meeste keuze. Zowel met als zonder alcohol</p>','<h2>enkel</h2>\n<div class=\"red\">Alcohol</div>\n<p>Wil je je een avond organiseren met drank? Kijk dan zeker door ons assortiment met alcohol. Voor iedereen is er iets. <br /><br />Vergeet niet ons vakmanschap drink je met verstand.</p>','<h2>what we are all</h2>\n<div class=\"red\">About</div>\n<p>Eerst en vooral wij zijn de nummer 1 website in drankverkoop. Maar we zijn meer dan dat. Ondek dit allemaal.</p>',NULL,'<p>Welcome to</p>\n<div class=\"red\">\"The very good drinks\"</div>'),(168,168,1,'About us','2024-01-05 23:53:16','2024-01-05 23:53:16','847c871b-6617-43b8-8607-05d6be3c0c30',NULL,NULL,NULL,NULL,NULL,NULL,'<div class=\"red\">Welkom</div>\n<p>Welkom in THE VERY GOOD DRINKS – waar drank koning is. We zijn meer dan enkel een drank bedrijf; we zijn een hippe leuke en lekkere comunity met als missie het brengen van de lekkerste dranken</p>','<div class=\"red\">Ons verhaal</div>\n<p>We zijn ontstaan uit het brein van onze oprichter Yann Tagakou. <br />Opgericht in 2024, zijn we begonnen aan een reis om iedereen aan drank te voorzien. Sindsdien zijn we uitgegroeid tot een kleine startup die het halen wilt</p>','<div class=\"red\">Contact</div>\n<p>Phone: +32494739154<br />Mail: TheVeryGoodDrinks@gmail.com</p>\n<p>Attenhovenstraat 47, 3400 Landen</p>',NULL,'<p>ABOUT</p>\n<div class=\"red\">\"The very good drinks\"</div>'),(169,169,1,'Absolut vodka','2024-01-06 00:05:18','2024-01-06 00:05:22','00e59916-20d1-493d-8eaf-46f0ddea210e',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(170,170,1,'Fanta bb','2024-01-06 00:05:33','2024-01-06 00:05:36','a7b0146d-142b-4e8a-8394-5e410cdbd6e0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(171,171,1,'Jack daniels','2024-01-06 00:05:41','2024-01-06 00:05:44','e031ea6b-b708-4772-ac2f-cac7f62f9bf3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(172,172,1,'The famous grouse','2024-01-06 00:05:50','2024-01-06 00:05:54','89dabdce-4582-481a-846e-74bde5ac248c',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(173,173,1,'Smirnof vodka','2024-01-06 00:06:10','2024-01-06 00:06:14','f60ce2c4-d792-4966-a058-77fd031f3978',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(174,174,1,'Fanta BlueBerry 12','2024-01-06 00:07:35','2024-01-06 16:18:03','a0db6c23-1143-4db2-90fe-2695f24d39ab','<p>De eerste cola was Coca-Cola, een alcoholvrije imitatie door John Pemberton, van de Vin Mariani die door Angelo Mariani was bedacht</p>',NULL,10.30,0,'<p>Zoals je weet is het drinken van Fanta Orange, dankzij zijn authentieke smaak, een unieke ervaring! Maar wat je misschien nog niet wist, is dat, wanneer je Fanta Orange drinkt, je eigenlijk volop geniet van een drank met sinaasappelsap* met natuurlijke aroma’s. Welcome to the fun, natuurlijk!</p>\n<p>*Uit sapconcentraat</p>\n<p>**Fanta Orange recepten kunnen verschillen in Europa</p>',NULL,NULL,NULL,NULL,NULL,NULL),(176,176,1,'Coca-cola','2024-01-06 00:07:45','2024-01-06 16:18:03','cf26fdaa-b66a-47f8-964c-ae002e092fbe','<p>De eerste cola was Coca-Cola, een alcoholvrije imitatie door John Pemberton, van de Vin Mariani die door Angelo Mariani was bedacht.</p>',NULL,8.49,0,'<p>Op 8 mei 1886 serveerde Dr. John Styth Pemberton de eerste Coca‑Cola ter wereld in zijn apotheek in Atlanta, Georgia. Sinds dat eerste iconische drankje zijn we uitgegroeid tot een \'total beverage company\' - ons portfolio biedt voor ieder wat wils en dat voor elk moment van de dag.</p>\n<p>Dagelijks worden in meer dan 200 landen en regio\'s ruim 2,1 miljard van onze frisdranken gedronken. De 700.000 medewerkers van The Coca‑Cola Company en ruim 225 bottelpartners bezorgen de verfrissende dranken overal in de wereld.</p>',NULL,NULL,NULL,NULL,NULL,NULL),(178,178,1,'The Famous Grouse','2024-01-06 00:08:00','2024-01-06 16:18:03','32f4b65d-c504-4fe7-94d7-85cd73387c77','<p>Famous Grouse 1 liter is een Blended Scotch whisky die al jaren tot de meest verkochte in zijn soort behoort.</p>',NULL,25.94,37,'<p>amous Grouse, een Schotse whisky die bekend staat om zijn kwaliteit en verfijnde smaak, heeft wereldwijd een enorme populariteit verworven onder whisky-liefhebbers. Met zijn rijke geschiedenis, unieke smaak en effectieve marketingstrategie heeft Famous Grouse zich weten te positioneren als een van de meest geliefde whiskymerken ter wereld. Lees hier alles over Famouse Grouse whisky en kom erachter waarom dit merk zo succesvol is.</p>',NULL,NULL,NULL,NULL,NULL,NULL),(180,180,1,'Jack Daniels','2024-01-06 00:08:10','2024-01-06 16:18:03','c34c781f-ed4d-4e51-9b91-e5cb8e2a5c51','<p>Jack Daniels 1 is de meest populaire whiskey van het assortiment van dit geliefde Amerikaanse whiskeymerk.</p>',NULL,32.95,25,'<p>Sinds 1866 komt iedere druppel Jack Daniel’s whiskey uit het dorpje Lynchburg, diep op het platteland van Tennessee, Amerika. De Jack Daniel’s distilleerderij is de oudste geregistreerde distilleerderij van Amerika en is destijds begonnen door Jasper Newton ‘Jack’ Daniel.</p>\n<p>Jack Daniel\'s is, zoals de meesten denken, geen bourbon whiskey, maar Tennessee whiskey. De basisregels van bourbon of Amerikaanse whiskey worden gerespecteerd, maar daarnaast kent Jack Daniel’s whiskey een uniek extra element dat al sinds de oprichting van de distilleerderij (dit jaar 150 jaar geleden) wordt toegepast. De whiskey wordt na distillatie namelijk gefilterd door een drie meter dikke laag houtskool, wat zorgt voor de bekende zachtheid. Jack Daniel’s Tennessee Whiskey kent een licht fruitige mix van karamel, vanille, specerijen en geroosterd eiken. Aanbevolen drinkwijze is puur, on the rocks of gemixt met cola.</p>',NULL,NULL,NULL,NULL,NULL,NULL),(182,182,1,'Absolut vodka','2024-01-06 00:08:21','2024-01-06 16:18:03','71c3de21-59fb-4151-95a1-88597c935587','<p>Absolut Vodka 1 liter is de meest bekende wodka toebehorend aan dit Zweedse wodkamerk.</p>',NULL,20.95,35,'<p>Wodka is een kleurloos zuiver distillaat, vaak afkomstig uit Rusland, Polen of Zweden. Vodka heeft geen rijpingsproces zoals de meeste andere gedestilleerde dranken en behoort hierdoor tot een van de zuiverste van de familie. Doordat het destillaat wordt opgeslagen met houtskool, worden alle onreinheden geabsorbeerd. Wodka betekent in het Russisch \'watertje\', wodka is daar een afleiding van. Veel merken geven de voorkeur aan \'vodka\' omdat het er authentieker uit ziet, puur omwille van de marketing.</p>',NULL,NULL,NULL,NULL,NULL,NULL),(184,184,1,'Smirnoff vodka','2024-01-06 00:08:43','2024-01-06 16:18:03','4dff16c3-fc3f-432d-be9d-fedc3ef5af24','<p>Geniet je graag van Smirnoff Vodka? Kies dan voor deze Smirnoff Vodka 1 liter fles.</p>',NULL,20.95,40,'<p>Smirnoff No.21 is een iconische wodka die bekend staat om zijn unieke mix van graanalcohol en zuiver gedestilleerd water. De wodka wordt gemaakt van 100% graan en wordt gedistilleerd en gefilterd door middel van houtskool. Het resultaat is een zachte en zuivere wodka met een subtiele graansmaak en een licht peperige afdronk. Smirnoff is opgericht in Rusland in 1864 en heeft sindsdien een wereldwijde reputatie opgebouwd als een van de beste wodka-merken ter wereld. De Smirnoff No.21 is de meest populaire wodka van het merk en wordt wereldwijd verkocht.</p>',NULL,NULL,NULL,NULL,NULL,NULL),(185,185,1,'About frontpage','2024-01-06 00:17:49','2024-01-06 00:18:05','ddfba917-8e88-4f1e-91c3-6cb662af2575',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(186,186,1,'Apperitief','2024-01-06 00:17:51','2024-01-06 00:18:05','3b645d5a-c3c5-4d9a-a87d-46ef76dbd401',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(187,187,1,'Assortiment','2024-01-06 00:17:52','2024-01-06 00:18:05','c5154e7e-ebd1-46ec-893b-de22f452d1b9',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(188,188,1,'Bottle Jack','2024-01-06 00:17:55','2024-01-06 00:18:05','f050fce3-03f5-4cc6-a9bf-e87cfb6c6f30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(189,189,1,'Drinking orange','2024-01-06 00:17:57','2024-01-06 00:18:05','b9302305-8a0b-464d-810f-ea0282f141b9',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(190,190,1,'TVGD logo','2024-01-06 00:17:59','2024-01-06 00:18:05','300eaa89-d986-484a-9455-f813009eb475',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(191,191,1,'Led us her','2024-01-06 00:20:21','2024-01-06 00:21:15','759b697a-21ca-4393-b5b8-e67b8df46c1e',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(192,192,1,'Ons verhaal','2024-01-06 00:20:40','2024-01-06 00:21:16','ed30405a-2e41-435f-b9a2-9900a207319d',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(193,193,1,'Vereniging','2024-01-06 00:20:41','2024-01-06 00:21:16','6da76f15-3a84-4353-9bf7-7a4d31b81768',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(194,194,1,'About frontpage','2024-01-06 00:21:44','2024-01-06 00:21:48','dc23fa02-b96d-4ec0-8c0b-30f7e9564f94',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(196,196,1,'Fanta BlueBerry 12','2024-01-06 16:51:36','2024-01-06 16:51:36','52e49b5b-06d3-4550-9d89-3b23415fe685','<p>De eerste cola was FANTA, een alcoholvrije imitatie door John Pemberton, van de Vin Mariani die door Angelo Mariani was bedacht</p>',NULL,10.30,0,'<p>Zoals je weet is het drinken van Fanta Orange, dankzij zijn authentieke smaak, een unieke ervaring! Maar wat je misschien nog niet wist, is dat, wanneer je Fanta Orange drinkt, je eigenlijk volop geniet van een drank met sinaasappelsap* met natuurlijke aroma’s. Welcome to the fun, natuurlijk!</p>\n<p>*Uit sapconcentraat</p>\n<p>**Fanta Orange recepten kunnen verschillen in Europa</p>',NULL,NULL,NULL,NULL,NULL,NULL),(197,197,1,'home','2024-01-06 17:49:03','2024-01-06 17:49:03','f836e01e-4f2d-4c7a-8ca0-91e5b715d97d',NULL,NULL,NULL,NULL,NULL,NULL,'<h2>ons</h2>\n<div class=\"red\">\"Assortiment\"</div>\n<p>Heb jij een feest of denk je een kleine avond te organiseren. Twijfel dan zeker niet om ons assortiment te bekijken. We beloven je de beste kwaliteit aan dranken en de meeste keuze. Zowel met als zonder alcohol</p>','<h2>enkel</h2>\n<div class=\"red\">Alcohol</div>\n<p>Wil je je een avond organiseren met drank? Kijk dan zeker door ons assortiment met alcohol. Voor iedereen is er iets. <br /><br />Vergeet niet ons vakmanschap drink je met verstand.</p>','<h2>what we are all</h2>\n<div class=\"red\">About</div>\n<p>Eerst en vooral wij zijn de nummer 1 website in drankverkoop. Maar we zijn meer dan dat. Ondek dit allemaal.</p>',NULL,'<p>Welcome to</p>\n<div class=\"red\">\"The very good drinks\"</div>'),(198,198,1,'About us','2024-01-06 17:54:36','2024-01-06 17:54:36','5b46cfc6-9b3a-46dd-9b4a-d06c5a1ed7e6',NULL,NULL,NULL,NULL,NULL,NULL,'<div class=\"red\">Welkom</div>\n<p>Welkom in THE VERY GOOD DRINKS – waar drank koning is. We zijn meer dan enkel een drank bedrijf; we zijn een hippe leuke en lekkere comunity met als missie het brengen van de lekkerste dranken</p>','<div class=\"red\">Ons verhaal</div>\n<p>We zijn ontstaan uit het brein van onze oprichter Yann Tagakou. <br />Opgericht in 2024, zijn we begonnen aan een reis om iedereen aan drank te voorzien. Sindsdien zijn we uitgegroeid tot een kleine startup die het halen wilt</p>','<div class=\"red\">Contact</div>\n<p>Phone: +32494739154<br />Mail: TheVeryGoodDrinks@gmail.com</p>\n<p>Attenhovenstraat 47, 3400 Landen</p>',NULL,'<p>ABOUT</p>\n<div class=\"red\">\"The very good drinks\"</div>'),(199,199,1,'Passion led us here','2024-01-10 20:49:53','2024-01-10 20:49:53','e8834755-6307-4952-815c-0f7ac137c7a7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(200,200,1,'Ons vereniging','2024-01-10 20:50:20','2024-01-10 20:50:20','3c605aba-0c20-419f-8021-16286e4c4ab4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(201,201,1,'Drinks','2024-01-10 22:10:29','2024-01-10 22:10:35','7458a9cd-305f-4348-b6eb-557f2294c0df',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(202,202,1,'Drinks','2024-01-10 22:10:35','2024-01-10 22:10:35','1da74b7c-6082-45e5-bbd8-1aade69da685',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(203,203,1,'NADrinks','2024-01-10 22:10:43','2024-01-10 22:11:14','68c031f7-4a95-4596-82cf-173f362c204d',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(204,204,1,'nonAlcolische','2024-01-10 22:10:49','2024-01-10 22:10:49','7e1c2670-4470-44b7-99c7-d3035022767c',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(206,206,1,'NADrinks','2024-01-10 22:11:14','2024-01-10 22:11:14','ae96d7f7-0213-451e-a0a8-2a38ed21e6f2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(208,208,1,'Fanta BlueBerry 12','2024-01-10 22:12:43','2024-01-10 22:12:43','b2a02d6d-0713-4e93-abec-b0637fc7eb4c','<p>De eerste cola was FANTA, een alcoholvrije imitatie door John Pemberton, van de Vin Mariani die door Angelo Mariani was bedacht</p>',NULL,10.30,0,'<p>Zoals je weet is het drinken van Fanta Orange, dankzij zijn authentieke smaak, een unieke ervaring! Maar wat je misschien nog niet wist, is dat, wanneer je Fanta Orange drinkt, je eigenlijk volop geniet van een drank met sinaasappelsap* met natuurlijke aroma’s. Welcome to the fun, natuurlijk!</p>\n<p>*Uit sapconcentraat</p>\n<p>**Fanta Orange recepten kunnen verschillen in Europa</p>',NULL,NULL,NULL,NULL,NULL,NULL),(210,210,1,'Coca-cola','2024-01-10 22:12:57','2024-01-10 22:12:57','31d1e62f-fecd-4eaa-97ca-4bf005adfabf','<p>De eerste cola was Coca-Cola, een alcoholvrije imitatie door John Pemberton, van de Vin Mariani die door Angelo Mariani was bedacht.</p>',NULL,8.49,0,'<p>Op 8 mei 1886 serveerde Dr. John Styth Pemberton de eerste Coca‑Cola ter wereld in zijn apotheek in Atlanta, Georgia. Sinds dat eerste iconische drankje zijn we uitgegroeid tot een \'total beverage company\' - ons portfolio biedt voor ieder wat wils en dat voor elk moment van de dag.</p>\n<p>Dagelijks worden in meer dan 200 landen en regio\'s ruim 2,1 miljard van onze frisdranken gedronken. De 700.000 medewerkers van The Coca‑Cola Company en ruim 225 bottelpartners bezorgen de verfrissende dranken overal in de wereld.</p>',NULL,NULL,NULL,NULL,NULL,NULL),(212,212,1,'The Famous Grouse','2024-01-10 22:13:09','2024-01-10 22:13:09','e2a623a8-d482-4ae1-b0d7-7782382fd3b0','<p>Famous Grouse 1 liter is een Blended Scotch whisky die al jaren tot de meest verkochte in zijn soort behoort.</p>',NULL,25.94,37,'<p>amous Grouse, een Schotse whisky die bekend staat om zijn kwaliteit en verfijnde smaak, heeft wereldwijd een enorme populariteit verworven onder whisky-liefhebbers. Met zijn rijke geschiedenis, unieke smaak en effectieve marketingstrategie heeft Famous Grouse zich weten te positioneren als een van de meest geliefde whiskymerken ter wereld. Lees hier alles over Famouse Grouse whisky en kom erachter waarom dit merk zo succesvol is.</p>',NULL,NULL,NULL,NULL,NULL,NULL),(214,214,1,'Jack Daniels','2024-01-10 22:13:23','2024-01-10 22:13:23','91bac0d4-aace-4ad6-abc3-a340e1fef73d','<p>Jack Daniels 1 is de meest populaire whiskey van het assortiment van dit geliefde Amerikaanse whiskeymerk.</p>',NULL,32.95,25,'<p>Sinds 1866 komt iedere druppel Jack Daniel’s whiskey uit het dorpje Lynchburg, diep op het platteland van Tennessee, Amerika. De Jack Daniel’s distilleerderij is de oudste geregistreerde distilleerderij van Amerika en is destijds begonnen door Jasper Newton ‘Jack’ Daniel.</p>\n<p>Jack Daniel\'s is, zoals de meesten denken, geen bourbon whiskey, maar Tennessee whiskey. De basisregels van bourbon of Amerikaanse whiskey worden gerespecteerd, maar daarnaast kent Jack Daniel’s whiskey een uniek extra element dat al sinds de oprichting van de distilleerderij (dit jaar 150 jaar geleden) wordt toegepast. De whiskey wordt na distillatie namelijk gefilterd door een drie meter dikke laag houtskool, wat zorgt voor de bekende zachtheid. Jack Daniel’s Tennessee Whiskey kent een licht fruitige mix van karamel, vanille, specerijen en geroosterd eiken. Aanbevolen drinkwijze is puur, on the rocks of gemixt met cola.</p>',NULL,NULL,NULL,NULL,NULL,NULL),(216,216,1,'Absolut vodka','2024-01-10 22:13:37','2024-01-10 22:13:37','3e64959a-6ecc-4598-81b3-2c1f71f4148a','<p>Absolut Vodka 1 liter is de meest bekende wodka toebehorend aan dit Zweedse wodkamerk.</p>',NULL,20.95,35,'<p>Wodka is een kleurloos zuiver distillaat, vaak afkomstig uit Rusland, Polen of Zweden. Vodka heeft geen rijpingsproces zoals de meeste andere gedestilleerde dranken en behoort hierdoor tot een van de zuiverste van de familie. Doordat het destillaat wordt opgeslagen met houtskool, worden alle onreinheden geabsorbeerd. Wodka betekent in het Russisch \'watertje\', wodka is daar een afleiding van. Veel merken geven de voorkeur aan \'vodka\' omdat het er authentieker uit ziet, puur omwille van de marketing.</p>',NULL,NULL,NULL,NULL,NULL,NULL),(218,218,1,'Smirnoff vodka','2024-01-10 22:13:51','2024-01-10 22:13:51','2a405b95-5edc-4e50-aaa9-edbc7f743d2f','<p>Geniet je graag van Smirnoff Vodka? Kies dan voor deze Smirnoff Vodka 1 liter fles.</p>',NULL,20.95,40,'<p>Smirnoff No.21 is een iconische wodka die bekend staat om zijn unieke mix van graanalcohol en zuiver gedestilleerd water. De wodka wordt gemaakt van 100% graan en wordt gedistilleerd en gefilterd door middel van houtskool. Het resultaat is een zachte en zuivere wodka met een subtiele graansmaak en een licht peperige afdronk. Smirnoff is opgericht in Rusland in 1864 en heeft sindsdien een wereldwijde reputatie opgebouwd als een van de beste wodka-merken ter wereld. De Smirnoff No.21 is de meest populaire wodka van het merk en wordt wereldwijd verkocht.</p>',NULL,NULL,NULL,NULL,NULL,NULL),(219,219,1,'Fanta BlueBerry 12','2024-01-10 22:50:58','2024-01-10 22:50:58','95fcc207-7815-478b-9692-c35f15cec0e6','<p>De eerste cola was FANTA, een alcoholvrije imitatie door John Pemberton, van de Vin Mariani die door Angelo Mariani was bedacht</p>',NULL,10.30,0,'<p>Zoals je weet is het drinken van Fanta Orange, dankzij zijn authentieke smaak, een unieke ervaring! Maar wat je misschien nog niet wist, is dat, wanneer je Fanta Orange drinkt, je eigenlijk volop geniet van een drank met sinaasappelsap* met natuurlijke aroma’s. Welcome to the fun, natuurlijk!</p>\n<p>*Uit sapconcentraat</p>\n<p>**Fanta Orange recepten kunnen verschillen in Europa</p>',NULL,NULL,NULL,NULL,NULL,NULL),(220,220,1,'The Famous Grouse','2024-01-11 16:54:20','2024-01-11 16:54:20','bc706322-0668-4c4b-8ce4-a70f9b843df7','<p>Famous Grouse 1 liter is een Blended Scotch whisky die al jaren tot de meest verkochte in zijn soort behoort.</p>',NULL,25.94,37,'<p>amous Grouse, een Schotse whisky die bekend staat om zijn kwaliteit en verfijnde smaak, heeft wereldwijd een enorme populariteit verworven onder whisky-liefhebbers. Met zijn rijke geschiedenis, unieke smaak en effectieve marketingstrategie heeft Famous Grouse zich weten te positioneren als een van de meest geliefde whiskymerken ter wereld. Lees hier alles over Famouse Grouse whisky en kom erachter waarom dit merk zo succesvol is.</p>',NULL,NULL,NULL,NULL,NULL,NULL),(221,221,1,'The Famous Grouse','2024-01-11 16:54:20','2024-01-11 16:54:20','a71de926-a66f-4945-9c15-f89889731aad','<p>Famous Grouse 1 liter is een Blended Scotch whisky die al jaren tot de meest verkochte in zijn soort behoort.</p>',NULL,25.94,37,'<p>amous Grouse, een Schotse whisky die bekend staat om zijn kwaliteit en verfijnde smaak, heeft wereldwijd een enorme populariteit verworven onder whisky-liefhebbers. Met zijn rijke geschiedenis, unieke smaak en effectieve marketingstrategie heeft Famous Grouse zich weten te positioneren als een van de meest geliefde whiskymerken ter wereld. Lees hier alles over Famouse Grouse whisky en kom erachter waarom dit merk zo succesvol is.</p>',NULL,NULL,NULL,NULL,NULL,NULL),(223,223,1,'The Famous Grouse','2024-01-11 16:56:51','2024-01-11 16:56:51','d5c002e2-2d96-4290-8efd-37d6ab0795c7','<p>Famous Grouse 1 liter is een Blended Scotch whisky die al jaren tot de meest verkochte in zijn soort behoort.</p>',NULL,25.94,37,'<p>amous Grouse, een Schotse whisky die bekend staat om zijn kwaliteit en verfijnde smaak, heeft wereldwijd een enorme populariteit verworven onder whisky-liefhebbers. Met zijn rijke geschiedenis, unieke smaak en effectieve marketingstrategie heeft Famous Grouse zich weten te positioneren als een van de meest geliefde whiskymerken ter wereld. Lees hier alles over Famouse Grouse whisky en kom erachter waarom dit merk zo succesvol is.</p>',NULL,NULL,NULL,NULL,NULL,NULL),(225,225,1,'Jack Daniels','2024-01-11 16:57:22','2024-01-11 16:57:22','2b5e8e32-9be2-4e06-9f93-70059c150aba','<p>Jack Daniels 1 is de meest populaire whiskey van het assortiment van dit geliefde Amerikaanse whiskeymerk.</p>',NULL,32.95,25,'<p>Sinds 1866 komt iedere druppel Jack Daniel’s whiskey uit het dorpje Lynchburg, diep op het platteland van Tennessee, Amerika. De Jack Daniel’s distilleerderij is de oudste geregistreerde distilleerderij van Amerika en is destijds begonnen door Jasper Newton ‘Jack’ Daniel.</p>\n<p>Jack Daniel\'s is, zoals de meesten denken, geen bourbon whiskey, maar Tennessee whiskey. De basisregels van bourbon of Amerikaanse whiskey worden gerespecteerd, maar daarnaast kent Jack Daniel’s whiskey een uniek extra element dat al sinds de oprichting van de distilleerderij (dit jaar 150 jaar geleden) wordt toegepast. De whiskey wordt na distillatie namelijk gefilterd door een drie meter dikke laag houtskool, wat zorgt voor de bekende zachtheid. Jack Daniel’s Tennessee Whiskey kent een licht fruitige mix van karamel, vanille, specerijen en geroosterd eiken. Aanbevolen drinkwijze is puur, on the rocks of gemixt met cola.</p>',NULL,NULL,NULL,NULL,NULL,NULL),(227,227,1,'Absolut vodka','2024-01-11 16:57:38','2024-01-11 16:57:38','14e27274-75a8-4a95-b7da-1a2f6ab696f2','<p>Absolut Vodka 1 liter is de meest bekende wodka toebehorend aan dit Zweedse wodkamerk.</p>',NULL,20.95,35,'<p>Wodka is een kleurloos zuiver distillaat, vaak afkomstig uit Rusland, Polen of Zweden. Vodka heeft geen rijpingsproces zoals de meeste andere gedestilleerde dranken en behoort hierdoor tot een van de zuiverste van de familie. Doordat het destillaat wordt opgeslagen met houtskool, worden alle onreinheden geabsorbeerd. Wodka betekent in het Russisch \'watertje\', wodka is daar een afleiding van. Veel merken geven de voorkeur aan \'vodka\' omdat het er authentieker uit ziet, puur omwille van de marketing.</p>',NULL,NULL,NULL,NULL,NULL,NULL),(229,229,1,'Smirnoff vodka','2024-01-11 16:57:59','2024-01-11 16:57:59','65b18386-1a5f-453a-a1c5-25b2120f04d7','<p>Geniet je graag van Smirnoff Vodka? Kies dan voor deze Smirnoff Vodka 1 liter fles.</p>',NULL,20.95,40,'<p>Smirnoff No.21 is een iconische wodka die bekend staat om zijn unieke mix van graanalcohol en zuiver gedestilleerd water. De wodka wordt gemaakt van 100% graan en wordt gedistilleerd en gefilterd door middel van houtskool. Het resultaat is een zachte en zuivere wodka met een subtiele graansmaak en een licht peperige afdronk. Smirnoff is opgericht in Rusland in 1864 en heeft sindsdien een wereldwijde reputatie opgebouwd als een van de beste wodka-merken ter wereld. De Smirnoff No.21 is de meest populaire wodka van het merk en wordt wereldwijd verkocht.</p>',NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craftidtokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_hdmzynncpyeakfjfxvxmemcqniifdxsjenwd` (`userId`),
  CONSTRAINT `fk_hdmzynncpyeakfjfxvxmemcqniifdxsjenwd` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deprecationerrors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint unsigned DEFAULT NULL,
  `message` text,
  `traces` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_vpgcsqibujxyhdenetiehdqxcyszmhszsxmt` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drafts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `creatorId` int DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `notes` text,
  `trackChanges` tinyint(1) NOT NULL DEFAULT '0',
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_rqapnhkgkvrnhltbmqzzgqmbfprlxqqqokqv` (`creatorId`,`provisional`),
  KEY `idx_hvdnhafdyamsqshxrhvbrsbyhozgzyjaiswd` (`saved`),
  KEY `fk_ojxcgavholqpehgleyoemdxnzucgxljhetkm` (`canonicalId`),
  CONSTRAINT `fk_ijqjvofhhkhbylvekzjvhjwdzjfkbgsflrwz` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ojxcgavholqpehgleyoemdxnzucgxljhetkm` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
INSERT INTO `drafts` VALUES (1,NULL,1,0,'First draft',NULL,0,NULL,1),(2,NULL,1,0,'First draft',NULL,0,NULL,1);
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elementactivity`
--

DROP TABLE IF EXISTS `elementactivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elementactivity` (
  `elementId` int NOT NULL,
  `userId` int NOT NULL,
  `siteId` int NOT NULL,
  `draftId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`elementId`,`userId`,`type`),
  KEY `idx_uwcesyrnxwdmkgexzpkmccwwprenttotpbvh` (`elementId`,`timestamp`,`userId`),
  KEY `fk_zlmospdkbimtqcimyyfbbxjdvusmmliewbjy` (`userId`),
  KEY `fk_egtzsbmbpktpfeeimzekyukoydvjupvkecul` (`siteId`),
  KEY `fk_iejgugqcmkwxjhypbjnvgouyxvlqwxqptgra` (`draftId`),
  CONSTRAINT `fk_bkdpjqeuffjaiqlapfcgpglxrykwfkvuuqua` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_egtzsbmbpktpfeeimzekyukoydvjupvkecul` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_iejgugqcmkwxjhypbjnvgouyxvlqwxqptgra` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zlmospdkbimtqcimyyfbbxjdvusmmliewbjy` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elementactivity`
--

LOCK TABLES `elementactivity` WRITE;
/*!40000 ALTER TABLE `elementactivity` DISABLE KEYS */;
INSERT INTO `elementactivity` VALUES (3,1,1,NULL,'edit','2024-01-05 23:53:14'),(3,1,1,NULL,'save','2024-01-05 23:53:16'),(16,1,1,NULL,'edit','2024-01-05 19:19:10'),(16,1,1,NULL,'save','2024-01-05 23:51:07'),(92,1,1,NULL,'edit','2024-01-11 16:57:56'),(92,1,1,NULL,'save','2024-01-11 16:57:59'),(94,1,1,NULL,'edit','2024-01-11 16:57:35'),(94,1,1,NULL,'save','2024-01-11 16:57:38'),(102,1,1,NULL,'edit','2024-01-11 16:57:22'),(102,1,1,NULL,'save','2024-01-11 16:57:22'),(111,1,1,NULL,'edit','2024-01-11 16:56:49'),(111,1,1,NULL,'save','2024-01-11 16:56:51'),(113,1,1,NULL,'edit','2024-01-10 22:12:55'),(113,1,1,NULL,'save','2024-01-10 22:12:57'),(117,1,1,NULL,'edit','2024-01-10 22:12:41'),(117,1,1,NULL,'save','2024-01-10 22:50:58'),(201,1,1,NULL,'save','2024-01-10 22:10:35'),(203,1,1,NULL,'edit','2024-01-10 22:11:13'),(203,1,1,NULL,'save','2024-01-10 22:11:14');
/*!40000 ALTER TABLE `elementactivity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `draftId` int DEFAULT NULL,
  `revisionId` int DEFAULT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qzoxsdhfhakextqvsslwbafrjaunqxsrxrcf` (`dateDeleted`),
  KEY `idx_lhxitqhtklsodbgussgabqpfynnunqxsmrmz` (`fieldLayoutId`),
  KEY `idx_uhesnyfjqzzxgueqfmaiihetcftotvwcwwvb` (`type`),
  KEY `idx_hbkqbsbqxiefcjflrkgpcfpwdhtlqifjfbza` (`enabled`),
  KEY `idx_eoqqjpxbdedzfuswxziiephntrpffxowiylq` (`canonicalId`),
  KEY `idx_hzbfezbfxceslgqfgdacgqdvorfiletnzyhl` (`archived`,`dateCreated`),
  KEY `idx_rpyvqtlmhubszledpmkbfssndzdpcngrurlo` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `idx_qzzywacgyvfdvqbxviaajdrbsuwaxkwgywkg` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `fk_ciiiwmsrezqrodqniyckjhsilfchvxvcbomx` (`draftId`),
  KEY `fk_mkrizkqavppgffysxtxghujtgwawechtzkzv` (`revisionId`),
  CONSTRAINT `fk_cchbfutmgxujnmjqmzqquxorhhykuyuqyett` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ciiiwmsrezqrodqniyckjhsilfchvxvcbomx` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mkrizkqavppgffysxtxghujtgwawechtzkzv` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rnetxnydnbledrdgmdynlcboudesghebtquz` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=230 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
INSERT INTO `elements` VALUES (1,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2023-12-26 19:45:34','2023-12-26 19:45:34',NULL,NULL,'b46a111d-14c5-4a10-8e92-a71c94f0d91e'),(2,NULL,1,NULL,1,'craft\\elements\\Entry',1,0,'2024-01-05 15:27:20','2024-01-05 15:27:20',NULL,'2024-01-06 00:34:14','4322d09e-0b8d-45af-bad7-dc625f8ca3ef'),(3,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2024-01-05 15:47:11','2024-01-06 17:54:36',NULL,NULL,'200148ec-a0bc-4faa-a066-657a6a60ed7f'),(4,3,NULL,1,3,'craft\\elements\\Entry',1,0,'2024-01-05 15:47:11','2024-01-05 15:47:11',NULL,NULL,'cdd5d378-3c96-4198-b427-48754476a654'),(5,3,NULL,2,3,'craft\\elements\\Entry',1,0,'2024-01-05 15:47:11','2024-01-05 15:47:11',NULL,NULL,'6c8e896a-1a5b-4c39-b297-74d65feb6307'),(6,NULL,2,NULL,1,'craft\\elements\\Entry',1,0,'2024-01-05 16:35:03','2024-01-05 16:35:03',NULL,'2024-01-06 00:34:14','096543e6-9d00-488d-908e-bcdc01650df8'),(7,3,NULL,3,3,'craft\\elements\\Entry',1,0,'2024-01-05 17:04:19','2024-01-05 17:04:19',NULL,NULL,'502f4d04-5b34-43f0-a53f-c86e1aba5a15'),(8,3,NULL,4,3,'craft\\elements\\Entry',1,0,'2024-01-05 17:06:33','2024-01-05 17:06:33',NULL,NULL,'badb02b8-f7ea-49c7-9e24-4805ba1377c6'),(9,3,NULL,5,3,'craft\\elements\\Entry',1,0,'2024-01-05 17:07:12','2024-01-05 17:07:12',NULL,NULL,'b7d0daff-bce1-4df9-87b6-d1942f327b47'),(10,3,NULL,6,3,'craft\\elements\\Entry',1,0,'2024-01-05 17:07:36','2024-01-05 17:07:36',NULL,NULL,'7ae33be3-4131-4013-8652-bc48aa547704'),(11,3,NULL,7,3,'craft\\elements\\Entry',1,0,'2024-01-05 17:07:36','2024-01-05 17:07:36',NULL,NULL,'759ea81a-a235-4325-bd67-592e4240fa9f'),(12,3,NULL,8,3,'craft\\elements\\Entry',1,0,'2024-01-05 17:08:38','2024-01-05 17:08:38',NULL,NULL,'d49a03dd-f048-4584-90f0-e07a6f676424'),(13,3,NULL,9,3,'craft\\elements\\Entry',1,0,'2024-01-05 17:08:38','2024-01-05 17:08:38',NULL,NULL,'002c775b-cf4e-474f-be5d-35d9ac3f209c'),(14,3,NULL,10,3,'craft\\elements\\Entry',1,0,'2024-01-05 17:09:15','2024-01-05 17:09:15',NULL,NULL,'47f01ed0-107d-4719-8d20-7537b231ec50'),(15,3,NULL,11,3,'craft\\elements\\Entry',1,0,'2024-01-05 17:09:15','2024-01-05 17:09:15',NULL,NULL,'eb6770df-d701-4759-a9f7-0d56af300c90'),(16,NULL,NULL,NULL,5,'craft\\elements\\Entry',1,0,'2024-01-05 17:43:07','2024-01-06 17:49:03',NULL,NULL,'133a62f0-6cc4-42b8-9edc-6adc68839d99'),(23,16,NULL,17,5,'craft\\elements\\Entry',1,0,'2024-01-05 17:55:32','2024-01-05 17:55:32',NULL,NULL,'c074c695-201c-4813-8e39-4f9f68ef3373'),(24,16,NULL,18,5,'craft\\elements\\Entry',1,0,'2024-01-05 17:57:01','2024-01-05 17:57:01',NULL,NULL,'6ec11c93-7210-43af-8780-29b0e6ce4e5b'),(26,16,NULL,19,5,'craft\\elements\\Entry',1,0,'2024-01-05 17:59:13','2024-01-05 17:59:13',NULL,NULL,'65af24c7-db73-43dd-b5f2-153c5b15a437'),(27,16,NULL,20,5,'craft\\elements\\Entry',1,0,'2024-01-05 18:03:07','2024-01-05 18:03:07',NULL,NULL,'69aa0cd1-be85-4e46-9c8c-bf3e7a8b7d8a'),(29,16,NULL,21,5,'craft\\elements\\Entry',1,0,'2024-01-05 18:04:26','2024-01-05 18:04:26',NULL,NULL,'6f1bccb0-7102-4ddb-bb29-4634f5461682'),(30,16,NULL,22,5,'craft\\elements\\Entry',1,0,'2024-01-05 18:04:59','2024-01-05 18:04:59',NULL,NULL,'973fa048-7676-418e-aaa4-5c407fc6b086'),(32,16,NULL,23,5,'craft\\elements\\Entry',1,0,'2024-01-05 18:06:05','2024-01-05 18:06:05',NULL,NULL,'2a3b91e7-db37-48c3-9c36-3db4ac55ccf0'),(34,16,NULL,24,5,'craft\\elements\\Entry',1,0,'2024-01-05 18:06:29','2024-01-05 18:06:29',NULL,NULL,'ff0a3607-fcd6-49fa-b79f-0142929e5895'),(36,16,NULL,25,5,'craft\\elements\\Entry',1,0,'2024-01-05 18:07:13','2024-01-05 18:07:13',NULL,NULL,'65031b17-0ee9-4fa6-a4b7-35c568b59719'),(38,16,NULL,26,5,'craft\\elements\\Entry',1,0,'2024-01-05 18:07:44','2024-01-05 18:07:44',NULL,NULL,'a8dd89cc-2fda-4c3e-995b-c5d0d5bdffc8'),(40,16,NULL,27,5,'craft\\elements\\Entry',1,0,'2024-01-05 18:09:56','2024-01-05 18:09:56',NULL,NULL,'0173da31-b039-4577-9f59-36084f982294'),(41,16,NULL,28,5,'craft\\elements\\Entry',1,0,'2024-01-05 18:10:11','2024-01-05 18:10:11',NULL,NULL,'8c115494-9bc8-4810-b6fd-cc85b70b1c2e'),(43,16,NULL,29,5,'craft\\elements\\Entry',1,0,'2024-01-05 18:11:25','2024-01-05 18:11:25',NULL,NULL,'6668126a-bb90-4bf2-996d-34fdb29107b2'),(45,16,NULL,30,5,'craft\\elements\\Entry',1,0,'2024-01-05 18:11:41','2024-01-05 18:11:41',NULL,NULL,'5c16c2af-2016-42f2-9145-ddb07d987c9e'),(47,16,NULL,31,5,'craft\\elements\\Entry',1,0,'2024-01-05 18:11:53','2024-01-05 18:11:53',NULL,NULL,'fd0547d8-e53c-42e8-b8b3-5751bfc84ab1'),(49,16,NULL,32,5,'craft\\elements\\Entry',1,0,'2024-01-05 18:13:04','2024-01-05 18:13:04',NULL,NULL,'9613d138-ee60-42f2-a073-415822daa0de'),(50,16,NULL,33,5,'craft\\elements\\Entry',1,0,'2024-01-05 18:19:48','2024-01-05 18:19:48',NULL,NULL,'12283867-e131-409d-826e-0517daf0df53'),(52,16,NULL,34,5,'craft\\elements\\Entry',1,0,'2024-01-05 18:30:39','2024-01-05 18:30:39',NULL,NULL,'5dc22448-45e6-4726-82a4-9241365a7ed7'),(54,16,NULL,35,5,'craft\\elements\\Entry',1,0,'2024-01-05 18:35:14','2024-01-05 18:35:14',NULL,NULL,'30469abf-4f8b-43eb-8de6-467f29cf735c'),(56,16,NULL,36,5,'craft\\elements\\Entry',1,0,'2024-01-05 18:36:54','2024-01-05 18:36:54',NULL,NULL,'12d63966-c904-40a9-973e-3567c668234a'),(58,16,NULL,37,5,'craft\\elements\\Entry',1,0,'2024-01-05 18:38:52','2024-01-05 18:38:52',NULL,NULL,'bbfd7734-8e24-4ae7-84f2-a545aae25b01'),(59,16,NULL,38,5,'craft\\elements\\Entry',1,0,'2024-01-05 18:39:34','2024-01-05 18:39:34',NULL,NULL,'199034f7-e50a-4db1-92b3-0b4d91aa7a63'),(61,16,NULL,39,5,'craft\\elements\\Entry',0,0,'2024-01-05 18:41:10','2024-01-05 18:41:10',NULL,NULL,'1eec8a58-b0ba-4fd3-bd4c-fde9431aa12c'),(62,16,NULL,40,5,'craft\\elements\\Entry',0,0,'2024-01-05 18:44:28','2024-01-05 18:44:28',NULL,NULL,'013863b0-2dc2-455b-abd3-347e8b67dc39'),(64,16,NULL,41,5,'craft\\elements\\Entry',1,0,'2024-01-05 18:44:43','2024-01-05 18:44:43',NULL,NULL,'4ca44ccc-a10a-44b6-ab23-01165e73bab6'),(66,16,NULL,42,5,'craft\\elements\\Entry',1,0,'2024-01-05 18:47:42','2024-01-05 18:47:43',NULL,NULL,'218807eb-a45b-43ef-b912-d646b2d74e17'),(67,16,NULL,43,5,'craft\\elements\\Entry',1,0,'2024-01-05 18:50:21','2024-01-05 18:50:21',NULL,NULL,'cac58381-23aa-498e-9681-55ab04bd3026'),(69,16,NULL,44,5,'craft\\elements\\Entry',1,0,'2024-01-05 18:54:05','2024-01-05 18:54:05',NULL,NULL,'e909cd82-b817-43c8-8469-9a96aa9d7028'),(71,16,NULL,45,5,'craft\\elements\\Entry',1,0,'2024-01-05 18:55:34','2024-01-05 18:55:34',NULL,NULL,'e13175ab-acb6-4436-b261-545a1769255a'),(73,16,NULL,46,5,'craft\\elements\\Entry',1,0,'2024-01-05 18:56:27','2024-01-05 18:56:27',NULL,NULL,'c5a81eff-f19d-44b4-9f52-c62099cc059f'),(74,16,NULL,47,5,'craft\\elements\\Entry',1,0,'2024-01-05 18:58:08','2024-01-05 18:58:08',NULL,NULL,'c1f8851a-ccfc-496a-8cd7-ecdc549680d9'),(76,16,NULL,48,5,'craft\\elements\\Entry',1,0,'2024-01-05 18:58:39','2024-01-05 18:58:39',NULL,NULL,'6a58c43c-3cb3-40a2-b8e0-2798a9b586a3'),(77,16,NULL,49,5,'craft\\elements\\Entry',1,0,'2024-01-05 18:59:02','2024-01-05 18:59:02',NULL,NULL,'83eb4060-8160-44a6-a72f-56dd66567df6'),(79,16,NULL,50,5,'craft\\elements\\Entry',1,0,'2024-01-05 18:59:40','2024-01-05 18:59:40',NULL,NULL,'66f1c45f-f2c7-4af1-8e8f-c61db1c543dc'),(81,16,NULL,51,5,'craft\\elements\\Entry',1,0,'2024-01-05 19:04:51','2024-01-05 19:04:51',NULL,NULL,'ab8baa6e-3e7b-4594-aca5-684a88afca7a'),(83,16,NULL,52,5,'craft\\elements\\Entry',1,0,'2024-01-05 19:08:12','2024-01-05 19:08:12',NULL,NULL,'64402d89-e0d4-4eff-ad3e-75d50d5b3230'),(85,16,NULL,53,5,'craft\\elements\\Entry',1,0,'2024-01-05 19:10:27','2024-01-05 19:10:27',NULL,NULL,'01688ce2-491b-4bd9-a271-9fb2a6a03612'),(87,16,NULL,54,5,'craft\\elements\\Entry',1,0,'2024-01-05 19:13:45','2024-01-05 19:13:45',NULL,NULL,'e4663b71-f385-4f1c-a00d-37af8ca79092'),(89,16,NULL,55,5,'craft\\elements\\Entry',1,0,'2024-01-05 19:15:28','2024-01-05 19:15:28',NULL,NULL,'ca95f5a7-04d8-439c-a6d1-9785596719e5'),(91,16,NULL,56,5,'craft\\elements\\Entry',1,0,'2024-01-05 19:19:58','2024-01-05 19:19:58',NULL,NULL,'36165321-7440-46d2-a354-c052c417d20b'),(92,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-01-05 21:45:37','2024-01-11 16:57:59',NULL,NULL,'46b3351d-c4db-4b03-84c2-317036b05ef6'),(93,92,NULL,57,1,'craft\\elements\\Entry',1,0,'2024-01-05 21:48:48','2024-01-05 21:48:48',NULL,NULL,'837578ef-b830-468d-9467-b4cc5fe00c33'),(94,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-01-05 21:48:58','2024-01-11 16:57:38',NULL,NULL,'e0c3ad68-b221-4d2b-838b-0bf65a27ee48'),(95,94,NULL,58,1,'craft\\elements\\Entry',1,0,'2024-01-05 21:49:16','2024-01-05 21:49:16',NULL,NULL,'9692a76f-9a56-486f-876e-19258d9fcf53'),(97,94,NULL,59,1,'craft\\elements\\Entry',1,0,'2024-01-05 21:49:33','2024-01-05 21:49:33',NULL,NULL,'79e36e1d-8db1-408f-b350-c7c199d4b58c'),(99,92,NULL,60,1,'craft\\elements\\Entry',1,0,'2024-01-05 21:49:46','2024-01-05 21:49:46',NULL,NULL,'5bc4aca3-9a53-4001-9bed-8fc5ffea51ff'),(101,94,NULL,61,1,'craft\\elements\\Entry',1,0,'2024-01-05 21:50:46','2024-01-05 21:50:46',NULL,NULL,'23fec74c-0de0-446f-865a-1c676751a1e9'),(102,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-01-05 21:51:41','2024-01-11 16:57:22',NULL,NULL,'13a243c4-0271-4c90-a1e3-c40036fe31e0'),(103,102,NULL,62,1,'craft\\elements\\Entry',1,0,'2024-01-05 21:52:00','2024-01-05 21:52:00',NULL,NULL,'83335b67-5dcd-4644-ad70-fbc6608e49fd'),(105,102,NULL,63,1,'craft\\elements\\Entry',1,0,'2024-01-05 21:52:55','2024-01-05 21:52:55',NULL,NULL,'4e0409ea-619e-4c67-890e-40c1a7c2cd4b'),(106,94,NULL,64,1,'craft\\elements\\Entry',1,0,'2024-01-05 21:53:12','2024-01-05 21:53:12',NULL,NULL,'cd387acc-4514-4620-91c3-2e12446c6d44'),(108,92,NULL,65,1,'craft\\elements\\Entry',1,0,'2024-01-05 21:53:23','2024-01-05 21:53:23',NULL,NULL,'9c1a07e1-b819-4d7c-a16c-0fe512280c9a'),(109,94,NULL,66,1,'craft\\elements\\Entry',1,0,'2024-01-05 21:54:00','2024-01-05 21:54:00',NULL,NULL,'770a8271-726f-42c7-a58e-9fc3d04113f9'),(111,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-01-05 21:54:13','2024-01-11 16:56:50',NULL,NULL,'3b81b022-112d-4203-8422-81bd9e0b95d4'),(112,111,NULL,67,1,'craft\\elements\\Entry',1,0,'2024-01-05 21:55:59','2024-01-05 21:55:59',NULL,NULL,'beef05b6-3426-4809-a066-3ae8f03bc72c'),(113,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-01-05 21:56:14','2024-01-10 22:12:57',NULL,NULL,'32afb50b-1e90-4c38-9050-d5770fc1f582'),(114,113,NULL,68,1,'craft\\elements\\Entry',1,0,'2024-01-05 21:56:25','2024-01-05 21:56:25',NULL,NULL,'d46f6ebb-5b3d-49ef-920a-b57f2222c029'),(116,113,NULL,69,1,'craft\\elements\\Entry',1,0,'2024-01-05 21:57:23','2024-01-05 21:57:23',NULL,NULL,'d9e4e569-79b7-4e52-b89d-ef5d01835e1b'),(117,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-01-05 21:57:27','2024-01-10 22:50:58',NULL,NULL,'24054e84-eb23-4a27-8c8a-dae6ae3ca2d5'),(118,117,NULL,70,1,'craft\\elements\\Entry',1,0,'2024-01-05 21:59:07','2024-01-05 21:59:07',NULL,NULL,'a2c2380f-0d8a-478b-bba7-6633fc903eb3'),(120,111,NULL,71,2,'craft\\elements\\Entry',1,0,'2024-01-05 21:59:16','2024-01-05 21:59:16',NULL,NULL,'dfe1a797-950e-4f1b-9910-2115cd80818b'),(121,111,NULL,72,2,'craft\\elements\\Entry',1,0,'2024-01-05 21:59:22','2024-01-05 21:59:22',NULL,NULL,'ed8e1a93-b80c-4b4c-8e0c-30416aff833e'),(123,102,NULL,73,2,'craft\\elements\\Entry',1,0,'2024-01-05 21:59:31','2024-01-05 21:59:31',NULL,NULL,'dd223bfb-9264-4a5b-bf12-e9af3eabd941'),(125,92,NULL,74,2,'craft\\elements\\Entry',1,0,'2024-01-05 21:59:48','2024-01-05 21:59:48',NULL,NULL,'e2933d00-e40f-4453-8280-66891c278976'),(126,102,NULL,75,2,'craft\\elements\\Entry',1,0,'2024-01-05 21:59:53','2024-01-05 21:59:53',NULL,NULL,'53d90691-fa8d-4d6f-8654-e8f08918d079'),(127,92,NULL,76,2,'craft\\elements\\Entry',1,0,'2024-01-05 21:59:58','2024-01-05 21:59:58',NULL,NULL,'3240f2a7-8992-43db-9215-c83ad0aa859a'),(128,111,NULL,77,2,'craft\\elements\\Entry',1,0,'2024-01-05 22:00:04','2024-01-05 22:00:04',NULL,NULL,'2798c4a5-a54a-46ac-b2c4-1c1c262cee44'),(129,102,NULL,78,2,'craft\\elements\\Entry',1,0,'2024-01-05 22:00:07','2024-01-05 22:00:07',NULL,NULL,'04b3b7d1-d058-41c5-9e47-29ba3a7a78c1'),(130,94,NULL,79,2,'craft\\elements\\Entry',1,0,'2024-01-05 22:00:14','2024-01-05 22:00:14',NULL,NULL,'a018808b-9dfb-4465-975c-4c7e0f359ffb'),(131,117,NULL,80,1,'craft\\elements\\Entry',1,0,'2024-01-05 22:01:12','2024-01-05 22:01:12',NULL,NULL,'8bb1d0cd-3f6a-4647-b14c-ad9c63740d78'),(133,117,NULL,81,1,'craft\\elements\\Entry',1,0,'2024-01-05 22:10:26','2024-01-05 22:10:26',NULL,NULL,'475fd02a-3706-4136-8e82-cebe1f68993f'),(134,NULL,NULL,NULL,2,'craft\\elements\\Entry',1,0,'2024-01-05 22:19:55','2024-01-05 22:19:55',NULL,'2024-01-05 22:20:17','feaf682e-cf93-40b0-9a11-e8215bbd4a65'),(135,134,NULL,82,2,'craft\\elements\\Entry',1,0,'2024-01-05 22:19:55','2024-01-05 22:19:55',NULL,'2024-01-05 22:20:17','ccd58f52-30d6-4734-909e-60ed367bc653'),(137,16,NULL,83,5,'craft\\elements\\Entry',1,0,'2024-01-05 22:37:19','2024-01-05 22:37:19',NULL,NULL,'f914536e-d0fb-476e-88fb-b4b585db30ea'),(138,16,NULL,84,5,'craft\\elements\\Entry',1,0,'2024-01-05 22:37:19','2024-01-05 22:37:19',NULL,NULL,'470ce70b-0aef-41cf-89a3-b7bb6460023b'),(139,16,NULL,85,5,'craft\\elements\\Entry',1,0,'2024-01-05 22:37:54','2024-01-05 22:37:54',NULL,NULL,'d870bf75-d9be-45ff-81c0-4e11ad5afb57'),(140,16,NULL,86,5,'craft\\elements\\Entry',1,0,'2024-01-05 22:37:54','2024-01-05 22:37:54',NULL,NULL,'a30f8dad-f11a-40de-901c-77813a443fb8'),(141,16,NULL,87,5,'craft\\elements\\Entry',1,0,'2024-01-05 22:38:56','2024-01-05 22:38:56',NULL,NULL,'eb7b4dd9-739c-4546-89dd-52f01ab95cd6'),(142,16,NULL,88,5,'craft\\elements\\Entry',1,0,'2024-01-05 22:38:56','2024-01-05 22:38:56',NULL,NULL,'387d1114-7d99-48f8-a906-4348f4570705'),(143,NULL,NULL,NULL,8,'craft\\elements\\Asset',1,0,'2024-01-05 23:21:27','2024-01-05 23:21:38',NULL,NULL,'0d59ac1a-555e-495b-ac91-106b0ff01045'),(144,3,NULL,89,3,'craft\\elements\\Entry',1,0,'2024-01-05 23:32:48','2024-01-05 23:32:48',NULL,NULL,'b686f03f-3db1-4160-b907-6976d56b4851'),(146,3,NULL,90,3,'craft\\elements\\Entry',1,0,'2024-01-05 23:38:13','2024-01-05 23:38:13',NULL,NULL,'bea48d7a-1732-44af-9902-000e632520e4'),(147,3,NULL,91,3,'craft\\elements\\Entry',1,0,'2024-01-05 23:39:11','2024-01-05 23:39:11',NULL,NULL,'651b127d-1447-44ad-90bf-ec0cfb5a0d56'),(149,3,NULL,92,3,'craft\\elements\\Entry',1,0,'2024-01-05 23:40:25','2024-01-05 23:40:25',NULL,NULL,'e8d59692-5e63-4462-a55e-4bb742356ce5'),(151,3,NULL,93,3,'craft\\elements\\Entry',1,0,'2024-01-05 23:40:45','2024-01-05 23:40:45',NULL,NULL,'e16524d5-95dd-4eca-bc28-97d6b403a001'),(152,3,NULL,94,3,'craft\\elements\\Entry',1,0,'2024-01-05 23:42:11','2024-01-05 23:42:11',NULL,NULL,'a5860331-77b1-4b9d-8bf6-ea2a35976b3f'),(154,3,NULL,95,3,'craft\\elements\\Entry',1,0,'2024-01-05 23:43:40','2024-01-05 23:43:40',NULL,NULL,'b10c1df0-f14a-43e5-917d-4474713b6a1c'),(155,3,NULL,96,3,'craft\\elements\\Entry',1,0,'2024-01-05 23:44:56','2024-01-05 23:44:56',NULL,NULL,'20e42018-c5cc-4d0d-ada8-4c22f19fd3f8'),(157,3,NULL,97,3,'craft\\elements\\Entry',1,0,'2024-01-05 23:46:25','2024-01-05 23:46:25',NULL,NULL,'171149cd-3d9e-4f0f-a4c2-33a8329f04a8'),(158,16,NULL,98,5,'craft\\elements\\Entry',1,0,'2024-01-05 23:46:45','2024-01-05 23:46:45',NULL,NULL,'a7f16d03-7360-49b0-8e0f-cf8f0a43b27b'),(160,3,NULL,99,3,'craft\\elements\\Entry',1,0,'2024-01-05 23:46:57','2024-01-05 23:46:57',NULL,NULL,'5569e8c1-a167-4a34-9393-cd0a6f9faf04'),(162,3,NULL,100,3,'craft\\elements\\Entry',1,0,'2024-01-05 23:47:20','2024-01-05 23:47:20',NULL,NULL,'9abd81e5-264d-4e33-ae43-051ead029c2b'),(163,16,NULL,101,5,'craft\\elements\\Entry',1,0,'2024-01-05 23:49:07','2024-01-05 23:49:07',NULL,NULL,'6b53524d-5c5f-4bee-8642-e84f1164cbfc'),(165,3,NULL,102,3,'craft\\elements\\Entry',1,0,'2024-01-05 23:49:53','2024-01-05 23:49:53',NULL,NULL,'8e214e08-e964-4786-b8cd-62a6d97e0553'),(166,16,NULL,103,5,'craft\\elements\\Entry',1,0,'2024-01-05 23:51:07','2024-01-05 23:51:07',NULL,NULL,'2b7425b5-59db-49a7-b8c0-2fad29596caf'),(168,3,NULL,104,3,'craft\\elements\\Entry',1,0,'2024-01-05 23:53:16','2024-01-05 23:53:16',NULL,NULL,'7dede0c9-86b4-499a-8974-ff413dd2fe4b'),(169,NULL,NULL,NULL,8,'craft\\elements\\Asset',1,0,'2024-01-06 00:05:18','2024-01-06 00:05:22',NULL,NULL,'03374e4a-7f70-4852-811f-785d95806b46'),(170,NULL,NULL,NULL,8,'craft\\elements\\Asset',1,0,'2024-01-06 00:05:33','2024-01-06 00:05:36',NULL,NULL,'3f923ae5-6b14-46cc-998e-0ac9246a3a6a'),(171,NULL,NULL,NULL,8,'craft\\elements\\Asset',1,0,'2024-01-06 00:05:41','2024-01-06 00:05:44',NULL,NULL,'47866366-834e-4cad-b01b-fea52718bf2f'),(172,NULL,NULL,NULL,8,'craft\\elements\\Asset',1,0,'2024-01-06 00:05:50','2024-01-06 00:05:54',NULL,NULL,'d656f2c5-3e77-4157-add2-f9982e152da9'),(173,NULL,NULL,NULL,8,'craft\\elements\\Asset',1,0,'2024-01-06 00:06:10','2024-01-06 00:06:14',NULL,NULL,'0cde2b85-e115-442a-971e-8987280aee86'),(174,117,NULL,105,1,'craft\\elements\\Entry',1,0,'2024-01-06 00:07:35','2024-01-06 00:07:35',NULL,NULL,'91a6e96c-3dc5-4f11-8a9e-f5148ae83a7b'),(176,113,NULL,106,1,'craft\\elements\\Entry',1,0,'2024-01-06 00:07:45','2024-01-06 00:07:45',NULL,NULL,'a1333667-3779-484d-83c0-f0f7e4a38237'),(178,111,NULL,107,2,'craft\\elements\\Entry',1,0,'2024-01-06 00:08:00','2024-01-06 00:08:00',NULL,NULL,'2fa99c14-1a92-438a-8e81-f16ef60c17f8'),(180,102,NULL,108,2,'craft\\elements\\Entry',1,0,'2024-01-06 00:08:10','2024-01-06 00:08:10',NULL,NULL,'922f85ea-af16-4302-bf9f-ab164a15f3f3'),(182,94,NULL,109,2,'craft\\elements\\Entry',1,0,'2024-01-06 00:08:21','2024-01-06 00:08:21',NULL,NULL,'52ba7cbb-06b2-4f5b-9461-b066af907df7'),(184,92,NULL,110,2,'craft\\elements\\Entry',1,0,'2024-01-06 00:08:43','2024-01-06 00:08:43',NULL,NULL,'1c730ee3-a3c0-4523-9632-537ac4541dd9'),(185,NULL,NULL,NULL,9,'craft\\elements\\Asset',1,0,'2024-01-06 00:17:49','2024-01-06 00:18:05',NULL,NULL,'32601de9-3c13-4f5e-b206-ddff44213e21'),(186,NULL,NULL,NULL,9,'craft\\elements\\Asset',1,0,'2024-01-06 00:17:51','2024-01-06 00:18:05',NULL,NULL,'29c62860-350d-44c6-86dc-84a1a6dee7c6'),(187,NULL,NULL,NULL,9,'craft\\elements\\Asset',1,0,'2024-01-06 00:17:52','2024-01-06 00:18:05',NULL,NULL,'7471dede-7e31-40b7-b389-ef7ef7c78358'),(188,NULL,NULL,NULL,9,'craft\\elements\\Asset',1,0,'2024-01-06 00:17:55','2024-01-06 00:18:05',NULL,NULL,'6c6fec6f-d552-49a8-b42c-b1e30cc76fe4'),(189,NULL,NULL,NULL,9,'craft\\elements\\Asset',1,0,'2024-01-06 00:17:57','2024-01-06 00:18:05',NULL,NULL,'a1350528-1f68-4b7d-9117-aecd5e1b9064'),(190,NULL,NULL,NULL,9,'craft\\elements\\Asset',1,0,'2024-01-06 00:17:59','2024-01-06 00:18:05',NULL,NULL,'277c69ff-7d03-4eeb-9366-8c5c51d2fafb'),(191,NULL,NULL,NULL,10,'craft\\elements\\Asset',1,0,'2024-01-06 00:20:21','2024-01-06 00:21:15',NULL,'2024-01-10 20:50:09','e7a75d7d-5a6b-40e9-b17d-61cd414e098d'),(192,NULL,NULL,NULL,10,'craft\\elements\\Asset',1,0,'2024-01-06 00:20:40','2024-01-06 00:21:16',NULL,NULL,'198d5929-8dc3-4fcf-8de5-6391d24379a5'),(193,NULL,NULL,NULL,10,'craft\\elements\\Asset',1,0,'2024-01-06 00:20:41','2024-01-06 00:21:16',NULL,NULL,'5ef0f229-d048-4e1b-b5eb-d596c767292b'),(194,NULL,NULL,NULL,10,'craft\\elements\\Asset',1,0,'2024-01-06 00:21:44','2024-01-06 00:21:48',NULL,NULL,'a30c98b7-391b-4451-ad75-3f99ea38cccb'),(196,117,NULL,111,1,'craft\\elements\\Entry',1,0,'2024-01-06 16:51:36','2024-01-06 16:51:36',NULL,NULL,'f89ff8cf-e9be-48c6-876b-9e3acaaddd47'),(197,16,NULL,112,5,'craft\\elements\\Entry',1,0,'2024-01-06 17:49:03','2024-01-06 17:49:03',NULL,NULL,'468b5685-1964-4965-8672-d15dac044274'),(198,3,NULL,113,3,'craft\\elements\\Entry',1,0,'2024-01-06 17:54:36','2024-01-06 17:54:36',NULL,NULL,'d584c777-e451-431a-9a81-f63f69efaebd'),(199,NULL,NULL,NULL,10,'craft\\elements\\Asset',1,0,'2024-01-10 20:49:53','2024-01-10 20:49:53',NULL,NULL,'dbc37158-ecb9-4c2e-959b-5bcda1125740'),(200,NULL,NULL,NULL,10,'craft\\elements\\Asset',1,0,'2024-01-10 20:50:20','2024-01-10 20:50:20',NULL,NULL,'f1ae58fe-e5e4-4270-b8d0-1e02d5360ede'),(201,NULL,NULL,NULL,13,'craft\\elements\\Entry',1,0,'2024-01-10 22:10:29','2024-01-10 22:10:35',NULL,NULL,'c75ee873-34a5-4337-a959-755b4ada4cfd'),(202,201,NULL,114,13,'craft\\elements\\Entry',1,0,'2024-01-10 22:10:35','2024-01-10 22:10:35',NULL,NULL,'71eaa48f-c4ba-4011-bc00-7def91a47733'),(203,NULL,NULL,NULL,13,'craft\\elements\\Entry',1,0,'2024-01-10 22:10:43','2024-01-10 22:11:14',NULL,NULL,'39e855af-460d-4c0c-8dab-005cfa50da26'),(204,203,NULL,115,13,'craft\\elements\\Entry',1,0,'2024-01-10 22:10:49','2024-01-10 22:10:49',NULL,NULL,'365ae1d6-b779-49f3-9554-504b8e7a7bbc'),(206,203,NULL,116,13,'craft\\elements\\Entry',1,0,'2024-01-10 22:11:14','2024-01-10 22:11:14',NULL,NULL,'7500cf80-55cb-47ec-919f-7fba9228bad4'),(208,117,NULL,117,1,'craft\\elements\\Entry',1,0,'2024-01-10 22:12:43','2024-01-10 22:12:43',NULL,NULL,'bfb00ac0-5313-41d2-a991-e0c790cfbc26'),(210,113,NULL,118,1,'craft\\elements\\Entry',1,0,'2024-01-10 22:12:57','2024-01-10 22:12:57',NULL,NULL,'59392221-345b-430c-8cce-6d14e74a5dee'),(212,111,NULL,119,2,'craft\\elements\\Entry',1,0,'2024-01-10 22:13:09','2024-01-10 22:13:09',NULL,NULL,'62867d45-0a40-4628-8db7-bb3defabf82a'),(214,102,NULL,120,2,'craft\\elements\\Entry',1,0,'2024-01-10 22:13:23','2024-01-10 22:13:23',NULL,NULL,'50f11d77-56a6-4572-bf73-fa625a985155'),(216,94,NULL,121,2,'craft\\elements\\Entry',1,0,'2024-01-10 22:13:37','2024-01-10 22:13:37',NULL,NULL,'4df9a81d-86de-4dbe-ad30-33a4207bd718'),(218,92,NULL,122,2,'craft\\elements\\Entry',1,0,'2024-01-10 22:13:51','2024-01-10 22:13:51',NULL,NULL,'64e267dc-2154-4b5e-97a6-5b1d0630fb6c'),(219,117,NULL,123,1,'craft\\elements\\Entry',1,0,'2024-01-10 22:50:58','2024-01-10 22:50:58',NULL,NULL,'6ba99ded-d166-4dc4-a880-166635fb09eb'),(220,NULL,NULL,NULL,2,'craft\\elements\\Entry',1,0,'2024-01-11 16:54:20','2024-01-11 16:54:20',NULL,'2024-01-11 16:54:46','698e9f98-995d-40c1-8576-be4903ca6da8'),(221,220,NULL,124,2,'craft\\elements\\Entry',1,0,'2024-01-11 16:54:20','2024-01-11 16:54:20',NULL,'2024-01-11 16:54:46','d2ab3b5c-a18e-48f2-af9e-888637bbfaf3'),(223,111,NULL,125,1,'craft\\elements\\Entry',1,0,'2024-01-11 16:56:50','2024-01-11 16:56:51',NULL,NULL,'a2548ab1-3994-45e3-8e43-557c4aca5c8c'),(225,102,NULL,126,1,'craft\\elements\\Entry',1,0,'2024-01-11 16:57:22','2024-01-11 16:57:22',NULL,NULL,'706c85fd-1e8b-4f76-bc06-91dc411d773d'),(227,94,NULL,127,1,'craft\\elements\\Entry',1,0,'2024-01-11 16:57:38','2024-01-11 16:57:38',NULL,NULL,'41faea21-4b14-4eef-b159-afdf9862b5a3'),(229,92,NULL,128,1,'craft\\elements\\Entry',1,0,'2024-01-11 16:57:59','2024-01-11 16:57:59',NULL,NULL,'2ff850e9-8312-4047-ba5f-e90a7b095502');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ehcutgenytaioszdriysuwqnyddtmpgilogo` (`elementId`,`siteId`),
  KEY `idx_dlwbhtwwwrafsoggwlhuikefcbbqnlnolbpi` (`siteId`),
  KEY `idx_hdbmwafwbvxswmfxflafwlcmqfdbrrgycaft` (`slug`,`siteId`),
  KEY `idx_jzukeaunakeyadkfinkcvvntydomdtptiill` (`enabled`),
  KEY `idx_tzedtalifhziembijfawffrxrjdlqyhvivdp` (`uri`,`siteId`),
  CONSTRAINT `fk_fevikzlfgpqszzxakpkbprxpdkaqqzrqofxx` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_jkqhohwmrnhcrxpdqapnvesdxgdgzybmnosb` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=230 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
INSERT INTO `elements_sites` VALUES (1,1,1,NULL,NULL,1,'2023-12-26 19:45:34','2023-12-26 19:45:34','0173f609-4699-4ef4-b93a-a12263711838'),(2,2,1,'__temp_yccfmnohgbxsdxixrndefrewcwqzcygtijop','drinks/__temp_yccfmnohgbxsdxixrndefrewcwqzcygtijop',1,'2024-01-05 15:27:20','2024-01-05 15:27:20','a62a9d9e-08f8-485e-9a71-f47d54a1d67d'),(3,3,1,'about-us','aboutUs/about-us',1,'2024-01-05 15:47:11','2024-01-05 17:09:15','424a3cb8-396a-4984-82ef-073db8ae39ad'),(4,4,1,'about-us','about-us',1,'2024-01-05 15:47:11','2024-01-05 15:47:11','9f98067a-ee26-449a-86a5-bf2be89d5cfa'),(5,5,1,'about-us','about-us',1,'2024-01-05 15:47:11','2024-01-05 15:47:11','ae588b84-2873-48e6-84e5-1c773e91d06e'),(6,6,1,'__temp_ukrlfiddpssvoadhelohcilswohdsgzrcnhi','drinks/__temp_ukrlfiddpssvoadhelohcilswohdsgzrcnhi',1,'2024-01-05 16:35:03','2024-01-05 16:35:03','dfb85632-d2e7-409a-9bbf-deb170842ba3'),(7,7,1,'about-us','about-us',1,'2024-01-05 17:04:19','2024-01-05 17:04:19','8bdb7646-f3c6-4371-99f4-5187c7ab2385'),(8,8,1,'about-us','about-us',1,'2024-01-05 17:06:33','2024-01-05 17:06:33','2771c542-8469-4038-bfd8-8c610ddae7fb'),(9,9,1,'about-us','about-us',1,'2024-01-05 17:07:12','2024-01-05 17:07:12','a3937579-4ae1-49aa-96d2-4cdcedae8eaf'),(10,10,1,'about-us','aboutUs',1,'2024-01-05 17:07:36','2024-01-05 17:08:39','343df6b7-9229-4440-ae64-515dd51d65d1'),(11,11,1,'about-us','aboutUs',1,'2024-01-05 17:07:36','2024-01-05 17:08:39','5902b874-3570-45f7-8fca-5d022c5ddadc'),(12,12,1,'about-us','aboutUs',1,'2024-01-05 17:08:38','2024-01-05 17:08:38','736e63af-30a7-4a19-a613-a6e76806dee9'),(13,13,1,'about-us','aboutUs',1,'2024-01-05 17:08:38','2024-01-05 17:08:38','cf50d16c-e2f5-4efd-a7d6-903271400dc2'),(14,14,1,'about-us','aboutUs/about-us',1,'2024-01-05 17:09:15','2024-01-05 17:09:15','e27225eb-3971-42d6-ae1e-8c695236c1d0'),(15,15,1,'about-us','aboutUs/about-us',1,'2024-01-05 17:09:15','2024-01-05 17:09:15','4ec52982-082a-4d28-b81b-7785e276f881'),(16,16,1,'home','__home__',1,'2024-01-05 17:43:07','2024-01-05 22:38:35','9cad3207-2afc-473b-9198-0e244c455e04'),(23,23,1,'home','home',1,'2024-01-05 17:55:32','2024-01-05 17:55:32','d30f24ec-a295-4612-a18b-40ccc31d693a'),(24,24,1,'home','home',1,'2024-01-05 17:57:01','2024-01-05 17:57:01','b6531a30-4647-4d12-96f4-0040ef0380d8'),(26,26,1,'home','home',1,'2024-01-05 17:59:13','2024-01-05 17:59:13','74ba73ce-28e4-47a7-82a5-495a6b4dab55'),(27,27,1,'home','home',1,'2024-01-05 18:03:07','2024-01-05 18:03:07','e0d40497-c133-4f20-97ca-3405aa914245'),(29,29,1,'home','home',1,'2024-01-05 18:04:26','2024-01-05 18:04:26','c77d3f02-45d8-47a1-8f86-8e4acdeff23e'),(30,30,1,'home','home',1,'2024-01-05 18:04:59','2024-01-05 18:04:59','bae20b3b-84e7-40b1-9318-101b9ec18fa3'),(32,32,1,'home','home',1,'2024-01-05 18:06:05','2024-01-05 18:06:05','341113df-4bf2-4bd1-869a-3be0a36262f2'),(34,34,1,'home','home',1,'2024-01-05 18:06:29','2024-01-05 18:06:29','8487d942-7b90-4bec-9a3d-d7abfda411f8'),(36,36,1,'home','home',1,'2024-01-05 18:07:13','2024-01-05 18:07:13','4bf4c18b-1987-4d3d-9f7a-aa4f646da417'),(38,38,1,'home','home',1,'2024-01-05 18:07:44','2024-01-05 18:07:44','f84a6be7-9cbd-435c-a5e2-8ae86420a94b'),(40,40,1,'home','home',1,'2024-01-05 18:09:56','2024-01-05 18:09:56','429d2ae9-5b52-4de6-9f16-b5ac68e30115'),(41,41,1,'home','home',1,'2024-01-05 18:10:11','2024-01-05 18:10:11','88ce5dae-3c78-43d8-8af0-1608d23c0b7b'),(43,43,1,'home','home',1,'2024-01-05 18:11:25','2024-01-05 18:11:25','4c48fa87-7b13-4a2b-a306-b1730d52cd64'),(45,45,1,'home','home',1,'2024-01-05 18:11:41','2024-01-05 18:11:41','381f9d53-4650-4559-8756-389f4637b95e'),(47,47,1,'home','home',1,'2024-01-05 18:11:53','2024-01-05 18:11:53','36986ee6-3238-4670-bab0-3656b07f9c6f'),(49,49,1,'home','home',1,'2024-01-05 18:13:04','2024-01-05 18:13:04','41a07460-5b2d-4f97-8be5-f90d17492236'),(50,50,1,'home','home',1,'2024-01-05 18:19:48','2024-01-05 18:19:48','806ed0e5-3781-467a-a7c8-11e865962300'),(52,52,1,'home','home',1,'2024-01-05 18:30:39','2024-01-05 18:30:39','7ede044d-6d0d-484d-b7da-26ba92ae655f'),(54,54,1,'home','home',1,'2024-01-05 18:35:14','2024-01-05 18:35:14','29fc6009-55d5-4077-87d5-acda98864ab3'),(56,56,1,'home','home',1,'2024-01-05 18:36:54','2024-01-05 18:36:54','f0e64d9c-3864-42b4-a492-633e710e531d'),(58,58,1,'home','home',1,'2024-01-05 18:38:52','2024-01-05 18:38:52','da558cd7-caad-45c3-a526-f5bd621d6479'),(59,59,1,'home','home',1,'2024-01-05 18:39:34','2024-01-05 18:39:34','1fd3ac68-f914-45aa-828a-3a8418e7444b'),(61,61,1,'home','home',1,'2024-01-05 18:41:10','2024-01-05 18:41:10','8c6f4e1d-5210-4b3d-b07a-755319f6f358'),(62,62,1,'home','home',1,'2024-01-05 18:44:28','2024-01-05 18:44:28','e3c3e402-76bc-4289-a304-268030837638'),(64,64,1,'home','home',1,'2024-01-05 18:44:43','2024-01-05 18:44:43','02b4cc7c-9b32-4a06-9ab5-153dc24d081f'),(66,66,1,'home','home',1,'2024-01-05 18:47:43','2024-01-05 18:47:43','2fd4f947-fdc0-4c55-af77-0c21a6f6a1b5'),(67,67,1,'home','home',1,'2024-01-05 18:50:21','2024-01-05 18:50:21','aa70758f-a930-4519-9b87-1b8aa014577f'),(69,69,1,'home','home',1,'2024-01-05 18:54:05','2024-01-05 18:54:05','aa569d4c-535e-4746-bcd9-d9f632696ce9'),(71,71,1,'home','home',1,'2024-01-05 18:55:34','2024-01-05 18:55:34','de5bdf36-3576-42bd-bb72-6d6b74667fec'),(73,73,1,'home','home',1,'2024-01-05 18:56:27','2024-01-05 18:56:27','0196d402-e9f5-4b6d-ac20-35c03f55afc5'),(74,74,1,'home','home',1,'2024-01-05 18:58:08','2024-01-05 18:58:08','aa580c26-35c6-4580-af85-7254623ce6ff'),(76,76,1,'home','home',1,'2024-01-05 18:58:39','2024-01-05 18:58:39','c264e770-f3e5-4575-a0ab-c912d03ad05e'),(77,77,1,'home','home',1,'2024-01-05 18:59:02','2024-01-05 18:59:02','47522c08-df0e-421e-817d-ad19184bdd11'),(79,79,1,'home','home',1,'2024-01-05 18:59:40','2024-01-05 18:59:40','f57cb9de-638c-4750-a38d-123b96263d65'),(81,81,1,'home','home',1,'2024-01-05 19:04:51','2024-01-05 19:04:51','52eba96c-65b7-4592-8040-0679f5520b44'),(83,83,1,'home','home',1,'2024-01-05 19:08:12','2024-01-05 19:08:12','ac3630c9-9b3a-4493-a201-9a3ec0ab874c'),(85,85,1,'home','home',1,'2024-01-05 19:10:27','2024-01-05 19:10:27','40ffbd59-84d9-4e80-90be-e32d4898f2e1'),(87,87,1,'home','home',1,'2024-01-05 19:13:45','2024-01-05 19:13:45','cc5f6e90-93fd-4549-8d1c-47609b78c7c0'),(89,89,1,'home','home',1,'2024-01-05 19:15:28','2024-01-05 19:15:28','8037557b-f475-4e75-a71e-e5dc1dd5680c'),(91,91,1,'home','home',1,'2024-01-05 19:19:58','2024-01-05 19:19:58','97ce9408-1ff2-457c-a465-86f772d393bd'),(92,92,1,'smirnoff-vodka','drinks/smirnoff-vodka',1,'2024-01-05 21:45:37','2024-01-05 21:46:09','8a232d93-36d2-4629-affc-8142e3c5ab69'),(93,93,1,'smirnoff-vodka','drinks/smirnoff-vodka',1,'2024-01-05 21:48:48','2024-01-05 21:48:48','a5a415f8-5617-46cc-8d08-f2efa6da3e44'),(94,94,1,'absolut-vodka','drinks/absolut-vodka',1,'2024-01-05 21:48:58','2024-01-05 21:49:06','8bb0e332-1000-499e-a09c-feb1734eda99'),(95,95,1,'absolut-vodka','drinks/absolut-vodka',1,'2024-01-05 21:49:16','2024-01-05 21:49:16','88f10eb2-cf86-4923-b4f6-3b0edfa1ed7e'),(97,97,1,'absolut-vodka','drinks/absolut-vodka',1,'2024-01-05 21:49:33','2024-01-05 21:49:33','07f6d30f-012f-408d-b6c8-aae5cb356937'),(99,99,1,'smirnoff-vodka','drinks/smirnoff-vodka',1,'2024-01-05 21:49:46','2024-01-05 21:49:46','50316075-24ea-4942-aba2-fe8021207e33'),(101,101,1,'absolut-vodka','drinks/absolut-vodka',1,'2024-01-05 21:50:46','2024-01-05 21:50:46','bae7c4e6-e0c9-46f5-9870-04becd8b5d6d'),(102,102,1,'jack-daniels','drinks/jack-daniels',1,'2024-01-05 21:51:41','2024-01-05 21:51:51','69a34a28-1f88-41f9-92a1-a1da5c6bee58'),(103,103,1,'jack-daniels','drinks/jack-daniels',1,'2024-01-05 21:52:00','2024-01-05 21:52:00','415c9c06-0a25-4d3e-9d1f-6bbbb9b2456a'),(105,105,1,'jack-daniels','drinks/jack-daniels',1,'2024-01-05 21:52:55','2024-01-05 21:52:55','f8d104d8-6073-4b03-8ad5-d523ae538db7'),(106,106,1,'absolut-vodka','drinks/absolut-vodka',1,'2024-01-05 21:53:12','2024-01-05 21:53:12','e2944330-d6c6-4415-9ff1-b4fba067eea4'),(108,108,1,'smirnoff-vodka','drinks/smirnoff-vodka',1,'2024-01-05 21:53:23','2024-01-05 21:53:23','4aa41ed8-1512-45fc-882a-ac1b6315be85'),(109,109,1,'absolut-vodka','drinks/absolut-vodka',1,'2024-01-05 21:54:00','2024-01-05 21:54:00','777c1744-882d-4547-932f-128ffab662da'),(111,111,1,'the-famous-grouse','drinks/the-famous-grouse',1,'2024-01-05 21:54:13','2024-01-05 21:54:42','d7cffc4d-7338-4773-b09c-1b0c19628acf'),(112,112,1,'the-famous-grouse','drinks/the-famous-grouse',1,'2024-01-05 21:55:59','2024-01-05 21:55:59','7ac24576-5505-493e-b66f-7c888361b98b'),(113,113,1,'coca-cola','drinks/coca-cola',1,'2024-01-05 21:56:14','2024-01-05 21:56:19','f79df1d3-c545-4ecd-b5b8-2f9ba8a5a7cb'),(114,114,1,'coca-cola','drinks/coca-cola',1,'2024-01-05 21:56:25','2024-01-05 21:56:25','795b4656-9536-4f53-8f84-2f8e8ea535b2'),(116,116,1,'coca-cola','drinks/coca-cola',1,'2024-01-05 21:57:23','2024-01-05 21:57:23','48f2c5b8-7618-4fb4-a926-0231971c8812'),(117,117,1,'fanta-blueberry-12','drinks/fanta-blueberry-12',1,'2024-01-05 21:57:27','2024-01-05 21:57:39','d00f16ec-d96e-4bd0-82e9-e43eecb3773a'),(118,118,1,'fanta-blueberry-12','drinks/fanta-blueberry-12',1,'2024-01-05 21:59:07','2024-01-05 21:59:07','94719d12-53bd-4632-9823-3b6f11f35f0a'),(120,120,1,'the-famous-grouse','drinks/the-famous-grouse',1,'2024-01-05 21:59:16','2024-01-05 21:59:16','449e0a89-74ad-4d50-85e0-6ba942765bd6'),(121,121,1,'the-famous-grouse','drinks/the-famous-grouse',1,'2024-01-05 21:59:22','2024-01-05 21:59:22','c0ffe04c-c8fb-434f-bf6f-4766158722f4'),(123,123,1,'jack-daniels','drinks/jack-daniels',1,'2024-01-05 21:59:31','2024-01-05 21:59:31','b5ed3565-a710-41d9-aa9f-9bac88100310'),(125,125,1,'smirnoff-vodka','drinks/smirnoff-vodka',1,'2024-01-05 21:59:48','2024-01-05 21:59:48','a1aa234a-9748-4170-b4fa-87f17cd01904'),(126,126,1,'jack-daniels','drinks/jack-daniels',1,'2024-01-05 21:59:53','2024-01-05 21:59:53','7c99d904-3aca-4a5d-aaf4-3fdc3e7e84f0'),(127,127,1,'smirnoff-vodka','drinks/smirnoff-vodka',1,'2024-01-05 21:59:58','2024-01-05 21:59:58','b1270b73-258b-4183-80ad-863aadb012b1'),(128,128,1,'the-famous-grouse','drinks/the-famous-grouse',1,'2024-01-05 22:00:04','2024-01-05 22:00:04','bd633f44-059c-4e12-89e2-1809caa43358'),(129,129,1,'jack-daniels','drinks/jack-daniels',1,'2024-01-05 22:00:07','2024-01-05 22:00:07','1fc9eeb8-1b2e-4a2c-a91c-b3cb0082c500'),(130,130,1,'absolut-vodka','drinks/absolut-vodka',1,'2024-01-05 22:00:14','2024-01-05 22:00:14','00fa98d0-3b7c-4254-99ee-eedd239fb83f'),(131,131,1,'fanta-blueberry-12','drinks/fanta-blueberry-12',1,'2024-01-05 22:01:12','2024-01-05 22:01:12','7178e952-9251-485b-8d0e-eaf9c22b4386'),(133,133,1,'fanta-blueberry-12','drinks/fanta-blueberry-12',1,'2024-01-05 22:10:26','2024-01-05 22:10:26','d7e787bb-175b-48ba-8368-0c5b7d3035b3'),(134,134,1,'the-famous-grouse-2','drinks/the-famous-grouse-2',1,'2024-01-05 22:19:55','2024-01-05 22:19:55','530ad45f-99b5-440a-b913-b86a01e562aa'),(135,135,1,'the-famous-grouse-2','drinks/the-famous-grouse-2',1,'2024-01-05 22:19:55','2024-01-05 22:19:55','5238c529-baf7-435c-ba1d-8cb0b0f8d918'),(137,137,1,'home','__home__',1,'2024-01-05 22:37:19','2024-01-05 22:37:19','00dcf68f-d650-4fb1-9c58-a0f01b1b34bc'),(138,138,1,'home','__home__',1,'2024-01-05 22:37:19','2024-01-05 22:37:19','717802eb-dd89-4df8-9e9d-88a3d851b487'),(139,139,1,'home','__home__',1,'2024-01-05 22:37:54','2024-01-05 22:38:37','fa209ed5-70ac-4814-80ef-95aedde97659'),(140,140,1,'home','__home__',1,'2024-01-05 22:37:54','2024-01-05 22:38:37','95352cd1-8055-4be1-b5f4-96911cb1a2f5'),(141,141,1,'home','__home__',1,'2024-01-05 22:38:56','2024-01-05 22:38:56','ce5f94af-7186-471f-b252-e815c35262ee'),(142,142,1,'home','__home__',1,'2024-01-05 22:38:56','2024-01-05 22:38:56','f3ea7b01-344a-4d88-a4ab-5aa8578ed293'),(143,143,1,NULL,NULL,1,'2024-01-05 23:21:27','2024-01-05 23:21:27','03a518d8-c508-4c80-908c-1fbfbf5f7fd4'),(144,144,1,'about-us','aboutUs/about-us',1,'2024-01-05 23:32:48','2024-01-05 23:32:48','05136a30-dd72-4030-88a1-13d71569b725'),(146,146,1,'about-us','aboutUs/about-us',1,'2024-01-05 23:38:13','2024-01-05 23:38:13','c89cf021-8419-43f6-9a09-4388ca100305'),(147,147,1,'about-us','aboutUs/about-us',1,'2024-01-05 23:39:11','2024-01-05 23:39:11','bec8c7fb-e21e-464a-8882-06bf474db866'),(149,149,1,'about-us','aboutUs/about-us',1,'2024-01-05 23:40:25','2024-01-05 23:40:25','055a00cc-94b6-4234-b99f-eda7bc49534b'),(151,151,1,'about-us','aboutUs/about-us',1,'2024-01-05 23:40:45','2024-01-05 23:40:45','d530bbe9-7f1c-43c4-a188-99c15d70707e'),(152,152,1,'about-us','aboutUs/about-us',1,'2024-01-05 23:42:11','2024-01-05 23:42:11','0d1d7f92-8be9-4783-8ef9-8b75fc17fcfc'),(154,154,1,'about-us','aboutUs/about-us',1,'2024-01-05 23:43:40','2024-01-05 23:43:40','7ebf5c75-3301-46ac-afbe-ecd52296f1b3'),(155,155,1,'about-us','aboutUs/about-us',1,'2024-01-05 23:44:56','2024-01-05 23:44:56','94f8d2a3-1c37-4784-bfc8-23aec9ab38d6'),(157,157,1,'about-us','aboutUs/about-us',1,'2024-01-05 23:46:25','2024-01-05 23:46:25','ed9f3c1f-ba22-40fd-a545-396f5f817ccd'),(158,158,1,'home','__home__',1,'2024-01-05 23:46:45','2024-01-05 23:46:45','d7f27da7-c095-49b1-a373-9b721ede912e'),(160,160,1,'about-us','aboutUs/about-us',1,'2024-01-05 23:46:57','2024-01-05 23:46:57','1633c81c-6b16-4608-9a02-eaa1bc8dc8b5'),(162,162,1,'about-us','aboutUs/about-us',1,'2024-01-05 23:47:20','2024-01-05 23:47:20','1a3f2ff3-5914-4d10-b60b-c6a03eee82ff'),(163,163,1,'home','__home__',1,'2024-01-05 23:49:07','2024-01-05 23:49:07','45c81d9e-cad4-415f-9166-2548672b6fa3'),(165,165,1,'about-us','aboutUs/about-us',1,'2024-01-05 23:49:53','2024-01-05 23:49:53','45f816c2-0d08-4b40-87f8-2dd5bc66f82c'),(166,166,1,'home','__home__',1,'2024-01-05 23:51:07','2024-01-05 23:51:07','1a49cf19-29e2-49da-9eeb-442c8d1a14ad'),(168,168,1,'about-us','aboutUs/about-us',1,'2024-01-05 23:53:16','2024-01-05 23:53:16','f681dd23-a09e-4c52-9797-00254e65feae'),(169,169,1,NULL,NULL,1,'2024-01-06 00:05:18','2024-01-06 00:05:18','7cbcd4f0-fe1b-405e-9c09-ccd4c52be72f'),(170,170,1,NULL,NULL,1,'2024-01-06 00:05:33','2024-01-06 00:05:33','8424e950-7a0f-41f9-ae92-906ae769925b'),(171,171,1,NULL,NULL,1,'2024-01-06 00:05:41','2024-01-06 00:05:41','ded5d003-4c5f-4cec-9dda-b82ef963ad23'),(172,172,1,NULL,NULL,1,'2024-01-06 00:05:50','2024-01-06 00:05:50','5bcd783e-1b9a-48db-bec5-b748f97e2070'),(173,173,1,NULL,NULL,1,'2024-01-06 00:06:10','2024-01-06 00:06:10','42a060d4-6cbb-4e67-8f34-a5f2d52086ea'),(174,174,1,'fanta-blueberry-12','drinks/fanta-blueberry-12',1,'2024-01-06 00:07:35','2024-01-06 00:07:35','00069c63-314c-4bd0-8683-d92371ebc7e4'),(176,176,1,'coca-cola','drinks/coca-cola',1,'2024-01-06 00:07:45','2024-01-06 00:07:45','57d0cfba-72b4-4a09-9bca-8372bbc3bbb4'),(178,178,1,'the-famous-grouse','drinks/the-famous-grouse',1,'2024-01-06 00:08:00','2024-01-06 00:08:00','c3a39d50-9dfd-4623-9f7d-48038c63baa3'),(180,180,1,'jack-daniels','drinks/jack-daniels',1,'2024-01-06 00:08:10','2024-01-06 00:08:10','d0d2b09f-d12f-4ff0-a577-dbd3d26fa806'),(182,182,1,'absolut-vodka','drinks/absolut-vodka',1,'2024-01-06 00:08:21','2024-01-06 00:08:21','005a857e-6ec5-4ddb-8d3b-e5dd0040bfb2'),(184,184,1,'smirnoff-vodka','drinks/smirnoff-vodka',1,'2024-01-06 00:08:43','2024-01-06 00:08:43','07bb33d4-1879-43a8-a371-b8efa7d3e688'),(185,185,1,NULL,NULL,1,'2024-01-06 00:17:49','2024-01-06 00:17:49','80cb127f-1c53-44ad-ad86-af127deffc90'),(186,186,1,NULL,NULL,1,'2024-01-06 00:17:51','2024-01-06 00:17:51','e99685fe-743f-4ed7-94fd-a912f8eb0614'),(187,187,1,NULL,NULL,1,'2024-01-06 00:17:52','2024-01-06 00:17:52','af3fa1df-788e-4b8a-b7a9-462f58f1794a'),(188,188,1,NULL,NULL,1,'2024-01-06 00:17:55','2024-01-06 00:17:55','b400bfaa-0813-4ba1-bcf8-4994d27ed764'),(189,189,1,NULL,NULL,1,'2024-01-06 00:17:57','2024-01-06 00:17:57','896bf1a6-6524-40bc-9065-c0b423a75104'),(190,190,1,NULL,NULL,1,'2024-01-06 00:17:59','2024-01-06 00:17:59','70357d80-e5b6-41c1-a750-53395ac49d3d'),(191,191,1,NULL,NULL,1,'2024-01-06 00:20:21','2024-01-06 00:20:21','cf549553-bbaf-4ae0-ad33-21cea230a3b3'),(192,192,1,NULL,NULL,1,'2024-01-06 00:20:40','2024-01-06 00:20:40','828743be-4646-4ffd-a72d-7435e8b96e90'),(193,193,1,NULL,NULL,1,'2024-01-06 00:20:41','2024-01-06 00:20:41','5ad714cb-f8e2-45a4-b1d4-fe13c5466a8d'),(194,194,1,NULL,NULL,1,'2024-01-06 00:21:44','2024-01-06 00:21:44','2aadf7cc-8c21-4094-9fff-959c816304bf'),(196,196,1,'fanta-blueberry-12','drinks/fanta-blueberry-12',1,'2024-01-06 16:51:36','2024-01-06 16:51:36','bb85fdfa-9b2e-4d4e-843b-0735901562bd'),(197,197,1,'home','__home__',1,'2024-01-06 17:49:03','2024-01-06 17:49:03','4d015573-157d-40a7-81f7-870ec402372e'),(198,198,1,'about-us','aboutUs/about-us',1,'2024-01-06 17:54:36','2024-01-06 17:54:36','fe45af31-632a-4782-9841-d5e79eec13ae'),(199,199,1,NULL,NULL,1,'2024-01-10 20:49:53','2024-01-10 20:49:53','517bf3ef-426f-42e0-932b-54eb0baffd23'),(200,200,1,NULL,NULL,1,'2024-01-10 20:50:20','2024-01-10 20:50:20','a86e8910-7283-45ba-9326-7e48468bd3d3'),(201,201,1,'drinks','store-categories/drinks',1,'2024-01-10 22:10:29','2024-01-10 22:10:35','f3442e5c-a425-4f08-bfd3-53eec31afaa0'),(202,202,1,'drinks','store-categories/drinks',1,'2024-01-10 22:10:35','2024-01-10 22:10:35','2e6bc360-4075-40c6-931a-d1c7ce158a93'),(203,203,1,'nonalcolische','store-categories/nonalcolische',1,'2024-01-10 22:10:43','2024-01-10 22:10:49','40e0bcc7-1343-4e6d-9111-cfdbe7a1c1ea'),(204,204,1,'nonalcolische','store-categories/nonalcolische',1,'2024-01-10 22:10:49','2024-01-10 22:10:49','7dfc335c-95b2-437f-b8fa-0dac7a867840'),(206,206,1,'nonalcolische','store-categories/nonalcolische',1,'2024-01-10 22:11:14','2024-01-10 22:11:14','6080591f-cf94-438d-9755-b9d4faee7a30'),(208,208,1,'fanta-blueberry-12','drinks/fanta-blueberry-12',1,'2024-01-10 22:12:43','2024-01-10 22:12:43','a2812b85-10a0-4567-8ed1-c59e3c482796'),(210,210,1,'coca-cola','drinks/coca-cola',1,'2024-01-10 22:12:57','2024-01-10 22:12:57','e4c0b9cd-7704-4a82-bd27-c642fa42e997'),(212,212,1,'the-famous-grouse','drinks/the-famous-grouse',1,'2024-01-10 22:13:09','2024-01-10 22:13:09','11bcb1c4-e98c-410f-98c8-fd8941979efa'),(214,214,1,'jack-daniels','drinks/jack-daniels',1,'2024-01-10 22:13:23','2024-01-10 22:13:23','3f48ca7e-110a-4259-83ca-49b3abf29f50'),(216,216,1,'absolut-vodka','drinks/absolut-vodka',1,'2024-01-10 22:13:37','2024-01-10 22:13:37','4adbf9cb-a0e1-4e28-afcb-872e4297ca53'),(218,218,1,'smirnoff-vodka','drinks/smirnoff-vodka',1,'2024-01-10 22:13:51','2024-01-10 22:13:51','16dd8ab9-a19a-4c55-b29a-ae4fa4b56e4c'),(219,219,1,'fanta-blueberry-12','drinks/fanta-blueberry-12',1,'2024-01-10 22:50:58','2024-01-10 22:50:58','0c4e7b7e-868f-4c08-91cc-8529e881bdc5'),(220,220,1,'the-famous-grouse-2','drinks/the-famous-grouse-2',1,'2024-01-11 16:54:20','2024-01-11 16:54:20','9bf0fc4a-ffc4-4a52-8559-15edcd9e3af7'),(221,221,1,'the-famous-grouse-2','drinks/the-famous-grouse-2',1,'2024-01-11 16:54:20','2024-01-11 16:54:20','4c97070b-2c4f-4713-8afb-86eac8ad7bef'),(223,223,1,'the-famous-grouse','drinks/the-famous-grouse',1,'2024-01-11 16:56:51','2024-01-11 16:56:51','2e8183af-e564-4955-a24a-42f6b7c9a463'),(225,225,1,'jack-daniels','drinks/jack-daniels',1,'2024-01-11 16:57:22','2024-01-11 16:57:22','2650e45a-ac6f-4558-b2e7-5a1c1052f58e'),(227,227,1,'absolut-vodka','drinks/absolut-vodka',1,'2024-01-11 16:57:38','2024-01-11 16:57:38','72235bd1-6681-4ee3-8e40-1a920e924a37'),(229,229,1,'smirnoff-vodka','drinks/smirnoff-vodka',1,'2024-01-11 16:57:59','2024-01-11 16:57:59','110a6e39-931c-4c42-8877-72cda75b9fd4');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries` (
  `id` int NOT NULL,
  `sectionId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `typeId` int NOT NULL,
  `authorId` int DEFAULT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_xdzfjzmqjprxsxnmwatfexqdaqnernvzhsug` (`postDate`),
  KEY `idx_xtxuppazvbeldoenqeadaqhujowayeabmlci` (`expiryDate`),
  KEY `idx_bgbucxtmsbqwrlnetroqydwoluhqgbjhrmfb` (`authorId`),
  KEY `idx_nquvutszvvdrcinfxsoehqturqmoyurozmab` (`sectionId`),
  KEY `idx_dzhrkkiqdwbdanwoxyrbdhzhwnabcjjlyqhh` (`typeId`),
  KEY `fk_hmvczafylrqikelbxbvpzapodhqwmfpomxew` (`parentId`),
  CONSTRAINT `fk_dtgqjcmxeustfxhgpeueeaciytysjpeoonhr` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_gwblttpsqgdtmwfhzhzdhvskleesibzjjxpp` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_hmvczafylrqikelbxbvpzapodhqwmfpomxew` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_lslgxbimzgrhxrlaobikhhpbcfievuprdasg` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nsvepjlqsdnjtizuppbsbsrehfcdzeqrzwun` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
INSERT INTO `entries` VALUES (2,1,NULL,1,1,'2024-01-05 15:27:20',NULL,0,'2024-01-05 15:27:20','2024-01-05 15:27:20'),(3,2,NULL,3,NULL,'2024-01-05 15:47:00',NULL,NULL,'2024-01-05 15:47:11','2024-01-05 17:07:36'),(4,2,NULL,3,NULL,'2024-01-05 15:47:00',NULL,NULL,'2024-01-05 15:47:11','2024-01-05 17:07:37'),(5,2,NULL,3,NULL,'2024-01-05 15:47:00',NULL,NULL,'2024-01-05 15:47:11','2024-01-05 17:07:37'),(6,1,NULL,1,1,'2024-01-05 16:35:03',NULL,0,'2024-01-05 16:35:03','2024-01-05 16:35:03'),(7,2,NULL,3,NULL,'2024-01-05 15:47:00',NULL,NULL,'2024-01-05 17:04:19','2024-01-05 17:07:37'),(8,2,NULL,3,NULL,'2024-01-05 15:47:00',NULL,NULL,'2024-01-05 17:06:33','2024-01-05 17:07:37'),(9,2,NULL,3,NULL,'2024-01-05 15:47:00',NULL,NULL,'2024-01-05 17:07:12','2024-01-05 17:07:37'),(10,2,NULL,3,NULL,'2024-01-05 15:47:00',NULL,NULL,'2024-01-05 17:07:36','2024-01-05 17:07:36'),(11,2,NULL,3,NULL,'2024-01-05 15:47:00',NULL,NULL,'2024-01-05 17:07:36','2024-01-05 17:07:36'),(12,2,NULL,3,NULL,'2024-01-05 15:47:00',NULL,NULL,'2024-01-05 17:08:38','2024-01-05 17:08:38'),(13,2,NULL,3,NULL,'2024-01-05 15:47:00',NULL,NULL,'2024-01-05 17:08:38','2024-01-05 17:08:38'),(14,2,NULL,3,NULL,'2024-01-05 15:47:00',NULL,NULL,'2024-01-05 17:09:15','2024-01-05 17:09:15'),(15,2,NULL,3,NULL,'2024-01-05 15:47:00',NULL,NULL,'2024-01-05 17:09:15','2024-01-05 17:09:15'),(16,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 17:43:07','2024-01-05 17:43:07'),(23,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 17:55:32','2024-01-05 17:55:32'),(24,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 17:57:01','2024-01-05 17:57:01'),(26,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 17:59:13','2024-01-05 17:59:13'),(27,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 18:03:07','2024-01-05 18:03:07'),(29,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 18:04:26','2024-01-05 18:04:26'),(30,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 18:04:59','2024-01-05 18:04:59'),(32,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 18:06:05','2024-01-05 18:06:05'),(34,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 18:06:29','2024-01-05 18:06:29'),(36,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 18:07:13','2024-01-05 18:07:13'),(38,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 18:07:44','2024-01-05 18:07:44'),(40,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 18:09:56','2024-01-05 18:09:56'),(41,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 18:10:11','2024-01-05 18:10:11'),(43,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 18:11:25','2024-01-05 18:11:25'),(45,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 18:11:41','2024-01-05 18:11:41'),(47,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 18:11:53','2024-01-05 18:11:53'),(49,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 18:13:04','2024-01-05 18:13:04'),(50,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 18:19:48','2024-01-05 18:19:48'),(52,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 18:30:39','2024-01-05 18:30:39'),(54,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 18:35:14','2024-01-05 18:35:14'),(56,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 18:36:54','2024-01-05 18:36:54'),(58,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 18:38:52','2024-01-05 18:38:52'),(59,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 18:39:34','2024-01-05 18:39:34'),(61,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 18:41:10','2024-01-05 18:41:10'),(62,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 18:44:28','2024-01-05 18:44:28'),(64,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 18:44:43','2024-01-05 18:44:43'),(66,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 18:47:43','2024-01-05 18:47:43'),(67,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 18:50:21','2024-01-05 18:50:21'),(69,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 18:54:05','2024-01-05 18:54:05'),(71,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 18:55:34','2024-01-05 18:55:34'),(73,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 18:56:27','2024-01-05 18:56:27'),(74,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 18:58:08','2024-01-05 18:58:08'),(76,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 18:58:39','2024-01-05 18:58:39'),(77,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 18:59:02','2024-01-05 18:59:02'),(79,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 18:59:40','2024-01-05 18:59:40'),(81,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 19:04:51','2024-01-05 19:04:51'),(83,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 19:08:12','2024-01-05 19:08:12'),(85,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 19:10:27','2024-01-05 19:10:27'),(87,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 19:13:45','2024-01-05 19:13:45'),(89,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 19:15:28','2024-01-05 19:15:28'),(91,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 19:19:58','2024-01-05 19:19:58'),(92,1,NULL,1,1,'2024-01-05 21:48:00',NULL,NULL,'2024-01-05 21:45:37','2024-01-11 16:57:59'),(93,1,NULL,1,1,'2024-01-05 21:48:00',NULL,NULL,'2024-01-05 21:48:48','2024-01-05 21:48:48'),(94,1,NULL,1,1,'2024-01-05 21:49:00',NULL,NULL,'2024-01-05 21:48:58','2024-01-11 16:57:38'),(95,1,NULL,1,1,'2024-01-05 21:49:00',NULL,NULL,'2024-01-05 21:49:16','2024-01-05 21:49:16'),(97,1,NULL,1,1,'2024-01-05 21:49:00',NULL,NULL,'2024-01-05 21:49:33','2024-01-05 21:49:33'),(99,1,NULL,1,1,'2024-01-05 21:48:00',NULL,NULL,'2024-01-05 21:49:46','2024-01-05 21:49:46'),(101,1,NULL,1,1,'2024-01-05 21:49:00',NULL,NULL,'2024-01-05 21:50:46','2024-01-05 21:50:46'),(102,1,NULL,1,1,'2024-01-05 21:52:00',NULL,NULL,'2024-01-05 21:51:41','2024-01-11 16:57:22'),(103,1,NULL,1,1,'2024-01-05 21:52:00',NULL,NULL,'2024-01-05 21:52:00','2024-01-05 21:52:00'),(105,1,NULL,1,1,'2024-01-05 21:52:00',NULL,NULL,'2024-01-05 21:52:55','2024-01-05 21:52:55'),(106,1,NULL,1,1,'2024-01-05 21:49:00',NULL,NULL,'2024-01-05 21:53:12','2024-01-05 21:53:12'),(108,1,NULL,1,1,'2024-01-05 21:48:00',NULL,NULL,'2024-01-05 21:53:23','2024-01-05 21:53:23'),(109,1,NULL,1,1,'2024-01-05 21:49:00',NULL,NULL,'2024-01-05 21:54:00','2024-01-05 21:54:00'),(111,1,NULL,1,1,'2024-01-05 21:55:00',NULL,NULL,'2024-01-05 21:54:13','2024-01-11 16:56:50'),(112,1,NULL,1,1,'2024-01-05 21:55:00',NULL,NULL,'2024-01-05 21:55:59','2024-01-05 21:55:59'),(113,1,NULL,1,1,'2024-01-05 21:56:00',NULL,NULL,'2024-01-05 21:56:14','2024-01-05 21:56:25'),(114,1,NULL,1,1,'2024-01-05 21:56:00',NULL,NULL,'2024-01-05 21:56:25','2024-01-05 21:56:25'),(116,1,NULL,1,1,'2024-01-05 21:56:00',NULL,NULL,'2024-01-05 21:57:23','2024-01-05 21:57:23'),(117,1,NULL,1,1,'2024-01-05 21:59:00',NULL,NULL,'2024-01-05 21:57:27','2024-01-05 21:59:07'),(118,1,NULL,1,1,'2024-01-05 21:59:00',NULL,NULL,'2024-01-05 21:59:07','2024-01-05 21:59:07'),(120,1,NULL,2,1,'2024-01-05 21:55:00',NULL,NULL,'2024-01-05 21:59:16','2024-01-05 21:59:16'),(121,1,NULL,2,1,'2024-01-05 21:55:00',NULL,NULL,'2024-01-05 21:59:22','2024-01-05 21:59:22'),(123,1,NULL,2,1,'2024-01-05 21:52:00',NULL,NULL,'2024-01-05 21:59:31','2024-01-05 21:59:31'),(125,1,NULL,2,1,'2024-01-05 21:48:00',NULL,NULL,'2024-01-05 21:59:48','2024-01-05 21:59:48'),(126,1,NULL,2,1,'2024-01-05 21:52:00',NULL,NULL,'2024-01-05 21:59:53','2024-01-05 21:59:53'),(127,1,NULL,2,1,'2024-01-05 21:48:00',NULL,NULL,'2024-01-05 21:59:58','2024-01-05 21:59:58'),(128,1,NULL,2,1,'2024-01-05 21:55:00',NULL,NULL,'2024-01-05 22:00:04','2024-01-05 22:00:04'),(129,1,NULL,2,1,'2024-01-05 21:52:00',NULL,NULL,'2024-01-05 22:00:07','2024-01-05 22:00:07'),(130,1,NULL,2,1,'2024-01-05 21:49:00',NULL,NULL,'2024-01-05 22:00:14','2024-01-05 22:00:14'),(131,1,NULL,1,1,'2024-01-05 21:59:00',NULL,NULL,'2024-01-05 22:01:12','2024-01-05 22:01:12'),(133,1,NULL,1,1,'2024-01-05 21:59:00',NULL,NULL,'2024-01-05 22:10:26','2024-01-05 22:10:26'),(134,1,NULL,2,1,'2024-01-05 21:55:00',NULL,0,'2024-01-05 22:19:55','2024-01-05 22:19:55'),(135,1,NULL,2,1,'2024-01-05 21:55:00',NULL,NULL,'2024-01-05 22:19:55','2024-01-05 22:19:55'),(137,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 22:37:19','2024-01-05 22:37:19'),(138,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 22:37:19','2024-01-05 22:37:19'),(139,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 22:37:54','2024-01-05 22:37:54'),(140,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 22:37:54','2024-01-05 22:37:54'),(141,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 22:38:56','2024-01-05 22:38:56'),(142,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 22:38:56','2024-01-05 22:38:56'),(144,2,NULL,3,NULL,'2024-01-05 15:47:00',NULL,NULL,'2024-01-05 23:32:48','2024-01-05 23:32:48'),(146,2,NULL,3,NULL,'2024-01-05 15:47:00',NULL,NULL,'2024-01-05 23:38:13','2024-01-05 23:38:13'),(147,2,NULL,3,NULL,'2024-01-05 15:47:00',NULL,NULL,'2024-01-05 23:39:11','2024-01-05 23:39:11'),(149,2,NULL,3,NULL,'2024-01-05 15:47:00',NULL,NULL,'2024-01-05 23:40:25','2024-01-05 23:40:25'),(151,2,NULL,3,NULL,'2024-01-05 15:47:00',NULL,NULL,'2024-01-05 23:40:45','2024-01-05 23:40:45'),(152,2,NULL,3,NULL,'2024-01-05 15:47:00',NULL,NULL,'2024-01-05 23:42:11','2024-01-05 23:42:11'),(154,2,NULL,3,NULL,'2024-01-05 15:47:00',NULL,NULL,'2024-01-05 23:43:40','2024-01-05 23:43:40'),(155,2,NULL,3,NULL,'2024-01-05 15:47:00',NULL,NULL,'2024-01-05 23:44:56','2024-01-05 23:44:56'),(157,2,NULL,3,NULL,'2024-01-05 15:47:00',NULL,NULL,'2024-01-05 23:46:25','2024-01-05 23:46:25'),(158,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 23:46:45','2024-01-05 23:46:45'),(160,2,NULL,3,NULL,'2024-01-05 15:47:00',NULL,NULL,'2024-01-05 23:46:57','2024-01-05 23:46:57'),(162,2,NULL,3,NULL,'2024-01-05 15:47:00',NULL,NULL,'2024-01-05 23:47:20','2024-01-05 23:47:20'),(163,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 23:49:07','2024-01-05 23:49:07'),(165,2,NULL,3,NULL,'2024-01-05 15:47:00',NULL,NULL,'2024-01-05 23:49:53','2024-01-05 23:49:53'),(166,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-05 23:51:07','2024-01-05 23:51:07'),(168,2,NULL,3,NULL,'2024-01-05 15:47:00',NULL,NULL,'2024-01-05 23:53:16','2024-01-05 23:53:16'),(174,1,NULL,1,1,'2024-01-05 21:59:00',NULL,NULL,'2024-01-06 00:07:35','2024-01-06 00:07:35'),(176,1,NULL,1,1,'2024-01-05 21:56:00',NULL,NULL,'2024-01-06 00:07:45','2024-01-06 00:07:45'),(178,1,NULL,2,1,'2024-01-05 21:55:00',NULL,NULL,'2024-01-06 00:08:00','2024-01-06 00:08:00'),(180,1,NULL,2,1,'2024-01-05 21:52:00',NULL,NULL,'2024-01-06 00:08:10','2024-01-06 00:08:10'),(182,1,NULL,2,1,'2024-01-05 21:49:00',NULL,NULL,'2024-01-06 00:08:21','2024-01-06 00:08:21'),(184,1,NULL,2,1,'2024-01-05 21:48:00',NULL,NULL,'2024-01-06 00:08:43','2024-01-06 00:08:43'),(196,1,NULL,1,1,'2024-01-05 21:59:00',NULL,NULL,'2024-01-06 16:51:36','2024-01-06 16:51:36'),(197,4,NULL,5,NULL,'2024-01-05 17:43:00',NULL,NULL,'2024-01-06 17:49:03','2024-01-06 17:49:03'),(198,2,NULL,3,NULL,'2024-01-05 15:47:00',NULL,NULL,'2024-01-06 17:54:36','2024-01-06 17:54:36'),(201,8,NULL,9,1,'2024-01-10 22:10:00',NULL,NULL,'2024-01-10 22:10:29','2024-01-10 22:10:35'),(202,8,NULL,9,1,'2024-01-10 22:10:00',NULL,NULL,'2024-01-10 22:10:35','2024-01-10 22:10:35'),(203,8,NULL,9,1,'2024-01-10 22:10:00',NULL,NULL,'2024-01-10 22:10:43','2024-01-10 22:10:49'),(204,8,NULL,9,1,'2024-01-10 22:10:00',NULL,NULL,'2024-01-10 22:10:49','2024-01-10 22:10:49'),(206,8,NULL,9,1,'2024-01-10 22:10:00',NULL,NULL,'2024-01-10 22:11:14','2024-01-10 22:11:14'),(208,1,NULL,1,1,'2024-01-05 21:59:00',NULL,NULL,'2024-01-10 22:12:43','2024-01-10 22:12:43'),(210,1,NULL,1,1,'2024-01-05 21:56:00',NULL,NULL,'2024-01-10 22:12:57','2024-01-10 22:12:57'),(212,1,NULL,2,1,'2024-01-05 21:55:00',NULL,NULL,'2024-01-10 22:13:09','2024-01-10 22:13:09'),(214,1,NULL,2,1,'2024-01-05 21:52:00',NULL,NULL,'2024-01-10 22:13:23','2024-01-10 22:13:23'),(216,1,NULL,2,1,'2024-01-05 21:49:00',NULL,NULL,'2024-01-10 22:13:37','2024-01-10 22:13:37'),(218,1,NULL,2,1,'2024-01-05 21:48:00',NULL,NULL,'2024-01-10 22:13:51','2024-01-10 22:13:51'),(219,1,NULL,1,1,'2024-01-05 21:59:00',NULL,NULL,'2024-01-10 22:50:58','2024-01-10 22:50:58'),(220,1,NULL,2,1,'2024-01-05 21:55:00',NULL,0,'2024-01-11 16:54:20','2024-01-11 16:54:20'),(221,1,NULL,2,1,'2024-01-05 21:55:00',NULL,NULL,'2024-01-11 16:54:20','2024-01-11 16:54:20'),(223,1,NULL,1,1,'2024-01-05 21:55:00',NULL,NULL,'2024-01-11 16:56:51','2024-01-11 16:56:51'),(225,1,NULL,1,1,'2024-01-05 21:52:00',NULL,NULL,'2024-01-11 16:57:22','2024-01-11 16:57:22'),(227,1,NULL,1,1,'2024-01-05 21:49:00',NULL,NULL,'2024-01-11 16:57:38','2024-01-11 16:57:38'),(229,1,NULL,1,1,'2024-01-05 21:48:00',NULL,NULL,'2024-01-11 16:57:59','2024-01-11 16:57:59');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entrytypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `titleFormat` varchar(255) DEFAULT NULL,
  `slugTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `slugTranslationKeyFormat` text,
  `showStatusField` tinyint(1) DEFAULT '1',
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ybldbabzlfzsqxgbapinkghvsascwqpekjai` (`name`,`sectionId`),
  KEY `idx_spbyxoolcpahibjnceudkvyrehcpspjiduqi` (`handle`,`sectionId`),
  KEY `idx_fnenbiqlkqmddirxuoamzycvlisyxjrpedty` (`sectionId`),
  KEY `idx_cenliszxpqxffgkvwxoyhnujipzzgrztgknd` (`fieldLayoutId`),
  KEY `idx_xgwajrvqowuftmttfmrlmsjopeggxcouwvaj` (`dateDeleted`),
  CONSTRAINT `fk_jykdbbkxxiorzvhjkterbkxgcvzwmmmdjkey` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ubiqbpcagnqusmapmmabyxkyusbmqpsimklq` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
INSERT INTO `entrytypes` VALUES (1,1,1,'Default','default',1,'site',NULL,NULL,'site',NULL,1,1,'2024-01-05 15:13:17','2024-01-05 15:13:17',NULL,'6b5f5717-efc9-40c6-9d68-97b86792a46c'),(2,1,2,'alcohol drinks','alcoholDrinks',1,'site',NULL,NULL,'site',NULL,1,2,'2024-01-05 15:18:37','2024-01-05 15:18:37','2024-01-11 16:58:17','71b42945-5a4c-4853-b342-f744d52ec12d'),(3,2,3,'About us','aboutUs',0,'site',NULL,'{section.name|raw}','site',NULL,1,1,'2024-01-05 15:47:11','2024-01-05 23:43:39',NULL,'e671db06-f0c3-45b9-a032-192145ab9bc5'),(4,3,4,'Default','default',1,'site',NULL,NULL,'site',NULL,1,1,'2024-01-05 17:14:11','2024-01-05 17:14:11','2024-01-05 17:38:01','3cf61788-4e7a-418d-9219-ea22fe1f1335'),(5,4,5,'home','home',0,'site',NULL,'{section.name|raw}','site',NULL,1,1,'2024-01-05 17:43:07','2024-01-05 17:43:07',NULL,'597ef37d-ecf5-4ed9-92ef-7b0f956184dd'),(6,5,6,'Default','default',1,'site',NULL,NULL,'site',NULL,1,1,'2024-01-05 21:36:57','2024-01-05 21:36:57','2024-01-05 21:37:18','029865cd-48a4-412f-990e-701dc601088b'),(7,6,11,'Default','default',1,'site',NULL,NULL,'site',NULL,1,1,'2024-01-06 15:29:25','2024-01-06 15:29:25','2024-01-06 15:29:36','92f7ea34-40b1-4747-a674-9e939426bcb8'),(8,7,12,'Default','default',1,'site',NULL,NULL,'site',NULL,1,1,'2024-01-06 18:03:43','2024-01-06 18:03:43','2024-01-06 18:05:32','8591e77c-9d7e-4084-9e69-f0b63a984657'),(9,8,13,'Default','default',1,'site',NULL,NULL,'site',NULL,1,1,'2024-01-10 22:00:06','2024-01-10 22:00:06',NULL,'312c1641-3732-473d-82d8-212a18bc8443');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldgroups`
--

DROP TABLE IF EXISTS `fieldgroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldgroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vijlyugxbyetxdtvmyfphshzfnetgauukuke` (`name`),
  KEY `idx_dctqjapuioquukspeprmmaacymafxurjrfeb` (`dateDeleted`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldgroups`
--

LOCK TABLES `fieldgroups` WRITE;
/*!40000 ALTER TABLE `fieldgroups` DISABLE KEYS */;
INSERT INTO `fieldgroups` VALUES (1,'Common','2023-12-26 19:45:34','2023-12-26 19:45:34',NULL,'3d9e1db9-d8e4-4a7c-9a47-ca0b0dac0261'),(2,'Drinks','2024-01-05 15:19:49','2024-01-05 15:20:27',NULL,'892e899e-bc4d-426a-abb8-850855a6fc7c'),(3,'About us','2024-01-05 17:02:44','2024-01-05 17:02:44',NULL,'e5ae6272-fc40-4a83-ae00-6f7847500ae8'),(4,'home','2024-01-05 17:44:32','2024-01-05 17:44:32',NULL,'a16af4de-9170-42ba-9340-97ad4abfb3b2'),(5,'store categories','2024-01-10 22:01:07','2024-01-10 22:03:59',NULL,'8edf0eb0-db84-407e-8941-f20dada533ee');
/*!40000 ALTER TABLE `fieldgroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayoutfields`
--

DROP TABLE IF EXISTS `fieldlayoutfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayoutfields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `layoutId` int NOT NULL,
  `tabId` int NOT NULL,
  `fieldId` int NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kdtvmungculxjdoyifybsnfxkakozxzsjvio` (`layoutId`,`fieldId`),
  KEY `idx_cnemszhkfdneggvjzsannhsqzmeuvwwlcnik` (`sortOrder`),
  KEY `idx_rnxssdlqgyqihpjavwjwyxlprxtbahgpkxlj` (`tabId`),
  KEY `idx_lfapgdnwijmqfxooctcyccnfwxssyxxxptwi` (`fieldId`),
  CONSTRAINT `fk_fzmarqpbyctpqwnzkzrzudcoztyrkkydctis` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_optdluzvljjjblzmfzmajesdakjdkffccmza` FOREIGN KEY (`tabId`) REFERENCES `fieldlayouttabs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rfitnhekhiihomramjpdillglorikepwzzqr` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayoutfields`
--

LOCK TABLES `fieldlayoutfields` WRITE;
/*!40000 ALTER TABLE `fieldlayoutfields` DISABLE KEYS */;
INSERT INTO `fieldlayoutfields` VALUES (20,5,13,13,0,0,'2024-01-05 18:44:28','2024-01-05 18:44:28','3d470e7d-058d-4cfa-bb97-5050c75161fd'),(21,5,13,8,0,2,'2024-01-05 18:44:28','2024-01-05 18:44:28','61d02600-1878-46b0-ac9d-efe63c6d359a'),(22,5,13,9,0,3,'2024-01-05 18:44:28','2024-01-05 18:44:28','3766bff8-965f-46b9-acbe-26e683409547'),(23,5,13,10,0,4,'2024-01-05 18:44:28','2024-01-05 18:44:28','42f481a0-9645-40fb-ad6a-991a8c7d9be2'),(46,3,23,13,0,1,'2024-01-05 23:43:39','2024-01-05 23:43:39','d8778b68-fb34-42eb-99e5-316d32fda88f'),(47,3,23,8,0,2,'2024-01-05 23:43:39','2024-01-05 23:43:39','babe32f5-a77b-43e7-ab7a-3059332c0ead'),(48,3,23,9,0,3,'2024-01-05 23:43:39','2024-01-05 23:43:39','9aade723-537c-47f9-b868-31395355c2c1'),(49,3,23,10,0,4,'2024-01-05 23:43:39','2024-01-05 23:43:39','27098bb6-3cf2-454a-880b-34102ecbef60'),(65,1,32,15,0,1,'2024-01-10 22:12:09','2024-01-10 22:12:09','7b9a2655-1e22-4192-8a47-007a5cb79a87'),(66,1,32,14,0,2,'2024-01-10 22:12:09','2024-01-10 22:12:09','588fa657-e5b2-4b0d-ae20-6ea96629128d'),(67,1,32,3,0,3,'2024-01-10 22:12:09','2024-01-10 22:12:09','61f92756-0e74-4139-8bdd-12e63ed4bde3'),(68,1,32,1,0,4,'2024-01-10 22:12:09','2024-01-10 22:12:09','41f6fb71-4b07-4001-8552-24372935803f'),(69,1,32,4,0,5,'2024-01-10 22:12:09','2024-01-10 22:12:09','5d389dd6-6c58-4d3c-8110-872e41aad113'),(70,1,32,5,0,6,'2024-01-10 22:12:09','2024-01-10 22:12:09','66c4e431-5dd4-413e-a9d1-c5e1d3cdb964'),(71,2,33,15,0,1,'2024-01-10 22:12:17','2024-01-10 22:12:17','017cfa83-fb84-401e-9660-de00ff07cbb5'),(72,2,33,14,0,2,'2024-01-10 22:12:17','2024-01-10 22:12:17','e4471fc8-b98f-4e9c-bdb0-d1b9401e39bb'),(73,2,33,1,0,3,'2024-01-10 22:12:17','2024-01-10 22:12:17','cac3bcd9-c31d-4f2d-9b87-3645a5f4de78'),(74,2,33,5,0,4,'2024-01-10 22:12:17','2024-01-10 22:12:17','458f96ec-f5db-4885-84b7-605e159cfcab'),(75,2,33,4,0,5,'2024-01-10 22:12:17','2024-01-10 22:12:17','f04307e1-e2ef-407a-8630-5f557fce448b'),(76,2,33,3,0,6,'2024-01-10 22:12:17','2024-01-10 22:12:17','0b89c09e-5d3d-4933-9be4-5bd01a324d95');
/*!40000 ALTER TABLE `fieldlayoutfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayouts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qwmcugttlzwmqimmjipyvpteipfwytiznnyk` (`dateDeleted`),
  KEY `idx_bvbgxgygiyfsejphxfukybvfebnoudsbpydm` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
INSERT INTO `fieldlayouts` VALUES (1,'craft\\elements\\Entry','2024-01-05 15:13:17','2024-01-05 15:13:17',NULL,'a24f6f96-2c95-4738-ba3d-73f41b845102'),(2,'craft\\elements\\Entry','2024-01-05 15:18:37','2024-01-05 15:18:37','2024-01-11 16:58:17','f4e014f7-5702-4894-9e80-6f6f481907bc'),(3,'craft\\elements\\Entry','2024-01-05 15:47:11','2024-01-05 15:47:11',NULL,'606721de-4e04-4be0-8342-8dd40d60e385'),(4,'craft\\elements\\Entry','2024-01-05 17:14:11','2024-01-05 17:14:11','2024-01-05 17:38:01','fbe5abda-9c76-4f11-93d1-e66d64dc1d68'),(5,'craft\\elements\\Entry','2024-01-05 17:43:07','2024-01-05 17:43:07',NULL,'959111c6-5810-40f7-af4c-a8393e241bff'),(6,'craft\\elements\\Entry','2024-01-05 21:36:57','2024-01-05 21:36:57','2024-01-05 21:37:18','f47c1c12-61b0-421e-a235-9f60c2a39929'),(7,'craft\\elements\\Asset','2024-01-05 23:17:14','2024-01-05 23:17:14','2024-01-05 23:18:24','ec10a72c-c80b-44e4-8c22-a0183195607b'),(8,'craft\\elements\\Asset','2024-01-05 23:19:52','2024-01-05 23:19:52',NULL,'e3587594-ffc4-4e9d-bffd-8a3e848cf461'),(9,'craft\\elements\\Asset','2024-01-06 00:16:23','2024-01-06 00:16:23',NULL,'81516ae8-d3f5-4f39-802c-63a89a4b21b9'),(10,'craft\\elements\\Asset','2024-01-06 00:19:49','2024-01-06 00:19:49',NULL,'1dea624a-e24b-4dfd-b31b-c5ec1d364999'),(11,'craft\\elements\\Entry','2024-01-06 15:29:25','2024-01-06 15:29:25','2024-01-06 15:29:36','08206724-ef31-4da2-8b30-260855e7f0fd'),(12,'craft\\elements\\Entry','2024-01-06 18:03:43','2024-01-06 18:03:43','2024-01-06 18:05:32','fe9062a6-942f-4a95-b116-8e9333dc2009'),(13,'craft\\elements\\Entry','2024-01-10 22:00:06','2024-01-10 22:00:06',NULL,'ef29586e-d08d-400d-8073-2c503f71ffac');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayouttabs`
--

DROP TABLE IF EXISTS `fieldlayouttabs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayouttabs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `layoutId` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `settings` text,
  `elements` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ucnmqygboyftheweqpoieixbggfkzbjtavvg` (`sortOrder`),
  KEY `idx_dtmarnreswkzrsqdricmswghfalveelorpbn` (`layoutId`),
  CONSTRAINT `fk_ihrpwuptscslilvlxbjbuiivrxxjzderezup` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayouttabs`
--

LOCK TABLES `fieldlayouttabs` WRITE;
/*!40000 ALTER TABLE `fieldlayouttabs` DISABLE KEYS */;
INSERT INTO `fieldlayouttabs` VALUES (6,4,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"inputType\":null,\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"07c4db01-0ca1-4e21-932f-eb31a3cb163a\",\"userCondition\":null,\"elementCondition\":null}]',1,'2024-01-05 17:14:11','2024-01-05 17:14:11','e6cbb962-2ebf-4dc7-afa7-7d9e9d379069'),(13,5,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"2e555d3a-b77b-4756-8178-b9e8a83dda5b\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"224b5a40-80ce-447d-8be5-4e349e553bcd\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"inputType\":null,\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":\"title\",\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"3428543b-7253-40e7-b639-e0f415bc4ca7\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"6c5bc96b-3fcb-47e9-a0c1-d6c3916e0e76\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"e1d95b86-a3f8-45e9-b985-8605dde5b9d4\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"4a03d6f6-2595-4bbb-92b8-51417875f44b\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"9c58ac58-2bbb-49cf-8e49-c1f4f9364f6a\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"df8bc38b-de99-413e-bbd0-186611536fdd\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"b957af1b-f8d8-43a7-9958-98856e4707c6\"}]',1,'2024-01-05 18:44:28','2024-01-05 18:44:28','c6aee18b-8016-4b8c-967a-5bdcd0bd8acf'),(15,6,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"inputType\":null,\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"5c75b1a5-37cc-42e8-b6c0-6c6adaf672c1\",\"userCondition\":null,\"elementCondition\":null}]',1,'2024-01-05 21:36:57','2024-01-05 21:36:57','35818a80-fb45-447a-a71e-e8c03439cb97'),(18,7,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\",\"inputType\":null,\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"40e10630-9cd4-479c-963a-e347725b452c\",\"userCondition\":null,\"elementCondition\":null}]',1,'2024-01-05 23:17:14','2024-01-05 23:17:14','f833314e-a056-4e43-a853-8f02e841d2b1'),(19,8,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\",\"inputType\":null,\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"e1af96a8-8fa8-4ac6-ac6a-fbf57459099f\",\"userCondition\":null,\"elementCondition\":null}]',1,'2024-01-05 23:19:52','2024-01-05 23:19:52','b1aa57b7-fd1f-4432-9b4e-1d0a125a6ced'),(23,3,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"inputType\":null,\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":\"Header1\",\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"cc4d3ae6-bce3-4a7b-880d-dd2f3f55df71\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"1d74dfa1-a211-431a-9842-b146e7b8c026\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"224b5a40-80ce-447d-8be5-4e349e553bcd\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"84c99f48-1656-4121-a6d9-31d4d9523f7d\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"e1d95b86-a3f8-45e9-b985-8605dde5b9d4\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"c159eb55-2337-4a60-b0b3-3f129ef5643e\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"9c58ac58-2bbb-49cf-8e49-c1f4f9364f6a\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"a30c3e98-99f7-401f-8072-93d98d975d4c\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"b957af1b-f8d8-43a7-9958-98856e4707c6\"}]',1,'2024-01-05 23:43:39','2024-01-05 23:43:39','cab7f228-9d77-4c95-9ab3-42ff36b85f3a'),(27,9,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\",\"inputType\":null,\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"fdb68d94-03a3-42d8-9311-1f38ea94cd2c\",\"userCondition\":null,\"elementCondition\":null}]',1,'2024-01-06 00:16:23','2024-01-06 00:16:23','62e31e6a-94a0-4d0f-bd41-adc1916f8e06'),(28,10,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\",\"inputType\":null,\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"29b73afa-abc7-46de-9545-bf728b43346c\",\"userCondition\":null,\"elementCondition\":null}]',1,'2024-01-06 00:19:49','2024-01-06 00:19:49','5c975bba-4d1c-4ebd-ba80-865cfd5a8c19'),(29,11,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"inputType\":null,\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"2fe82f13-1d55-4456-ba2b-3e03eaf94c1c\",\"userCondition\":null,\"elementCondition\":null}]',1,'2024-01-06 15:29:25','2024-01-06 15:29:25','26b26c42-0c43-442b-b091-adce3e375948'),(30,12,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"inputType\":null,\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"1dc4c2bc-76fa-4588-8edd-a5e814437790\",\"userCondition\":null,\"elementCondition\":null}]',1,'2024-01-06 18:03:43','2024-01-06 18:03:43','eee6d87c-b5d3-4825-b4fb-bf7afab501d8'),(31,13,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"inputType\":null,\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"c973c94b-5f2e-463e-a721-52bff1de6523\",\"userCondition\":null,\"elementCondition\":null}]',1,'2024-01-10 22:00:06','2024-01-10 22:00:06','58a50282-1139-4afc-83a8-1c35084b3363'),(32,1,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"inputType\":null,\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":\"Drink Name\",\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"ccc38710-b902-4d94-aa34-5234ded60940\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"5e87acfe-a138-4181-ada3-52eaad1db004\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"9c722366-6570-4938-b9ff-9f3d55620afe\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"ff6668ea-4c84-4f14-a628-ee8bad489b0c\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"cbc6efb9-07dd-46a7-8965-d8c5bf50cd40\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"0b48bee4-9254-430c-83c4-0bf7ba5777a0\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"f0f0a2ff-68fd-4217-93b1-7318025da83b\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"1c0a3a10-b58d-41f3-ba49-0d5fdb0f412f\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"2fdf6f3c-8796-4125-a22a-392fe3486fef\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"37fcb3b0-1f1d-4d90-92ea-c5f897723120\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"51b05e04-81a8-4074-bb1c-64f3090a35c6\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"a900187f-5a13-4a96-9cdb-6ff9f87c5237\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"a5b7d0fb-075f-4551-ab53-c7a37d7ea905\"}]',1,'2024-01-10 22:12:09','2024-01-10 22:12:09','a8a8b882-b441-4e28-9c9d-953dda574efe'),(33,2,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"inputType\":null,\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":\"Drink Name\",\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"29764101-4023-4a30-aef2-d08024b0233e\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"9b909901-3cf6-4619-af60-5c9467c66f4d\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"9c722366-6570-4938-b9ff-9f3d55620afe\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"a94ca27a-5b01-400a-a63d-c9fafae4d35f\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"cbc6efb9-07dd-46a7-8965-d8c5bf50cd40\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"4259f1f9-ad16-4df3-9eb7-7669a9a60f4c\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"2fdf6f3c-8796-4125-a22a-392fe3486fef\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"4c86c31f-cbc0-47c3-ab49-94ba6c6f73cf\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"a5b7d0fb-075f-4551-ab53-c7a37d7ea905\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"811eb3ef-270e-4950-8827-97e09c3a07a8\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"51b05e04-81a8-4074-bb1c-64f3090a35c6\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"79fb3185-4d19-4811-809a-22f430fe1b40\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"f0f0a2ff-68fd-4217-93b1-7318025da83b\"}]',1,'2024-01-10 22:12:17','2024-01-10 22:12:17','90c6a0b6-edb9-43e1-8ddc-c4172b0b9724');
/*!40000 ALTER TABLE `fieldlayouttabs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xlyyfbjxkizinephtojhzzkeooligszrbyum` (`handle`,`context`),
  KEY `idx_gijzarvfpgvoepwyvweuyxdurpqsxhgtfszl` (`groupId`),
  KEY `idx_rngragppltnbegwipdjogrghcegpnnobbkhx` (`context`),
  CONSTRAINT `fk_mbivbsbsasqpaukzkgnwkcvyfymsevpdozjt` FOREIGN KEY (`groupId`) REFERENCES `fieldgroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
INSERT INTO `fields` VALUES (1,2,'introduction','introduction','global','fzsqwxge','short introduction next to drink page',0,'none',NULL,'abmat\\tinymce\\Field','{\"availableTransforms\":\"\",\"availableVolumes\":\"\",\"columnType\":\"text\",\"purifierConfig\":\"Default.json\",\"purifyHtml\":true,\"removeEmptyTags\":false,\"removeInlineStyles\":false,\"removeNbsp\":false,\"showHtmlButtonForNonAdmins\":false,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"tinymceConfig\":\"Default.json\"}','2024-01-05 15:29:55','2024-01-05 17:00:23','2fdf6f3c-8796-4125-a22a-392fe3486fef'),(2,1,'Page coppy','pageCoppy','global','wixbjycs',NULL,0,'none',NULL,'abmat\\tinymce\\Field','{\"availableTransforms\":\"\",\"availableVolumes\":\"\",\"columnType\":\"text\",\"purifierConfig\":\"Default.json\",\"purifyHtml\":true,\"removeEmptyTags\":false,\"removeInlineStyles\":false,\"removeNbsp\":false,\"showHtmlButtonForNonAdmins\":false,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"tinymceConfig\":\"Default.json\"}','2024-01-05 15:36:19','2024-01-05 15:36:19','bdfa53af-e91a-4d84-824e-a115eec9cd04'),(3,2,'Price drinks','priceDrinks','global','zfzzucta','The price of the drinks (number only)',0,'none',NULL,'craft\\fields\\Number','{\"decimals\":2,\"defaultValue\":null,\"max\":null,\"min\":0,\"prefix\":\"€\",\"previewCurrency\":\"EUR\",\"previewFormat\":\"currency\",\"size\":null,\"suffix\":null}','2024-01-05 15:37:31','2024-01-05 15:38:26','f0f0a2ff-68fd-4217-93b1-7318025da83b'),(4,2,'Alcohol percentage','alcoholPercentage','global','rksiqext','it gives the percentage of alcohol in the drinks',0,'none',NULL,'craft\\fields\\Number','{\"decimals\":0,\"defaultValue\":null,\"max\":null,\"min\":0,\"prefix\":null,\"previewCurrency\":null,\"previewFormat\":\"decimal\",\"size\":null,\"suffix\":\"%\"}','2024-01-05 15:39:30','2024-01-05 15:39:30','51b05e04-81a8-4074-bb1c-64f3090a35c6'),(5,2,'Information Drinks','informationDrinks','global','bnfajgjp',NULL,0,'none',NULL,'abmat\\tinymce\\Field','{\"availableTransforms\":\"\",\"availableVolumes\":\"\",\"columnType\":\"text\",\"purifierConfig\":\"Default.json\",\"purifyHtml\":true,\"removeEmptyTags\":false,\"removeInlineStyles\":false,\"removeNbsp\":false,\"showHtmlButtonForNonAdmins\":false,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"tinymceConfig\":\"Default.json\"}','2024-01-05 15:42:00','2024-01-05 15:42:00','a5b7d0fb-075f-4551-ab53-c7a37d7ea905'),(6,1,'Info about','infoAbout','global','tqqdapum',NULL,0,'none',NULL,'abmat\\tinymce\\Field','{\"availableTransforms\":\"\",\"availableVolumes\":\"\",\"columnType\":\"text\",\"purifierConfig\":\"Default.json\",\"purifyHtml\":true,\"removeEmptyTags\":false,\"removeInlineStyles\":false,\"removeNbsp\":false,\"showHtmlButtonForNonAdmins\":false,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"tinymceConfig\":\"Default.json\"}','2024-01-05 17:03:16','2024-01-05 17:03:31','3d1094d4-9576-466e-8f54-d264d7286642'),(8,4,'ons assortiment','onsAssortiment','global','eufivvyq','Dit is het gedeelte assortimen',0,'none',NULL,'abmat\\tinymce\\Field','{\"availableTransforms\":\"\",\"availableVolumes\":\"\",\"columnType\":\"text\",\"purifierConfig\":\"Default.json\",\"purifyHtml\":true,\"removeEmptyTags\":false,\"removeInlineStyles\":false,\"removeNbsp\":false,\"showHtmlButtonForNonAdmins\":false,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"tinymceConfig\":\"Default.json\"}','2024-01-05 17:45:40','2024-01-05 17:45:40','e1d95b86-a3f8-45e9-b985-8605dde5b9d4'),(9,4,'enkel alcohol','enkelAlcohol','global','rctpvesc','Dit is het gedeelte enkel alcohol',0,'none',NULL,'abmat\\tinymce\\Field','{\"availableTransforms\":\"\",\"availableVolumes\":\"\",\"columnType\":\"text\",\"purifierConfig\":\"Default.json\",\"purifyHtml\":true,\"removeEmptyTags\":false,\"removeInlineStyles\":false,\"removeNbsp\":false,\"showHtmlButtonForNonAdmins\":false,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"tinymceConfig\":\"Default.json\"}','2024-01-05 17:46:03','2024-01-05 17:46:03','9c58ac58-2bbb-49cf-8e49-c1f4f9364f6a'),(10,4,'what we are all about','whatWeAreAllAbout','global','kbjjojsw','Dit is het gedeelte what we are all about',0,'none',NULL,'abmat\\tinymce\\Field','{\"availableTransforms\":\"\",\"availableVolumes\":\"\",\"columnType\":\"text\",\"purifierConfig\":\"Default.json\",\"purifyHtml\":true,\"removeEmptyTags\":false,\"removeInlineStyles\":false,\"removeNbsp\":false,\"showHtmlButtonForNonAdmins\":false,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"tinymceConfig\":\"Default.json\"}','2024-01-05 17:46:42','2024-01-05 17:46:42','b957af1b-f8d8-43a7-9958-98856e4707c6'),(12,3,'test','test','global','bqwgakef',NULL,0,'none',NULL,'craft\\redactor\\Field','{\"availableTransforms\":\"\",\"availableVolumes\":\"\",\"columnType\":\"text\",\"configSelectionMode\":\"choose\",\"defaultTransform\":\"\",\"manualConfig\":\"\",\"purifierConfig\":null,\"purifyHtml\":true,\"redactorConfig\":null,\"removeEmptyTags\":false,\"removeInlineStyles\":false,\"removeNbsp\":false,\"showHtmlButtonForNonAdmins\":false,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"uiMode\":\"enlarged\"}','2024-01-05 17:55:13','2024-01-05 17:55:13','e9c3a8c7-917d-4e97-9b9b-c9113fac435a'),(13,4,'header1','header1','global','lwhrkzwq',NULL,0,'none',NULL,'abmat\\tinymce\\Field','{\"availableTransforms\":\"\",\"availableVolumes\":\"\",\"columnType\":\"text\",\"purifierConfig\":\"Default.json\",\"purifyHtml\":true,\"removeEmptyTags\":false,\"removeInlineStyles\":false,\"removeNbsp\":false,\"showHtmlButtonForNonAdmins\":false,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"tinymceConfig\":\"Default.json\"}','2024-01-05 18:44:02','2024-01-05 18:44:10','224b5a40-80ce-447d-8be5-4e349e553bcd'),(14,2,'drinkImageSmall','drinkimagesmall','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":null,\"branchLimit\":null,\"defaultUploadLocationSource\":\"volume:a0cd8b19-e1b7-4968-86c8-25f1345172a0\",\"defaultUploadLocationSubpath\":null,\"localizeRelations\":false,\"maintainHierarchy\":false,\"maxRelations\":null,\"minRelations\":null,\"previewMode\":\"full\",\"restrictFiles\":false,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":\"volume:a0cd8b19-e1b7-4968-86c8-25f1345172a0\",\"restrictedLocationSubpath\":null,\"selectionCondition\":{\"elementType\":\"craft\\\\elements\\\\Asset\",\"fieldContext\":\"global\",\"class\":\"craft\\\\elements\\\\conditions\\\\assets\\\\AssetCondition\"},\"selectionLabel\":null,\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":[\"volume:a0cd8b19-e1b7-4968-86c8-25f1345172a0\"],\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"large\"}','2024-01-05 23:31:25','2024-01-06 16:13:01','cbc6efb9-07dd-46a7-8965-d8c5bf50cd40'),(15,5,'store Categories','storeCategories','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Entries','{\"allowSelfRelations\":false,\"branchLimit\":null,\"localizeRelations\":false,\"maintainHierarchy\":false,\"maxRelations\":null,\"minRelations\":null,\"selectionCondition\":{\"elementType\":\"craft\\\\elements\\\\Entry\",\"fieldContext\":\"global\",\"class\":\"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\"},\"selectionLabel\":null,\"showSiteMenu\":false,\"sources\":[\"section:18e745c4-9c85-4f4c-9219-09e2ba15599c\"],\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":null}','2024-01-10 22:05:11','2024-01-10 22:05:11','9c722366-6570-4938-b9ff-9f3d55620afe');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `globalsets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_hnappwfkasdqrhhmwzmprehaqmmjpdjqopal` (`name`),
  KEY `idx_siqigdegsplpyjbdpvxqnsdhjcythujwyicx` (`handle`),
  KEY `idx_wqijqkgeixoeqegfxntbbkqwalqgaobhjagj` (`fieldLayoutId`),
  KEY `idx_mksjmanfokyzdyrfenhezxojmmeacvkxnhwf` (`sortOrder`),
  CONSTRAINT `fk_ioygqqsendqoniezxhyhupjpmrqnfnfkgtbf` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uneftvvheeacpndmcqquzrduwohygglzusfs` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqlschemas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` text,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqltokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ulmzelcfdjembmwwrhekyrdmtieltdvloywt` (`accessToken`),
  UNIQUE KEY `idx_stcrktsihvrnjnogcvsltpyzefcdaezfumlz` (`name`),
  KEY `fk_sqvlprvaumvikqoljaaguernoqsumfrzqleq` (`schemaId`),
  CONSTRAINT `fk_sqvlprvaumvikqoljaaguernoqsumfrzqleq` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransformindex`
--

DROP TABLE IF EXISTS `imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransformindex` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assetId` int NOT NULL,
  `transformer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `transformString` varchar(255) NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qvmzvgilshwkuiflxmzgruwjjyfycizobsfe` (`assetId`,`transformString`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransformindex`
--

LOCK TABLES `imagetransformindex` WRITE;
/*!40000 ALTER TABLE `imagetransformindex` DISABLE KEYS */;
INSERT INTO `imagetransformindex` VALUES (1,143,'craft\\imagetransforms\\ImageTransformer','Coca-Cola.jpg',NULL,'_10x34_crop_center-center_none',1,0,0,'2024-01-05 23:21:38','2024-01-05 23:21:38','2024-01-05 23:22:17','34d2df59-2f8f-4383-860a-43de7d3ac994'),(2,143,'craft\\imagetransforms\\ImageTransformer','Coca-Cola.jpg',NULL,'_21x68_crop_center-center_none',1,0,0,'2024-01-05 23:21:39','2024-01-05 23:21:39','2024-01-05 23:21:39','f532b55f-e089-43c5-88c5-e77c0aee5f8a'),(3,169,'craft\\imagetransforms\\ImageTransformer','absolut_vodka.webp',NULL,'_10x34_crop_center-center_none',1,0,0,'2024-01-06 00:05:22','2024-01-06 00:05:22','2024-01-06 00:05:33','171e9e5b-e182-4ac0-a9a9-f308f23ce57a'),(4,169,'craft\\imagetransforms\\ImageTransformer','absolut_vodka.webp',NULL,'_21x68_crop_center-center_none',1,0,0,'2024-01-06 00:05:23','2024-01-06 00:05:23','2024-01-06 00:05:23','27a3ac4c-d2f1-4edf-9c37-a44b30f5246b'),(5,170,'craft\\imagetransforms\\ImageTransformer','Fanta_bb.jpg',NULL,'_18x34_crop_center-center_none',1,0,0,'2024-01-06 00:05:36','2024-01-06 00:05:36','2024-01-06 00:05:42','cfcf7822-d0d7-4e80-bbe5-a2854d71194d'),(6,170,'craft\\imagetransforms\\ImageTransformer','Fanta_bb.jpg',NULL,'_36x68_crop_center-center_none',1,0,0,'2024-01-06 00:05:36','2024-01-06 00:05:36','2024-01-06 00:05:36','53c797ac-bff0-4ffa-b0fc-76ee9b0d0817'),(7,171,'craft\\imagetransforms\\ImageTransformer','jack_daniels.webp',NULL,'_10x34_crop_center-center_none',1,0,0,'2024-01-06 00:05:44','2024-01-06 00:05:44','2024-01-06 00:05:51','39f30f1e-16bc-4ca5-9279-8b99bcece172'),(8,171,'craft\\imagetransforms\\ImageTransformer','jack_daniels.webp',NULL,'_21x68_crop_center-center_none',1,0,0,'2024-01-06 00:05:44','2024-01-06 00:05:44','2024-01-06 00:05:45','56126536-3755-4286-953a-fefedcabc241'),(9,172,'craft\\imagetransforms\\ImageTransformer','The_famous_grouse.webp',NULL,'_8x34_crop_center-center_none',1,0,0,'2024-01-06 00:05:55','2024-01-06 00:05:55','2024-01-06 00:06:11','8ba02c24-127b-4fbe-95e0-b31367ced49e'),(10,172,'craft\\imagetransforms\\ImageTransformer','The_famous_grouse.webp',NULL,'_17x68_crop_center-center_none',1,0,0,'2024-01-06 00:05:55','2024-01-06 00:05:55','2024-01-06 00:05:55','eb145f6b-fbe7-409b-a0d0-c69e914852d6'),(11,173,'craft\\imagetransforms\\ImageTransformer','smirnof_vodka.webp',NULL,'_9x34_crop_center-center_none',1,0,0,'2024-01-06 00:06:14','2024-01-06 00:06:14','2024-01-06 00:06:23','965b46a2-709a-47c1-9165-ddfe3b78a291'),(12,173,'craft\\imagetransforms\\ImageTransformer','smirnof_vodka.webp',NULL,'_18x68_crop_center-center_none',1,0,0,'2024-01-06 00:06:14','2024-01-06 00:06:14','2024-01-06 00:06:14','eba40017-82d1-405c-85ce-a8878ab2a748'),(13,190,'craft\\imagetransforms\\ImageTransformer','TVGD_logo.png',NULL,'_34x12_crop_center-center_none',1,0,0,'2024-01-06 00:18:06','2024-01-06 00:18:06','2024-01-06 00:18:22','f0bde225-2e51-4fbd-9ce4-ca722754f0b3'),(14,190,'craft\\imagetransforms\\ImageTransformer','TVGD_logo.png',NULL,'_68x25_crop_center-center_none',1,0,0,'2024-01-06 00:18:06','2024-01-06 00:18:06','2024-01-06 00:18:07','edc31e59-3285-4701-8162-e7fe4bc4eff4'),(15,189,'craft\\imagetransforms\\ImageTransformer','Drinking_orange.jpg',NULL,'_22x34_crop_center-center_none',1,0,0,'2024-01-06 00:18:06','2024-01-06 00:18:06','2024-01-06 00:18:23','133cee68-b323-47ed-a675-3ee5e29bbf73'),(16,189,'craft\\imagetransforms\\ImageTransformer','Drinking_orange.jpg',NULL,'_45x68_crop_center-center_none',1,0,0,'2024-01-06 00:18:06','2024-01-06 00:18:06','2024-01-06 00:18:07','06c7e4de-7a89-40cc-81bd-08438adb1c90'),(17,188,'craft\\imagetransforms\\ImageTransformer','Bottle_Jack.jpg',NULL,'_22x34_crop_center-center_none',1,0,0,'2024-01-06 00:18:06','2024-01-06 00:18:06','2024-01-06 00:18:23','af55340a-446f-4655-bb99-cd193427a275'),(18,188,'craft\\imagetransforms\\ImageTransformer','Bottle_Jack.jpg',NULL,'_45x68_crop_center-center_none',1,0,0,'2024-01-06 00:18:06','2024-01-06 00:18:06','2024-01-06 00:18:07','d16c127c-a16c-443b-ae72-f80d7353b6c8'),(19,187,'craft\\imagetransforms\\ImageTransformer','assortiment.jpg',NULL,'_22x34_crop_center-center_none',1,0,0,'2024-01-06 00:18:06','2024-01-06 00:18:06','2024-01-06 00:18:24','4316f538-a8b4-48db-b3df-5e62664b2e76'),(20,187,'craft\\imagetransforms\\ImageTransformer','assortiment.jpg',NULL,'_45x68_crop_center-center_none',1,0,0,'2024-01-06 00:18:06','2024-01-06 00:18:06','2024-01-06 00:18:07','b6b5e273-a05c-4497-96ae-6000542b99eb'),(21,186,'craft\\imagetransforms\\ImageTransformer','apperitief.png',NULL,'_22x34_crop_center-center_none',1,0,0,'2024-01-06 00:18:06','2024-01-06 00:18:06','2024-01-06 00:18:24','4ef34eaf-ec1c-49db-8d32-8406986cae17'),(22,186,'craft\\imagetransforms\\ImageTransformer','apperitief.png',NULL,'_45x68_crop_center-center_none',1,0,0,'2024-01-06 00:18:06','2024-01-06 00:18:06','2024-01-06 00:18:08','4dd2c03f-6c63-496a-9b83-b8f4de50d0c8'),(23,185,'craft\\imagetransforms\\ImageTransformer','About_frontpage.jpg',NULL,'_24x34_crop_center-center_none',1,0,0,'2024-01-06 00:18:06','2024-01-06 00:18:06','2024-01-06 00:18:25','758e246d-a4fb-492c-9fbb-8f7d7abbf52c'),(24,185,'craft\\imagetransforms\\ImageTransformer','About_frontpage.jpg',NULL,'_48x68_crop_center-center_none',1,0,0,'2024-01-06 00:18:06','2024-01-06 00:18:06','2024-01-06 00:18:08','cef264ca-0e0a-4e12-aa02-5aff6d03574d'),(25,193,'craft\\imagetransforms\\ImageTransformer','vereniging.avif',NULL,'_34x22_crop_center-center_none',1,0,0,'2024-01-06 00:21:16','2024-01-06 00:21:16','2024-01-06 00:21:46','91322bbb-1f77-46d8-8814-a06814920005'),(26,193,'craft\\imagetransforms\\ImageTransformer','vereniging.avif',NULL,'_68x45_crop_center-center_none',1,0,0,'2024-01-06 00:21:16','2024-01-06 00:21:16','2024-01-06 00:21:18','5acd35a5-7844-4ad1-a3cb-75feda3f09e9'),(27,192,'craft\\imagetransforms\\ImageTransformer','ons_verhaal.jpg',NULL,'_22x34_crop_center-center_none',1,0,0,'2024-01-06 00:21:16','2024-01-06 00:21:16','2024-01-06 00:21:46','248d3fd0-c164-404d-92f5-da07e98bc8dc'),(28,192,'craft\\imagetransforms\\ImageTransformer','ons_verhaal.jpg',NULL,'_45x68_crop_center-center_none',1,0,0,'2024-01-06 00:21:16','2024-01-06 00:21:16','2024-01-06 00:21:18','528a2b5a-32e1-4cb5-bef9-ace50911a3b0'),(31,194,'craft\\imagetransforms\\ImageTransformer','About_frontpage.jpg',NULL,'_24x34_crop_center-center_none',1,0,0,'2024-01-06 00:21:48','2024-01-06 00:21:48','2024-01-06 00:23:00','5a877e83-4bd6-4d9e-bf6d-4599340996a1'),(32,194,'craft\\imagetransforms\\ImageTransformer','About_frontpage.jpg',NULL,'_48x68_crop_center-center_none',1,0,0,'2024-01-06 00:21:48','2024-01-06 00:21:48','2024-01-06 00:21:48','5f062a42-354b-4c69-9b6d-e5742c8c49ed'),(33,173,'craft\\imagetransforms\\ImageTransformer','smirnof_vodka.webp',NULL,'_drinksversion',1,0,0,'2024-01-06 15:54:46','2024-01-06 15:54:46','2024-01-06 15:54:46','6f77a18b-e95e-4aca-b680-99c652afff21'),(34,169,'craft\\imagetransforms\\ImageTransformer','absolut_vodka.webp',NULL,'_drinksversion',1,0,0,'2024-01-06 15:54:46','2024-01-06 15:54:46','2024-01-06 15:54:46','46ed5bd0-4d5b-43d5-a8bf-b94b5daea8d1'),(35,171,'craft\\imagetransforms\\ImageTransformer','jack_daniels.webp',NULL,'_drinksversion',1,0,0,'2024-01-06 15:54:46','2024-01-06 15:54:46','2024-01-06 15:54:46','e2ca3e60-d26d-441a-ba6c-753c0f73d105'),(36,172,'craft\\imagetransforms\\ImageTransformer','The_famous_grouse.webp',NULL,'_drinksversion',1,0,0,'2024-01-06 15:54:46','2024-01-06 15:54:46','2024-01-06 15:54:46','9f5a5c9d-0ff4-4fc9-b164-d5996cb14ae8'),(37,143,'craft\\imagetransforms\\ImageTransformer','Coca-Cola.jpg',NULL,'_drinksversion',1,0,0,'2024-01-06 15:54:46','2024-01-06 15:54:46','2024-01-06 15:54:47','88330f49-8ed9-4621-a25a-1cf30a8a5806'),(38,170,'craft\\imagetransforms\\ImageTransformer','Fanta_bb.jpg',NULL,'_drinksversion',1,0,0,'2024-01-06 15:54:46','2024-01-06 15:54:46','2024-01-06 15:54:47','ead6043c-0346-4723-94b0-7f510729d250'),(39,170,'craft\\imagetransforms\\ImageTransformer','Fanta_bb.jpg',NULL,'_63x120_crop_center-center_none',1,0,0,'2024-01-06 16:05:18','2024-01-06 16:05:18','2024-01-06 16:05:19','b97118a2-ff47-4161-b3e4-739078df6b4b'),(40,170,'craft\\imagetransforms\\ImageTransformer','Fanta_bb.jpg',NULL,'_127x240_crop_center-center_none',1,0,0,'2024-01-06 16:05:18','2024-01-06 16:05:18','2024-01-06 16:05:19','a97fec8a-1134-416c-99fb-254ef9503610'),(41,199,'craft\\imagetransforms\\ImageTransformer','passion_led_us_here.jpg',NULL,'_34x22_crop_center-center_none',1,0,0,'2024-01-10 20:49:54','2024-01-10 20:49:54','2024-01-10 20:50:09','7bc546c6-d0f8-4dfe-9b86-92c2fe35b12b'),(42,199,'craft\\imagetransforms\\ImageTransformer','passion_led_us_here.jpg',NULL,'_68x45_crop_center-center_none',1,0,0,'2024-01-10 20:49:54','2024-01-10 20:49:54','2024-01-10 20:49:54','36325a59-7a8f-434d-986c-2846cf672146'),(43,200,'craft\\imagetransforms\\ImageTransformer','ons_vereniging.jpg',NULL,'_34x22_crop_center-center_none',1,0,0,'2024-01-10 20:50:21','2024-01-10 20:50:21','2024-01-10 20:50:31','72ddc574-2c2c-471b-81c2-e29e328c2a42'),(44,200,'craft\\imagetransforms\\ImageTransformer','ons_vereniging.jpg',NULL,'_68x45_crop_center-center_none',1,0,0,'2024-01-10 20:50:21','2024-01-10 20:50:21','2024-01-10 20:50:21','5e78ac4e-2d41-44ae-8f09-a3f753de5f87'),(45,143,'craft\\imagetransforms\\ImageTransformer','Coca-Cola.jpg',NULL,'_38x120_crop_center-center_none',1,0,0,'2024-01-10 22:12:49','2024-01-10 22:12:49','2024-01-10 22:12:50','52633cb0-7486-40c4-859c-7db0611217af'),(46,143,'craft\\imagetransforms\\ImageTransformer','Coca-Cola.jpg',NULL,'_77x240_crop_center-center_none',1,0,0,'2024-01-10 22:12:49','2024-01-10 22:12:49','2024-01-10 22:12:51','6838ea32-fb51-41ba-9238-ccad9ffcc18d'),(47,172,'craft\\imagetransforms\\ImageTransformer','The_famous_grouse.webp',NULL,'_31x120_crop_center-center_none',1,0,0,'2024-01-10 22:13:03','2024-01-10 22:13:03','2024-01-10 22:13:05','ac5f0fbc-76f8-441e-bfc7-72fb312acd9e'),(48,172,'craft\\imagetransforms\\ImageTransformer','The_famous_grouse.webp',NULL,'_62x240_crop_center-center_none',1,0,0,'2024-01-10 22:13:03','2024-01-10 22:13:03','2024-01-10 22:13:04','4a2e10b9-5162-4e91-95fc-6201860d4531'),(49,171,'craft\\imagetransforms\\ImageTransformer','jack_daniels.webp',NULL,'_38x120_crop_center-center_none',1,0,0,'2024-01-10 22:13:15','2024-01-10 22:13:15','2024-01-10 22:13:17','a0c571e5-fc5f-4d2c-baf5-db0bf8abd1d5'),(50,171,'craft\\imagetransforms\\ImageTransformer','jack_daniels.webp',NULL,'_76x240_crop_center-center_none',1,0,0,'2024-01-10 22:13:16','2024-01-10 22:13:16','2024-01-10 22:13:17','82b4215f-452f-420d-9de8-704014b87c6c'),(51,169,'craft\\imagetransforms\\ImageTransformer','absolut_vodka.webp',NULL,'_38x120_crop_center-center_none',1,0,0,'2024-01-10 22:13:29','2024-01-10 22:13:29','2024-01-10 22:13:31','18cf1c4b-0923-4d9d-8136-93a1421cb62e'),(52,169,'craft\\imagetransforms\\ImageTransformer','absolut_vodka.webp',NULL,'_76x240_crop_center-center_none',1,0,0,'2024-01-10 22:13:29','2024-01-10 22:13:29','2024-01-10 22:13:31','21d995f6-6d22-480d-be37-3b01b8d863e6'),(53,173,'craft\\imagetransforms\\ImageTransformer','smirnof_vodka.webp',NULL,'_32x120_crop_center-center_none',1,0,0,'2024-01-10 22:13:44','2024-01-10 22:13:44','2024-01-10 22:13:46','00fd7745-ac7f-4587-b83d-0cbf9bcbf403'),(54,173,'craft\\imagetransforms\\ImageTransformer','smirnof_vodka.webp',NULL,'_64x240_crop_center-center_none',1,0,0,'2024-01-10 22:13:44','2024-01-10 22:13:44','2024-01-10 22:13:46','b556fae2-aadf-4db6-8f3b-eb6994984fc7');
/*!40000 ALTER TABLE `imagetransformindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransforms`
--

DROP TABLE IF EXISTS `imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransforms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop','letterbox') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `fill` varchar(11) DEFAULT NULL,
  `upscale` tinyint(1) NOT NULL DEFAULT '1',
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_jlyslxknrfdnwfyuicaznzwiuyduqjttilqc` (`name`),
  KEY `idx_rfslpbqczplnrrplgeyxefsaczmxaraszwqd` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransforms`
--

LOCK TABLES `imagetransforms` WRITE;
/*!40000 ALTER TABLE `imagetransforms` DISABLE KEYS */;
INSERT INTO `imagetransforms` VALUES (1,'drinksVersion','drinksversion','crop','center-center',NULL,200,NULL,NULL,'none',NULL,1,'2024-01-06 00:24:48','2024-01-06 00:24:48','2024-01-06 00:24:48','4228d972-2762-4d4c-b1a6-d69ac37ceefa');
/*!40000 ALTER TABLE `imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
INSERT INTO `info` VALUES (1,'4.5.14','4.5.3.0',0,'xkjhzycyutqh','3@axrihkhxlo','2023-12-26 19:45:34','2024-01-11 16:58:17','3a43448f-fd93-42c9-a0e3-9f0af956d88b');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matrixblocks`
--

DROP TABLE IF EXISTS `matrixblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matrixblocks` (
  `id` int NOT NULL,
  `primaryOwnerId` int NOT NULL,
  `fieldId` int NOT NULL,
  `typeId` int NOT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tmmjojtfknblyyddshqvmjagtazbmizsxjwh` (`primaryOwnerId`),
  KEY `idx_yvhcmbzguigsahzlqxexyoaioyhmrpmbglbs` (`fieldId`),
  KEY `idx_iszapscodnfwzvbzxgkwrxapavhkjfcazseg` (`typeId`),
  CONSTRAINT `fk_cuvsjffeibfdstceqnlkuuevdpxlvpcvzznj` FOREIGN KEY (`typeId`) REFERENCES `matrixblocktypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_fmstyjczfzuskepwxxolujmvoyoyyhsszktj` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_npsjeyizqmkwojwesxuqijycrdulmhniavga` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xxowrzhwqgmfcvdqwryoaxbqhrntvlgljnqg` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matrixblocks`
--

LOCK TABLES `matrixblocks` WRITE;
/*!40000 ALTER TABLE `matrixblocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `matrixblocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matrixblocks_owners`
--

DROP TABLE IF EXISTS `matrixblocks_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matrixblocks_owners` (
  `blockId` int NOT NULL,
  `ownerId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`blockId`,`ownerId`),
  KEY `fk_pbiefeypokggxexpaxaxehmpgaezrcduabyi` (`ownerId`),
  CONSTRAINT `fk_dfeonghrtlxkckoeurtqotxerdakcgkzkpwu` FOREIGN KEY (`blockId`) REFERENCES `matrixblocks` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pbiefeypokggxexpaxaxehmpgaezrcduabyi` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matrixblocks_owners`
--

LOCK TABLES `matrixblocks_owners` WRITE;
/*!40000 ALTER TABLE `matrixblocks_owners` DISABLE KEYS */;
/*!40000 ALTER TABLE `matrixblocks_owners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matrixblocktypes`
--

DROP TABLE IF EXISTS `matrixblocktypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matrixblocktypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_oqbjzaoygdqouwzrlxtacdmhizqpxqqzxdts` (`name`,`fieldId`),
  KEY `idx_mgxjdzvanpjlqqzalbecxgywhmvrbivsrtdb` (`handle`,`fieldId`),
  KEY `idx_qxqwcgtkovuerrppldkwpwwfsiukqirkyqkt` (`fieldId`),
  KEY `idx_goajrxzzkeijoyhvkgboimpmpckoruxgihcz` (`fieldLayoutId`),
  CONSTRAINT `fk_hdnrwkzkotmhjxhxynqkgcxtsfrkfgmcqxqr` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_mkcfimbvqnxipqryyuunzvqkmxlwmpswpksb` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matrixblocktypes`
--

LOCK TABLES `matrixblocktypes` WRITE;
/*!40000 ALTER TABLE `matrixblocktypes` DISABLE KEYS */;
/*!40000 ALTER TABLE `matrixblocktypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ycbwkjcccfqjyykriaptrlswixpnosdazsgs` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'craft','Install','2023-12-26 19:45:34','2023-12-26 19:45:34','2023-12-26 19:45:34','438993bf-340d-4978-a180-b3c3722894e3'),(2,'craft','m210121_145800_asset_indexing_changes','2023-12-26 19:45:34','2023-12-26 19:45:34','2023-12-26 19:45:34','ce6ef4b5-7fcf-4fd6-a9e8-3aae139a5ab8'),(3,'craft','m210624_222934_drop_deprecated_tables','2023-12-26 19:45:34','2023-12-26 19:45:34','2023-12-26 19:45:34','f435a775-bfef-4e95-8744-d5046d0e65d5'),(4,'craft','m210724_180756_rename_source_cols','2023-12-26 19:45:34','2023-12-26 19:45:34','2023-12-26 19:45:34','bb079c1a-3bdc-4997-9021-d2224b182578'),(5,'craft','m210809_124211_remove_superfluous_uids','2023-12-26 19:45:34','2023-12-26 19:45:34','2023-12-26 19:45:34','d91093b3-f3db-417f-8de0-f862d0e90959'),(6,'craft','m210817_014201_universal_users','2023-12-26 19:45:34','2023-12-26 19:45:34','2023-12-26 19:45:34','ffa6bb0c-67d7-4f68-a438-dc1f13fa96e0'),(7,'craft','m210904_132612_store_element_source_settings_in_project_config','2023-12-26 19:45:34','2023-12-26 19:45:34','2023-12-26 19:45:34','bbb2884c-ed6d-452d-82b6-cb0002b991a4'),(8,'craft','m211115_135500_image_transformers','2023-12-26 19:45:34','2023-12-26 19:45:34','2023-12-26 19:45:34','ed92c446-b785-4846-adf0-a3acc8f5199e'),(9,'craft','m211201_131000_filesystems','2023-12-26 19:45:34','2023-12-26 19:45:34','2023-12-26 19:45:34','8e240dd6-e9cd-441c-894b-4eb3066d666c'),(10,'craft','m220103_043103_tab_conditions','2023-12-26 19:45:34','2023-12-26 19:45:34','2023-12-26 19:45:34','04639a68-0733-4fef-8cfa-b0df8bc0f723'),(11,'craft','m220104_003433_asset_alt_text','2023-12-26 19:45:34','2023-12-26 19:45:34','2023-12-26 19:45:34','07f9435e-5e1d-4d4c-a5aa-71e2ab958f27'),(12,'craft','m220123_213619_update_permissions','2023-12-26 19:45:34','2023-12-26 19:45:34','2023-12-26 19:45:34','8c37b848-3c66-42e6-a0e5-4d0b85f34853'),(13,'craft','m220126_003432_addresses','2023-12-26 19:45:34','2023-12-26 19:45:34','2023-12-26 19:45:34','9be71de9-fdec-41fe-9e40-be306aa1cb90'),(14,'craft','m220209_095604_add_indexes','2023-12-26 19:45:34','2023-12-26 19:45:34','2023-12-26 19:45:34','8608725f-8439-4fef-a27c-4be2436dcdb8'),(15,'craft','m220213_015220_matrixblocks_owners_table','2023-12-26 19:45:34','2023-12-26 19:45:34','2023-12-26 19:45:34','0cc72895-999e-41c9-8215-3b3e7ec7d79d'),(16,'craft','m220214_000000_truncate_sessions','2023-12-26 19:45:34','2023-12-26 19:45:34','2023-12-26 19:45:34','1f830cb2-ec07-4e0f-a277-3868ae6a26c8'),(17,'craft','m220222_122159_full_names','2023-12-26 19:45:34','2023-12-26 19:45:34','2023-12-26 19:45:34','4b0d1431-e4de-4d80-8fbe-e3f4e0610a75'),(18,'craft','m220223_180559_nullable_address_owner','2023-12-26 19:45:35','2023-12-26 19:45:35','2023-12-26 19:45:35','a75060cd-c662-4a6b-beaf-552faa0a390c'),(19,'craft','m220225_165000_transform_filesystems','2023-12-26 19:45:35','2023-12-26 19:45:35','2023-12-26 19:45:35','99aa12f3-d2ef-4c77-b2e7-89041c1e5538'),(20,'craft','m220309_152006_rename_field_layout_elements','2023-12-26 19:45:35','2023-12-26 19:45:35','2023-12-26 19:45:35','21ead6cf-8d21-4ffe-8490-13a9d3f565ba'),(21,'craft','m220314_211928_field_layout_element_uids','2023-12-26 19:45:35','2023-12-26 19:45:35','2023-12-26 19:45:35','af2ec5ef-1c66-444e-a417-d4f719fc9ff8'),(22,'craft','m220316_123800_transform_fs_subpath','2023-12-26 19:45:35','2023-12-26 19:45:35','2023-12-26 19:45:35','b636f7c6-46b2-48e6-8b91-05a8053e4e18'),(23,'craft','m220317_174250_release_all_jobs','2023-12-26 19:45:35','2023-12-26 19:45:35','2023-12-26 19:45:35','a3f71183-3b7a-45f6-9bcc-de8a36f34a9a'),(24,'craft','m220330_150000_add_site_gql_schema_components','2023-12-26 19:45:35','2023-12-26 19:45:35','2023-12-26 19:45:35','d8d4b0b6-fc30-4bcb-8eb0-db86a3400e72'),(25,'craft','m220413_024536_site_enabled_string','2023-12-26 19:45:35','2023-12-26 19:45:35','2023-12-26 19:45:35','cfa8e21b-ee47-4ec7-ba9b-ab2a80b5618f'),(26,'craft','m221027_160703_add_image_transform_fill','2023-12-26 19:45:35','2023-12-26 19:45:35','2023-12-26 19:45:35','26cbd5ea-bcb4-4593-860c-24dc103c246d'),(27,'craft','m221028_130548_add_canonical_id_index','2023-12-26 19:45:35','2023-12-26 19:45:35','2023-12-26 19:45:35','673e0d3f-f459-49e7-b490-d7e77d348015'),(28,'craft','m221118_003031_drop_element_fks','2023-12-26 19:45:35','2023-12-26 19:45:35','2023-12-26 19:45:35','fd6d8ff8-ea23-41d7-ae26-7769c532964e'),(29,'craft','m230131_120713_asset_indexing_session_new_options','2023-12-26 19:45:35','2023-12-26 19:45:35','2023-12-26 19:45:35','48f61ecd-42dc-4a04-8d12-e322e42ae25b'),(30,'craft','m230226_013114_drop_plugin_license_columns','2023-12-26 19:45:35','2023-12-26 19:45:35','2023-12-26 19:45:35','b41f6873-812a-4a8a-b24d-764251087a47'),(31,'craft','m230531_123004_add_entry_type_show_status_field','2023-12-26 19:45:35','2023-12-26 19:45:35','2023-12-26 19:45:35','92837b74-648a-4287-8679-f33d470da3de'),(32,'craft','m230607_102049_add_entrytype_slug_translation_columns','2023-12-26 19:45:35','2023-12-26 19:45:35','2023-12-26 19:45:35','665c4722-901e-4c5e-86d6-73714cb632ce'),(33,'craft','m230710_162700_element_activity','2023-12-26 19:45:35','2023-12-26 19:45:35','2023-12-26 19:45:35','c212fb29-57f2-43db-9632-3988d41378b6'),(34,'craft','m230820_162023_fix_cache_id_type','2023-12-26 19:45:35','2023-12-26 19:45:35','2023-12-26 19:45:35','359a1373-4c7e-4697-8365-9e135427c315'),(35,'craft','m230826_094050_fix_session_id_type','2023-12-26 19:45:35','2023-12-26 19:45:35','2023-12-26 19:45:35','e339cddd-fb41-4924-b0db-d648fcf61cad'),(36,'plugin:abm-tinymce','Install','2024-01-05 15:07:47','2024-01-05 15:07:47','2024-01-05 15:07:47','6b351189-17a3-414e-af82-931366c046bf'),(37,'plugin:redactor','m180430_204710_remove_old_plugins','2024-01-05 15:33:03','2024-01-05 15:33:03','2024-01-05 15:33:03','d024e662-f8f0-42e8-bad1-81c67e31a7ff'),(38,'plugin:redactor','Install','2024-01-05 15:33:03','2024-01-05 15:33:03','2024-01-05 15:33:03','31aab495-8212-4c39-bbaf-9f7448f5cfc0'),(39,'plugin:redactor','m190225_003922_split_cleanup_html_settings','2024-01-05 15:33:03','2024-01-05 15:33:03','2024-01-05 15:33:03','c5fc53ea-ce79-47cc-9fa6-c552f450a877'),(40,'plugin:cookie-consent-banner','m190902_000000_migrate_settings_to_uid','2024-01-06 17:24:43','2024-01-06 17:24:43','2024-01-06 17:24:43','d19f2f99-3640-40b4-bd63-44a98f4bf397'),(41,'plugin:geoaddress','m220516_144416_update_field_handle','2024-01-06 18:46:16','2024-01-06 18:46:16','2024-01-06 18:46:16','6e04954a-beb7-4d7e-ac98-239b66678d91');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plugins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lzrqxocfdlrotxebesjpbcunazpdcfzhwqtj` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
INSERT INTO `plugins` VALUES (1,'abm-tinymce','1.0.5','1.0.0','2024-01-05 15:07:47','2024-01-05 15:07:47','2024-01-05 15:07:47','5baf9a84-c9e1-4861-8a06-032f90adb7ee'),(2,'redactor','3.0.4','2.3.0','2024-01-05 15:33:03','2024-01-05 15:33:03','2024-01-05 15:33:03','32e88246-40ba-4cf2-95f1-3f3b87cfc05a'),(3,'cookie-consent-banner','2.0.0','1.0.1','2024-01-06 17:24:43','2024-01-06 17:24:43','2024-01-06 17:24:43','d83e10b8-25b2-46d3-9d0a-d12d164901d8'),(4,'cookies','4.0.0','1.0.0','2024-01-06 18:42:35','2024-01-06 18:42:35','2024-01-06 18:42:35','26b5c27a-d685-4dae-8fbb-116f85c93fbd'),(5,'geoaddress','2.0.0','1.0.1','2024-01-06 18:46:16','2024-01-06 18:46:16','2024-01-06 18:46:16','87b01e1c-285a-432d-8268-622f9cee2bda'),(6,'element-api','3.0.1.1','1.0.0','2024-01-10 23:31:48','2024-01-10 23:31:48','2024-01-10 23:31:48','bdd0c2c7-b217-4b39-99bf-3666f25e187a');
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
INSERT INTO `projectconfig` VALUES ('dateModified','1704992297'),('email.fromEmail','\"r0906880@student.thomasmore.be\"'),('email.fromName','\"Drank Webshop\"'),('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.fieldLayouts.ef29586e-d08d-400d-8073-2c503f71ffac.tabs.0.elementCondition','null'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.fieldLayouts.ef29586e-d08d-400d-8073-2c503f71ffac.tabs.0.elements.0.autocapitalize','true'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.fieldLayouts.ef29586e-d08d-400d-8073-2c503f71ffac.tabs.0.elements.0.autocomplete','false'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.fieldLayouts.ef29586e-d08d-400d-8073-2c503f71ffac.tabs.0.elements.0.autocorrect','true'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.fieldLayouts.ef29586e-d08d-400d-8073-2c503f71ffac.tabs.0.elements.0.class','null'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.fieldLayouts.ef29586e-d08d-400d-8073-2c503f71ffac.tabs.0.elements.0.disabled','false'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.fieldLayouts.ef29586e-d08d-400d-8073-2c503f71ffac.tabs.0.elements.0.elementCondition','null'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.fieldLayouts.ef29586e-d08d-400d-8073-2c503f71ffac.tabs.0.elements.0.id','null'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.fieldLayouts.ef29586e-d08d-400d-8073-2c503f71ffac.tabs.0.elements.0.inputType','null'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.fieldLayouts.ef29586e-d08d-400d-8073-2c503f71ffac.tabs.0.elements.0.instructions','null'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.fieldLayouts.ef29586e-d08d-400d-8073-2c503f71ffac.tabs.0.elements.0.label','null'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.fieldLayouts.ef29586e-d08d-400d-8073-2c503f71ffac.tabs.0.elements.0.max','null'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.fieldLayouts.ef29586e-d08d-400d-8073-2c503f71ffac.tabs.0.elements.0.min','null'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.fieldLayouts.ef29586e-d08d-400d-8073-2c503f71ffac.tabs.0.elements.0.name','null'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.fieldLayouts.ef29586e-d08d-400d-8073-2c503f71ffac.tabs.0.elements.0.orientation','null'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.fieldLayouts.ef29586e-d08d-400d-8073-2c503f71ffac.tabs.0.elements.0.placeholder','null'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.fieldLayouts.ef29586e-d08d-400d-8073-2c503f71ffac.tabs.0.elements.0.readonly','false'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.fieldLayouts.ef29586e-d08d-400d-8073-2c503f71ffac.tabs.0.elements.0.requirable','false'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.fieldLayouts.ef29586e-d08d-400d-8073-2c503f71ffac.tabs.0.elements.0.size','null'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.fieldLayouts.ef29586e-d08d-400d-8073-2c503f71ffac.tabs.0.elements.0.step','null'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.fieldLayouts.ef29586e-d08d-400d-8073-2c503f71ffac.tabs.0.elements.0.tip','null'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.fieldLayouts.ef29586e-d08d-400d-8073-2c503f71ffac.tabs.0.elements.0.title','null'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.fieldLayouts.ef29586e-d08d-400d-8073-2c503f71ffac.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.fieldLayouts.ef29586e-d08d-400d-8073-2c503f71ffac.tabs.0.elements.0.uid','\"c973c94b-5f2e-463e-a721-52bff1de6523\"'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.fieldLayouts.ef29586e-d08d-400d-8073-2c503f71ffac.tabs.0.elements.0.userCondition','null'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.fieldLayouts.ef29586e-d08d-400d-8073-2c503f71ffac.tabs.0.elements.0.warning','null'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.fieldLayouts.ef29586e-d08d-400d-8073-2c503f71ffac.tabs.0.elements.0.width','100'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.fieldLayouts.ef29586e-d08d-400d-8073-2c503f71ffac.tabs.0.name','\"Content\"'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.fieldLayouts.ef29586e-d08d-400d-8073-2c503f71ffac.tabs.0.uid','\"58a50282-1139-4afc-83a8-1c35084b3363\"'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.fieldLayouts.ef29586e-d08d-400d-8073-2c503f71ffac.tabs.0.userCondition','null'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.handle','\"default\"'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.hasTitleField','true'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.name','\"Default\"'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.section','\"18e745c4-9c85-4f4c-9219-09e2ba15599c\"'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.showStatusField','true'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.slugTranslationKeyFormat','null'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.slugTranslationMethod','\"site\"'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.sortOrder','1'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.titleFormat','null'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.titleTranslationKeyFormat','null'),('entryTypes.312c1641-3732-473d-82d8-212a18bc8443.titleTranslationMethod','\"site\"'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elementCondition','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.0.elementCondition','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.0.fieldUid','\"224b5a40-80ce-447d-8be5-4e349e553bcd\"'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.0.instructions','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.0.label','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.0.required','false'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.0.tip','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.0.uid','\"2e555d3a-b77b-4756-8178-b9e8a83dda5b\"'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.0.userCondition','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.0.warning','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.0.width','100'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.1.autocapitalize','true'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.1.autocomplete','false'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.1.autocorrect','true'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.1.class','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.1.disabled','false'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.1.elementCondition','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.1.id','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.1.inputType','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.1.instructions','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.1.label','\"title\"'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.1.max','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.1.min','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.1.name','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.1.orientation','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.1.placeholder','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.1.readonly','false'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.1.requirable','false'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.1.size','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.1.step','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.1.tip','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.1.title','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.1.uid','\"3428543b-7253-40e7-b639-e0f415bc4ca7\"'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.1.userCondition','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.1.warning','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.1.width','100'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.2.elementCondition','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.2.fieldUid','\"e1d95b86-a3f8-45e9-b985-8605dde5b9d4\"'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.2.instructions','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.2.label','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.2.required','false'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.2.tip','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.2.uid','\"6c5bc96b-3fcb-47e9-a0c1-d6c3916e0e76\"'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.2.userCondition','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.2.warning','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.2.width','100'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.3.elementCondition','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.3.fieldUid','\"9c58ac58-2bbb-49cf-8e49-c1f4f9364f6a\"'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.3.instructions','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.3.label','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.3.required','false'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.3.tip','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.3.uid','\"4a03d6f6-2595-4bbb-92b8-51417875f44b\"'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.3.userCondition','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.3.warning','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.3.width','100'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.4.elementCondition','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.4.fieldUid','\"b957af1b-f8d8-43a7-9958-98856e4707c6\"'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.4.instructions','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.4.label','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.4.required','false'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.4.tip','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.4.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.4.uid','\"df8bc38b-de99-413e-bbd0-186611536fdd\"'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.4.userCondition','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.4.warning','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.elements.4.width','100'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.name','\"Content\"'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.uid','\"c6aee18b-8016-4b8c-967a-5bdcd0bd8acf\"'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.fieldLayouts.959111c6-5810-40f7-af4c-a8393e241bff.tabs.0.userCondition','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.handle','\"home\"'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.hasTitleField','false'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.name','\"home\"'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.section','\"b4927f39-21eb-487f-9819-47b121ed4ca8\"'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.showStatusField','true'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.slugTranslationKeyFormat','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.slugTranslationMethod','\"site\"'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.sortOrder','1'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.titleFormat','\"{section.name|raw}\"'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.titleTranslationKeyFormat','null'),('entryTypes.597ef37d-ecf5-4ed9-92ef-7b0f956184dd.titleTranslationMethod','\"site\"'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elementCondition','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.0.autocapitalize','true'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.0.autocomplete','false'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.0.autocorrect','true'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.0.class','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.0.disabled','false'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.0.elementCondition','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.0.id','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.0.inputType','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.0.instructions','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.0.label','\"Drink Name\"'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.0.max','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.0.min','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.0.name','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.0.orientation','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.0.placeholder','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.0.readonly','false'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.0.requirable','false'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.0.size','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.0.step','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.0.tip','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.0.title','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.0.uid','\"ccc38710-b902-4d94-aa34-5234ded60940\"'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.0.userCondition','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.0.warning','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.0.width','100'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.1.elementCondition','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.1.fieldUid','\"9c722366-6570-4938-b9ff-9f3d55620afe\"'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.1.instructions','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.1.label','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.1.required','false'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.1.tip','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.1.uid','\"5e87acfe-a138-4181-ada3-52eaad1db004\"'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.1.userCondition','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.1.warning','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.1.width','100'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.2.elementCondition','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.2.fieldUid','\"cbc6efb9-07dd-46a7-8965-d8c5bf50cd40\"'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.2.instructions','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.2.label','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.2.required','false'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.2.tip','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.2.uid','\"ff6668ea-4c84-4f14-a628-ee8bad489b0c\"'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.2.userCondition','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.2.warning','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.2.width','100'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.3.elementCondition','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.3.fieldUid','\"f0f0a2ff-68fd-4217-93b1-7318025da83b\"'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.3.instructions','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.3.label','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.3.required','false'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.3.tip','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.3.uid','\"0b48bee4-9254-430c-83c4-0bf7ba5777a0\"'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.3.userCondition','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.3.warning','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.3.width','100'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.4.elementCondition','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.4.fieldUid','\"2fdf6f3c-8796-4125-a22a-392fe3486fef\"'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.4.instructions','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.4.label','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.4.required','false'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.4.tip','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.4.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.4.uid','\"1c0a3a10-b58d-41f3-ba49-0d5fdb0f412f\"'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.4.userCondition','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.4.warning','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.4.width','100'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.5.elementCondition','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.5.fieldUid','\"51b05e04-81a8-4074-bb1c-64f3090a35c6\"'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.5.instructions','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.5.label','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.5.required','false'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.5.tip','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.5.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.5.uid','\"37fcb3b0-1f1d-4d90-92ea-c5f897723120\"'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.5.userCondition','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.5.warning','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.5.width','100'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.6.elementCondition','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.6.fieldUid','\"a5b7d0fb-075f-4551-ab53-c7a37d7ea905\"'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.6.instructions','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.6.label','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.6.required','false'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.6.tip','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.6.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.6.uid','\"a900187f-5a13-4a96-9cdb-6ff9f87c5237\"'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.6.userCondition','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.6.warning','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.elements.6.width','100'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.name','\"Content\"'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.uid','\"a8a8b882-b441-4e28-9c9d-953dda574efe\"'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.fieldLayouts.a24f6f96-2c95-4738-ba3d-73f41b845102.tabs.0.userCondition','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.handle','\"default\"'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.hasTitleField','true'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.name','\"Default\"'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.section','\"4e90476a-1613-447e-9942-30d691eec5b1\"'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.showStatusField','true'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.slugTranslationKeyFormat','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.slugTranslationMethod','\"site\"'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.sortOrder','1'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.titleFormat','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.titleTranslationKeyFormat','null'),('entryTypes.6b5f5717-efc9-40c6-9d68-97b86792a46c.titleTranslationMethod','\"site\"'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elementCondition','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.0.autocapitalize','true'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.0.autocomplete','false'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.0.autocorrect','true'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.0.class','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.0.disabled','false'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.0.elementCondition','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.0.id','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.0.inputType','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.0.instructions','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.0.label','\"Header1\"'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.0.max','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.0.min','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.0.name','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.0.orientation','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.0.placeholder','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.0.readonly','false'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.0.requirable','false'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.0.size','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.0.step','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.0.tip','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.0.title','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.0.uid','\"cc4d3ae6-bce3-4a7b-880d-dd2f3f55df71\"'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.0.userCondition','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.0.warning','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.0.width','100'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.1.elementCondition','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.1.fieldUid','\"224b5a40-80ce-447d-8be5-4e349e553bcd\"'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.1.instructions','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.1.label','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.1.required','false'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.1.tip','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.1.uid','\"1d74dfa1-a211-431a-9842-b146e7b8c026\"'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.1.userCondition','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.1.warning','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.1.width','100'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.2.elementCondition','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.2.fieldUid','\"e1d95b86-a3f8-45e9-b985-8605dde5b9d4\"'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.2.instructions','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.2.label','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.2.required','false'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.2.tip','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.2.uid','\"84c99f48-1656-4121-a6d9-31d4d9523f7d\"'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.2.userCondition','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.2.warning','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.2.width','100'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.3.elementCondition','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.3.fieldUid','\"9c58ac58-2bbb-49cf-8e49-c1f4f9364f6a\"'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.3.instructions','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.3.label','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.3.required','false'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.3.tip','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.3.uid','\"c159eb55-2337-4a60-b0b3-3f129ef5643e\"'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.3.userCondition','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.3.warning','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.3.width','100'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.4.elementCondition','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.4.fieldUid','\"b957af1b-f8d8-43a7-9958-98856e4707c6\"'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.4.instructions','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.4.label','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.4.required','false'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.4.tip','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.4.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.4.uid','\"a30c3e98-99f7-401f-8072-93d98d975d4c\"'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.4.userCondition','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.4.warning','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.elements.4.width','100'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.name','\"Content\"'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.uid','\"cab7f228-9d77-4c95-9ab3-42ff36b85f3a\"'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.fieldLayouts.606721de-4e04-4be0-8342-8dd40d60e385.tabs.0.userCondition','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.handle','\"aboutUs\"'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.hasTitleField','false'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.name','\"About us\"'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.section','\"c0d44cc8-1c83-47d4-9b83-9ba94e0224dc\"'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.showStatusField','true'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.slugTranslationKeyFormat','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.slugTranslationMethod','\"site\"'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.sortOrder','1'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.titleFormat','\"{section.name|raw}\"'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.titleTranslationKeyFormat','null'),('entryTypes.e671db06-f0c3-45b9-a032-192145ab9bc5.titleTranslationMethod','\"site\"'),('fieldGroups.3d9e1db9-d8e4-4a7c-9a47-ca0b0dac0261.name','\"Common\"'),('fieldGroups.892e899e-bc4d-426a-abb8-850855a6fc7c.name','\"Drinks\"'),('fieldGroups.8edf0eb0-db84-407e-8941-f20dada533ee.name','\"store categories\"'),('fieldGroups.a16af4de-9170-42ba-9340-97ad4abfb3b2.name','\"home\"'),('fieldGroups.e5ae6272-fc40-4a83-ae00-6f7847500ae8.name','\"About us\"'),('fields.224b5a40-80ce-447d-8be5-4e349e553bcd.columnSuffix','\"lwhrkzwq\"'),('fields.224b5a40-80ce-447d-8be5-4e349e553bcd.contentColumnType','\"text\"'),('fields.224b5a40-80ce-447d-8be5-4e349e553bcd.fieldGroup','\"a16af4de-9170-42ba-9340-97ad4abfb3b2\"'),('fields.224b5a40-80ce-447d-8be5-4e349e553bcd.handle','\"header1\"'),('fields.224b5a40-80ce-447d-8be5-4e349e553bcd.instructions','null'),('fields.224b5a40-80ce-447d-8be5-4e349e553bcd.name','\"header1\"'),('fields.224b5a40-80ce-447d-8be5-4e349e553bcd.searchable','false'),('fields.224b5a40-80ce-447d-8be5-4e349e553bcd.settings.availableTransforms','\"\"'),('fields.224b5a40-80ce-447d-8be5-4e349e553bcd.settings.availableVolumes','\"\"'),('fields.224b5a40-80ce-447d-8be5-4e349e553bcd.settings.columnType','\"text\"'),('fields.224b5a40-80ce-447d-8be5-4e349e553bcd.settings.purifierConfig','\"Default.json\"'),('fields.224b5a40-80ce-447d-8be5-4e349e553bcd.settings.purifyHtml','true'),('fields.224b5a40-80ce-447d-8be5-4e349e553bcd.settings.removeEmptyTags','false'),('fields.224b5a40-80ce-447d-8be5-4e349e553bcd.settings.removeInlineStyles','false'),('fields.224b5a40-80ce-447d-8be5-4e349e553bcd.settings.removeNbsp','false'),('fields.224b5a40-80ce-447d-8be5-4e349e553bcd.settings.showHtmlButtonForNonAdmins','false'),('fields.224b5a40-80ce-447d-8be5-4e349e553bcd.settings.showUnpermittedFiles','false'),('fields.224b5a40-80ce-447d-8be5-4e349e553bcd.settings.showUnpermittedVolumes','false'),('fields.224b5a40-80ce-447d-8be5-4e349e553bcd.settings.tinymceConfig','\"Default.json\"'),('fields.224b5a40-80ce-447d-8be5-4e349e553bcd.translationKeyFormat','null'),('fields.224b5a40-80ce-447d-8be5-4e349e553bcd.translationMethod','\"none\"'),('fields.224b5a40-80ce-447d-8be5-4e349e553bcd.type','\"abmat\\\\tinymce\\\\Field\"'),('fields.2fdf6f3c-8796-4125-a22a-392fe3486fef.columnSuffix','\"fzsqwxge\"'),('fields.2fdf6f3c-8796-4125-a22a-392fe3486fef.contentColumnType','\"text\"'),('fields.2fdf6f3c-8796-4125-a22a-392fe3486fef.fieldGroup','\"892e899e-bc4d-426a-abb8-850855a6fc7c\"'),('fields.2fdf6f3c-8796-4125-a22a-392fe3486fef.handle','\"introduction\"'),('fields.2fdf6f3c-8796-4125-a22a-392fe3486fef.instructions','\"short introduction next to drink page\"'),('fields.2fdf6f3c-8796-4125-a22a-392fe3486fef.name','\"introduction\"'),('fields.2fdf6f3c-8796-4125-a22a-392fe3486fef.searchable','false'),('fields.2fdf6f3c-8796-4125-a22a-392fe3486fef.settings.availableTransforms','\"\"'),('fields.2fdf6f3c-8796-4125-a22a-392fe3486fef.settings.availableVolumes','\"\"'),('fields.2fdf6f3c-8796-4125-a22a-392fe3486fef.settings.columnType','\"text\"'),('fields.2fdf6f3c-8796-4125-a22a-392fe3486fef.settings.purifierConfig','\"Default.json\"'),('fields.2fdf6f3c-8796-4125-a22a-392fe3486fef.settings.purifyHtml','true'),('fields.2fdf6f3c-8796-4125-a22a-392fe3486fef.settings.removeEmptyTags','false'),('fields.2fdf6f3c-8796-4125-a22a-392fe3486fef.settings.removeInlineStyles','false'),('fields.2fdf6f3c-8796-4125-a22a-392fe3486fef.settings.removeNbsp','false'),('fields.2fdf6f3c-8796-4125-a22a-392fe3486fef.settings.showHtmlButtonForNonAdmins','false'),('fields.2fdf6f3c-8796-4125-a22a-392fe3486fef.settings.showUnpermittedFiles','false'),('fields.2fdf6f3c-8796-4125-a22a-392fe3486fef.settings.showUnpermittedVolumes','false'),('fields.2fdf6f3c-8796-4125-a22a-392fe3486fef.settings.tinymceConfig','\"Default.json\"'),('fields.2fdf6f3c-8796-4125-a22a-392fe3486fef.translationKeyFormat','null'),('fields.2fdf6f3c-8796-4125-a22a-392fe3486fef.translationMethod','\"none\"'),('fields.2fdf6f3c-8796-4125-a22a-392fe3486fef.type','\"abmat\\\\tinymce\\\\Field\"'),('fields.3d1094d4-9576-466e-8f54-d264d7286642.columnSuffix','\"tqqdapum\"'),('fields.3d1094d4-9576-466e-8f54-d264d7286642.contentColumnType','\"text\"'),('fields.3d1094d4-9576-466e-8f54-d264d7286642.fieldGroup','\"3d9e1db9-d8e4-4a7c-9a47-ca0b0dac0261\"'),('fields.3d1094d4-9576-466e-8f54-d264d7286642.handle','\"infoAbout\"'),('fields.3d1094d4-9576-466e-8f54-d264d7286642.instructions','null'),('fields.3d1094d4-9576-466e-8f54-d264d7286642.name','\"Info about\"'),('fields.3d1094d4-9576-466e-8f54-d264d7286642.searchable','false'),('fields.3d1094d4-9576-466e-8f54-d264d7286642.settings.availableTransforms','\"\"'),('fields.3d1094d4-9576-466e-8f54-d264d7286642.settings.availableVolumes','\"\"'),('fields.3d1094d4-9576-466e-8f54-d264d7286642.settings.columnType','\"text\"'),('fields.3d1094d4-9576-466e-8f54-d264d7286642.settings.purifierConfig','\"Default.json\"'),('fields.3d1094d4-9576-466e-8f54-d264d7286642.settings.purifyHtml','true'),('fields.3d1094d4-9576-466e-8f54-d264d7286642.settings.removeEmptyTags','false'),('fields.3d1094d4-9576-466e-8f54-d264d7286642.settings.removeInlineStyles','false'),('fields.3d1094d4-9576-466e-8f54-d264d7286642.settings.removeNbsp','false'),('fields.3d1094d4-9576-466e-8f54-d264d7286642.settings.showHtmlButtonForNonAdmins','false'),('fields.3d1094d4-9576-466e-8f54-d264d7286642.settings.showUnpermittedFiles','false'),('fields.3d1094d4-9576-466e-8f54-d264d7286642.settings.showUnpermittedVolumes','false'),('fields.3d1094d4-9576-466e-8f54-d264d7286642.settings.tinymceConfig','\"Default.json\"'),('fields.3d1094d4-9576-466e-8f54-d264d7286642.translationKeyFormat','null'),('fields.3d1094d4-9576-466e-8f54-d264d7286642.translationMethod','\"none\"'),('fields.3d1094d4-9576-466e-8f54-d264d7286642.type','\"abmat\\\\tinymce\\\\Field\"'),('fields.51b05e04-81a8-4074-bb1c-64f3090a35c6.columnSuffix','\"rksiqext\"'),('fields.51b05e04-81a8-4074-bb1c-64f3090a35c6.contentColumnType','\"integer(10)\"'),('fields.51b05e04-81a8-4074-bb1c-64f3090a35c6.fieldGroup','\"892e899e-bc4d-426a-abb8-850855a6fc7c\"'),('fields.51b05e04-81a8-4074-bb1c-64f3090a35c6.handle','\"alcoholPercentage\"'),('fields.51b05e04-81a8-4074-bb1c-64f3090a35c6.instructions','\"it gives the percentage of alcohol in the drinks\"'),('fields.51b05e04-81a8-4074-bb1c-64f3090a35c6.name','\"Alcohol percentage\"'),('fields.51b05e04-81a8-4074-bb1c-64f3090a35c6.searchable','false'),('fields.51b05e04-81a8-4074-bb1c-64f3090a35c6.settings.decimals','0'),('fields.51b05e04-81a8-4074-bb1c-64f3090a35c6.settings.defaultValue','null'),('fields.51b05e04-81a8-4074-bb1c-64f3090a35c6.settings.max','null'),('fields.51b05e04-81a8-4074-bb1c-64f3090a35c6.settings.min','0'),('fields.51b05e04-81a8-4074-bb1c-64f3090a35c6.settings.prefix','null'),('fields.51b05e04-81a8-4074-bb1c-64f3090a35c6.settings.previewCurrency','null'),('fields.51b05e04-81a8-4074-bb1c-64f3090a35c6.settings.previewFormat','\"decimal\"'),('fields.51b05e04-81a8-4074-bb1c-64f3090a35c6.settings.size','null'),('fields.51b05e04-81a8-4074-bb1c-64f3090a35c6.settings.suffix','\"%\"'),('fields.51b05e04-81a8-4074-bb1c-64f3090a35c6.translationKeyFormat','null'),('fields.51b05e04-81a8-4074-bb1c-64f3090a35c6.translationMethod','\"none\"'),('fields.51b05e04-81a8-4074-bb1c-64f3090a35c6.type','\"craft\\\\fields\\\\Number\"'),('fields.9c58ac58-2bbb-49cf-8e49-c1f4f9364f6a.columnSuffix','\"rctpvesc\"'),('fields.9c58ac58-2bbb-49cf-8e49-c1f4f9364f6a.contentColumnType','\"text\"'),('fields.9c58ac58-2bbb-49cf-8e49-c1f4f9364f6a.fieldGroup','\"a16af4de-9170-42ba-9340-97ad4abfb3b2\"'),('fields.9c58ac58-2bbb-49cf-8e49-c1f4f9364f6a.handle','\"enkelAlcohol\"'),('fields.9c58ac58-2bbb-49cf-8e49-c1f4f9364f6a.instructions','\"Dit is het gedeelte enkel alcohol\"'),('fields.9c58ac58-2bbb-49cf-8e49-c1f4f9364f6a.name','\"enkel alcohol\"'),('fields.9c58ac58-2bbb-49cf-8e49-c1f4f9364f6a.searchable','false'),('fields.9c58ac58-2bbb-49cf-8e49-c1f4f9364f6a.settings.availableTransforms','\"\"'),('fields.9c58ac58-2bbb-49cf-8e49-c1f4f9364f6a.settings.availableVolumes','\"\"'),('fields.9c58ac58-2bbb-49cf-8e49-c1f4f9364f6a.settings.columnType','\"text\"'),('fields.9c58ac58-2bbb-49cf-8e49-c1f4f9364f6a.settings.purifierConfig','\"Default.json\"'),('fields.9c58ac58-2bbb-49cf-8e49-c1f4f9364f6a.settings.purifyHtml','true'),('fields.9c58ac58-2bbb-49cf-8e49-c1f4f9364f6a.settings.removeEmptyTags','false'),('fields.9c58ac58-2bbb-49cf-8e49-c1f4f9364f6a.settings.removeInlineStyles','false'),('fields.9c58ac58-2bbb-49cf-8e49-c1f4f9364f6a.settings.removeNbsp','false'),('fields.9c58ac58-2bbb-49cf-8e49-c1f4f9364f6a.settings.showHtmlButtonForNonAdmins','false'),('fields.9c58ac58-2bbb-49cf-8e49-c1f4f9364f6a.settings.showUnpermittedFiles','false'),('fields.9c58ac58-2bbb-49cf-8e49-c1f4f9364f6a.settings.showUnpermittedVolumes','false'),('fields.9c58ac58-2bbb-49cf-8e49-c1f4f9364f6a.settings.tinymceConfig','\"Default.json\"'),('fields.9c58ac58-2bbb-49cf-8e49-c1f4f9364f6a.translationKeyFormat','null'),('fields.9c58ac58-2bbb-49cf-8e49-c1f4f9364f6a.translationMethod','\"none\"'),('fields.9c58ac58-2bbb-49cf-8e49-c1f4f9364f6a.type','\"abmat\\\\tinymce\\\\Field\"'),('fields.9c722366-6570-4938-b9ff-9f3d55620afe.columnSuffix','null'),('fields.9c722366-6570-4938-b9ff-9f3d55620afe.contentColumnType','\"string\"'),('fields.9c722366-6570-4938-b9ff-9f3d55620afe.fieldGroup','\"8edf0eb0-db84-407e-8941-f20dada533ee\"'),('fields.9c722366-6570-4938-b9ff-9f3d55620afe.handle','\"storeCategories\"'),('fields.9c722366-6570-4938-b9ff-9f3d55620afe.instructions','null'),('fields.9c722366-6570-4938-b9ff-9f3d55620afe.name','\"store Categories\"'),('fields.9c722366-6570-4938-b9ff-9f3d55620afe.searchable','false'),('fields.9c722366-6570-4938-b9ff-9f3d55620afe.settings.allowSelfRelations','false'),('fields.9c722366-6570-4938-b9ff-9f3d55620afe.settings.branchLimit','null'),('fields.9c722366-6570-4938-b9ff-9f3d55620afe.settings.localizeRelations','false'),('fields.9c722366-6570-4938-b9ff-9f3d55620afe.settings.maintainHierarchy','false'),('fields.9c722366-6570-4938-b9ff-9f3d55620afe.settings.maxRelations','null'),('fields.9c722366-6570-4938-b9ff-9f3d55620afe.settings.minRelations','null'),('fields.9c722366-6570-4938-b9ff-9f3d55620afe.settings.selectionCondition.__assoc__.0.0','\"elementType\"'),('fields.9c722366-6570-4938-b9ff-9f3d55620afe.settings.selectionCondition.__assoc__.0.1','\"craft\\\\elements\\\\Entry\"'),('fields.9c722366-6570-4938-b9ff-9f3d55620afe.settings.selectionCondition.__assoc__.1.0','\"fieldContext\"'),('fields.9c722366-6570-4938-b9ff-9f3d55620afe.settings.selectionCondition.__assoc__.1.1','\"global\"'),('fields.9c722366-6570-4938-b9ff-9f3d55620afe.settings.selectionCondition.__assoc__.2.0','\"class\"'),('fields.9c722366-6570-4938-b9ff-9f3d55620afe.settings.selectionCondition.__assoc__.2.1','\"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\"'),('fields.9c722366-6570-4938-b9ff-9f3d55620afe.settings.selectionLabel','null'),('fields.9c722366-6570-4938-b9ff-9f3d55620afe.settings.showSiteMenu','false'),('fields.9c722366-6570-4938-b9ff-9f3d55620afe.settings.sources.0','\"section:18e745c4-9c85-4f4c-9219-09e2ba15599c\"'),('fields.9c722366-6570-4938-b9ff-9f3d55620afe.settings.targetSiteId','null'),('fields.9c722366-6570-4938-b9ff-9f3d55620afe.settings.validateRelatedElements','false'),('fields.9c722366-6570-4938-b9ff-9f3d55620afe.settings.viewMode','null'),('fields.9c722366-6570-4938-b9ff-9f3d55620afe.translationKeyFormat','null'),('fields.9c722366-6570-4938-b9ff-9f3d55620afe.translationMethod','\"site\"'),('fields.9c722366-6570-4938-b9ff-9f3d55620afe.type','\"craft\\\\fields\\\\Entries\"'),('fields.a5b7d0fb-075f-4551-ab53-c7a37d7ea905.columnSuffix','\"bnfajgjp\"'),('fields.a5b7d0fb-075f-4551-ab53-c7a37d7ea905.contentColumnType','\"text\"'),('fields.a5b7d0fb-075f-4551-ab53-c7a37d7ea905.fieldGroup','\"892e899e-bc4d-426a-abb8-850855a6fc7c\"'),('fields.a5b7d0fb-075f-4551-ab53-c7a37d7ea905.handle','\"informationDrinks\"'),('fields.a5b7d0fb-075f-4551-ab53-c7a37d7ea905.instructions','null'),('fields.a5b7d0fb-075f-4551-ab53-c7a37d7ea905.name','\"Information Drinks\"'),('fields.a5b7d0fb-075f-4551-ab53-c7a37d7ea905.searchable','false'),('fields.a5b7d0fb-075f-4551-ab53-c7a37d7ea905.settings.availableTransforms','\"\"'),('fields.a5b7d0fb-075f-4551-ab53-c7a37d7ea905.settings.availableVolumes','\"\"'),('fields.a5b7d0fb-075f-4551-ab53-c7a37d7ea905.settings.columnType','\"text\"'),('fields.a5b7d0fb-075f-4551-ab53-c7a37d7ea905.settings.purifierConfig','\"Default.json\"'),('fields.a5b7d0fb-075f-4551-ab53-c7a37d7ea905.settings.purifyHtml','true'),('fields.a5b7d0fb-075f-4551-ab53-c7a37d7ea905.settings.removeEmptyTags','false'),('fields.a5b7d0fb-075f-4551-ab53-c7a37d7ea905.settings.removeInlineStyles','false'),('fields.a5b7d0fb-075f-4551-ab53-c7a37d7ea905.settings.removeNbsp','false'),('fields.a5b7d0fb-075f-4551-ab53-c7a37d7ea905.settings.showHtmlButtonForNonAdmins','false'),('fields.a5b7d0fb-075f-4551-ab53-c7a37d7ea905.settings.showUnpermittedFiles','false'),('fields.a5b7d0fb-075f-4551-ab53-c7a37d7ea905.settings.showUnpermittedVolumes','false'),('fields.a5b7d0fb-075f-4551-ab53-c7a37d7ea905.settings.tinymceConfig','\"Default.json\"'),('fields.a5b7d0fb-075f-4551-ab53-c7a37d7ea905.translationKeyFormat','null'),('fields.a5b7d0fb-075f-4551-ab53-c7a37d7ea905.translationMethod','\"none\"'),('fields.a5b7d0fb-075f-4551-ab53-c7a37d7ea905.type','\"abmat\\\\tinymce\\\\Field\"'),('fields.b957af1b-f8d8-43a7-9958-98856e4707c6.columnSuffix','\"kbjjojsw\"'),('fields.b957af1b-f8d8-43a7-9958-98856e4707c6.contentColumnType','\"text\"'),('fields.b957af1b-f8d8-43a7-9958-98856e4707c6.fieldGroup','\"a16af4de-9170-42ba-9340-97ad4abfb3b2\"'),('fields.b957af1b-f8d8-43a7-9958-98856e4707c6.handle','\"whatWeAreAllAbout\"'),('fields.b957af1b-f8d8-43a7-9958-98856e4707c6.instructions','\"Dit is het gedeelte what we are all about\"'),('fields.b957af1b-f8d8-43a7-9958-98856e4707c6.name','\"what we are all about\"'),('fields.b957af1b-f8d8-43a7-9958-98856e4707c6.searchable','false'),('fields.b957af1b-f8d8-43a7-9958-98856e4707c6.settings.availableTransforms','\"\"'),('fields.b957af1b-f8d8-43a7-9958-98856e4707c6.settings.availableVolumes','\"\"'),('fields.b957af1b-f8d8-43a7-9958-98856e4707c6.settings.columnType','\"text\"'),('fields.b957af1b-f8d8-43a7-9958-98856e4707c6.settings.purifierConfig','\"Default.json\"'),('fields.b957af1b-f8d8-43a7-9958-98856e4707c6.settings.purifyHtml','true'),('fields.b957af1b-f8d8-43a7-9958-98856e4707c6.settings.removeEmptyTags','false'),('fields.b957af1b-f8d8-43a7-9958-98856e4707c6.settings.removeInlineStyles','false'),('fields.b957af1b-f8d8-43a7-9958-98856e4707c6.settings.removeNbsp','false'),('fields.b957af1b-f8d8-43a7-9958-98856e4707c6.settings.showHtmlButtonForNonAdmins','false'),('fields.b957af1b-f8d8-43a7-9958-98856e4707c6.settings.showUnpermittedFiles','false'),('fields.b957af1b-f8d8-43a7-9958-98856e4707c6.settings.showUnpermittedVolumes','false'),('fields.b957af1b-f8d8-43a7-9958-98856e4707c6.settings.tinymceConfig','\"Default.json\"'),('fields.b957af1b-f8d8-43a7-9958-98856e4707c6.translationKeyFormat','null'),('fields.b957af1b-f8d8-43a7-9958-98856e4707c6.translationMethod','\"none\"'),('fields.b957af1b-f8d8-43a7-9958-98856e4707c6.type','\"abmat\\\\tinymce\\\\Field\"'),('fields.bdfa53af-e91a-4d84-824e-a115eec9cd04.columnSuffix','\"wixbjycs\"'),('fields.bdfa53af-e91a-4d84-824e-a115eec9cd04.contentColumnType','\"text\"'),('fields.bdfa53af-e91a-4d84-824e-a115eec9cd04.fieldGroup','\"3d9e1db9-d8e4-4a7c-9a47-ca0b0dac0261\"'),('fields.bdfa53af-e91a-4d84-824e-a115eec9cd04.handle','\"pageCoppy\"'),('fields.bdfa53af-e91a-4d84-824e-a115eec9cd04.instructions','null'),('fields.bdfa53af-e91a-4d84-824e-a115eec9cd04.name','\"Page coppy\"'),('fields.bdfa53af-e91a-4d84-824e-a115eec9cd04.searchable','false'),('fields.bdfa53af-e91a-4d84-824e-a115eec9cd04.settings.availableTransforms','\"\"'),('fields.bdfa53af-e91a-4d84-824e-a115eec9cd04.settings.availableVolumes','\"\"'),('fields.bdfa53af-e91a-4d84-824e-a115eec9cd04.settings.columnType','\"text\"'),('fields.bdfa53af-e91a-4d84-824e-a115eec9cd04.settings.purifierConfig','\"Default.json\"'),('fields.bdfa53af-e91a-4d84-824e-a115eec9cd04.settings.purifyHtml','true'),('fields.bdfa53af-e91a-4d84-824e-a115eec9cd04.settings.removeEmptyTags','false'),('fields.bdfa53af-e91a-4d84-824e-a115eec9cd04.settings.removeInlineStyles','false'),('fields.bdfa53af-e91a-4d84-824e-a115eec9cd04.settings.removeNbsp','false'),('fields.bdfa53af-e91a-4d84-824e-a115eec9cd04.settings.showHtmlButtonForNonAdmins','false'),('fields.bdfa53af-e91a-4d84-824e-a115eec9cd04.settings.showUnpermittedFiles','false'),('fields.bdfa53af-e91a-4d84-824e-a115eec9cd04.settings.showUnpermittedVolumes','false'),('fields.bdfa53af-e91a-4d84-824e-a115eec9cd04.settings.tinymceConfig','\"Default.json\"'),('fields.bdfa53af-e91a-4d84-824e-a115eec9cd04.translationKeyFormat','null'),('fields.bdfa53af-e91a-4d84-824e-a115eec9cd04.translationMethod','\"none\"'),('fields.bdfa53af-e91a-4d84-824e-a115eec9cd04.type','\"abmat\\\\tinymce\\\\Field\"'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.columnSuffix','null'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.contentColumnType','\"string\"'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.fieldGroup','\"892e899e-bc4d-426a-abb8-850855a6fc7c\"'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.handle','\"drinkimagesmall\"'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.instructions','null'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.name','\"drinkImageSmall\"'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.searchable','false'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.settings.allowedKinds','null'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.settings.allowSelfRelations','false'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.settings.allowSubfolders','false'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.settings.allowUploads','true'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.settings.branchLimit','null'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.settings.defaultUploadLocationSource','\"volume:a0cd8b19-e1b7-4968-86c8-25f1345172a0\"'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.settings.defaultUploadLocationSubpath','null'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.settings.localizeRelations','false'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.settings.maintainHierarchy','false'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.settings.maxRelations','null'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.settings.minRelations','null'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.settings.previewMode','\"full\"'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.settings.restrictedDefaultUploadSubpath','null'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.settings.restrictedLocationSource','\"volume:a0cd8b19-e1b7-4968-86c8-25f1345172a0\"'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.settings.restrictedLocationSubpath','null'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.settings.restrictFiles','false'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.settings.restrictLocation','false'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.settings.selectionCondition.__assoc__.0.0','\"elementType\"'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.settings.selectionCondition.__assoc__.0.1','\"craft\\\\elements\\\\Asset\"'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.settings.selectionCondition.__assoc__.1.0','\"fieldContext\"'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.settings.selectionCondition.__assoc__.1.1','\"global\"'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.settings.selectionCondition.__assoc__.2.0','\"class\"'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.settings.selectionCondition.__assoc__.2.1','\"craft\\\\elements\\\\conditions\\\\assets\\\\AssetCondition\"'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.settings.selectionLabel','null'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.settings.showSiteMenu','true'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.settings.showUnpermittedFiles','false'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.settings.showUnpermittedVolumes','false'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.settings.sources.0','\"volume:a0cd8b19-e1b7-4968-86c8-25f1345172a0\"'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.settings.targetSiteId','null'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.settings.validateRelatedElements','false'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.settings.viewMode','\"large\"'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.translationKeyFormat','null'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.translationMethod','\"site\"'),('fields.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40.type','\"craft\\\\fields\\\\Assets\"'),('fields.e1d95b86-a3f8-45e9-b985-8605dde5b9d4.columnSuffix','\"eufivvyq\"'),('fields.e1d95b86-a3f8-45e9-b985-8605dde5b9d4.contentColumnType','\"text\"'),('fields.e1d95b86-a3f8-45e9-b985-8605dde5b9d4.fieldGroup','\"a16af4de-9170-42ba-9340-97ad4abfb3b2\"'),('fields.e1d95b86-a3f8-45e9-b985-8605dde5b9d4.handle','\"onsAssortiment\"'),('fields.e1d95b86-a3f8-45e9-b985-8605dde5b9d4.instructions','\"Dit is het gedeelte assortimen\"'),('fields.e1d95b86-a3f8-45e9-b985-8605dde5b9d4.name','\"ons assortiment\"'),('fields.e1d95b86-a3f8-45e9-b985-8605dde5b9d4.searchable','false'),('fields.e1d95b86-a3f8-45e9-b985-8605dde5b9d4.settings.availableTransforms','\"\"'),('fields.e1d95b86-a3f8-45e9-b985-8605dde5b9d4.settings.availableVolumes','\"\"'),('fields.e1d95b86-a3f8-45e9-b985-8605dde5b9d4.settings.columnType','\"text\"'),('fields.e1d95b86-a3f8-45e9-b985-8605dde5b9d4.settings.purifierConfig','\"Default.json\"'),('fields.e1d95b86-a3f8-45e9-b985-8605dde5b9d4.settings.purifyHtml','true'),('fields.e1d95b86-a3f8-45e9-b985-8605dde5b9d4.settings.removeEmptyTags','false'),('fields.e1d95b86-a3f8-45e9-b985-8605dde5b9d4.settings.removeInlineStyles','false'),('fields.e1d95b86-a3f8-45e9-b985-8605dde5b9d4.settings.removeNbsp','false'),('fields.e1d95b86-a3f8-45e9-b985-8605dde5b9d4.settings.showHtmlButtonForNonAdmins','false'),('fields.e1d95b86-a3f8-45e9-b985-8605dde5b9d4.settings.showUnpermittedFiles','false'),('fields.e1d95b86-a3f8-45e9-b985-8605dde5b9d4.settings.showUnpermittedVolumes','false'),('fields.e1d95b86-a3f8-45e9-b985-8605dde5b9d4.settings.tinymceConfig','\"Default.json\"'),('fields.e1d95b86-a3f8-45e9-b985-8605dde5b9d4.translationKeyFormat','null'),('fields.e1d95b86-a3f8-45e9-b985-8605dde5b9d4.translationMethod','\"none\"'),('fields.e1d95b86-a3f8-45e9-b985-8605dde5b9d4.type','\"abmat\\\\tinymce\\\\Field\"'),('fields.e9c3a8c7-917d-4e97-9b9b-c9113fac435a.columnSuffix','\"bqwgakef\"'),('fields.e9c3a8c7-917d-4e97-9b9b-c9113fac435a.contentColumnType','\"text\"'),('fields.e9c3a8c7-917d-4e97-9b9b-c9113fac435a.fieldGroup','\"e5ae6272-fc40-4a83-ae00-6f7847500ae8\"'),('fields.e9c3a8c7-917d-4e97-9b9b-c9113fac435a.handle','\"test\"'),('fields.e9c3a8c7-917d-4e97-9b9b-c9113fac435a.instructions','null'),('fields.e9c3a8c7-917d-4e97-9b9b-c9113fac435a.name','\"test\"'),('fields.e9c3a8c7-917d-4e97-9b9b-c9113fac435a.searchable','false'),('fields.e9c3a8c7-917d-4e97-9b9b-c9113fac435a.settings.availableTransforms','\"\"'),('fields.e9c3a8c7-917d-4e97-9b9b-c9113fac435a.settings.availableVolumes','\"\"'),('fields.e9c3a8c7-917d-4e97-9b9b-c9113fac435a.settings.columnType','\"text\"'),('fields.e9c3a8c7-917d-4e97-9b9b-c9113fac435a.settings.configSelectionMode','\"choose\"'),('fields.e9c3a8c7-917d-4e97-9b9b-c9113fac435a.settings.defaultTransform','\"\"'),('fields.e9c3a8c7-917d-4e97-9b9b-c9113fac435a.settings.manualConfig','\"\"'),('fields.e9c3a8c7-917d-4e97-9b9b-c9113fac435a.settings.purifierConfig','null'),('fields.e9c3a8c7-917d-4e97-9b9b-c9113fac435a.settings.purifyHtml','true'),('fields.e9c3a8c7-917d-4e97-9b9b-c9113fac435a.settings.redactorConfig','null'),('fields.e9c3a8c7-917d-4e97-9b9b-c9113fac435a.settings.removeEmptyTags','false'),('fields.e9c3a8c7-917d-4e97-9b9b-c9113fac435a.settings.removeInlineStyles','false'),('fields.e9c3a8c7-917d-4e97-9b9b-c9113fac435a.settings.removeNbsp','false'),('fields.e9c3a8c7-917d-4e97-9b9b-c9113fac435a.settings.showHtmlButtonForNonAdmins','false'),('fields.e9c3a8c7-917d-4e97-9b9b-c9113fac435a.settings.showUnpermittedFiles','false'),('fields.e9c3a8c7-917d-4e97-9b9b-c9113fac435a.settings.showUnpermittedVolumes','false'),('fields.e9c3a8c7-917d-4e97-9b9b-c9113fac435a.settings.uiMode','\"enlarged\"'),('fields.e9c3a8c7-917d-4e97-9b9b-c9113fac435a.translationKeyFormat','null'),('fields.e9c3a8c7-917d-4e97-9b9b-c9113fac435a.translationMethod','\"none\"'),('fields.e9c3a8c7-917d-4e97-9b9b-c9113fac435a.type','\"craft\\\\redactor\\\\Field\"'),('fields.f0f0a2ff-68fd-4217-93b1-7318025da83b.columnSuffix','\"zfzzucta\"'),('fields.f0f0a2ff-68fd-4217-93b1-7318025da83b.contentColumnType','\"decimal(12,2)\"'),('fields.f0f0a2ff-68fd-4217-93b1-7318025da83b.fieldGroup','\"892e899e-bc4d-426a-abb8-850855a6fc7c\"'),('fields.f0f0a2ff-68fd-4217-93b1-7318025da83b.handle','\"priceDrinks\"'),('fields.f0f0a2ff-68fd-4217-93b1-7318025da83b.instructions','\"The price of the drinks (number only)\"'),('fields.f0f0a2ff-68fd-4217-93b1-7318025da83b.name','\"Price drinks\"'),('fields.f0f0a2ff-68fd-4217-93b1-7318025da83b.searchable','false'),('fields.f0f0a2ff-68fd-4217-93b1-7318025da83b.settings.decimals','2'),('fields.f0f0a2ff-68fd-4217-93b1-7318025da83b.settings.defaultValue','null'),('fields.f0f0a2ff-68fd-4217-93b1-7318025da83b.settings.max','null'),('fields.f0f0a2ff-68fd-4217-93b1-7318025da83b.settings.min','0'),('fields.f0f0a2ff-68fd-4217-93b1-7318025da83b.settings.prefix','\"€\"'),('fields.f0f0a2ff-68fd-4217-93b1-7318025da83b.settings.previewCurrency','\"EUR\"'),('fields.f0f0a2ff-68fd-4217-93b1-7318025da83b.settings.previewFormat','\"currency\"'),('fields.f0f0a2ff-68fd-4217-93b1-7318025da83b.settings.size','null'),('fields.f0f0a2ff-68fd-4217-93b1-7318025da83b.settings.suffix','null'),('fields.f0f0a2ff-68fd-4217-93b1-7318025da83b.translationKeyFormat','null'),('fields.f0f0a2ff-68fd-4217-93b1-7318025da83b.translationMethod','\"none\"'),('fields.f0f0a2ff-68fd-4217-93b1-7318025da83b.type','\"craft\\\\fields\\\\Number\"'),('fs.aboutUs.hasUrls','true'),('fs.aboutUs.name','\"about Us\"'),('fs.aboutUs.settings.path','\"@webroot/images/About\"'),('fs.aboutUs.type','\"craft\\\\fs\\\\Local\"'),('fs.aboutUs.url','\"@web/images/About\"'),('fs.drinks.hasUrls','true'),('fs.drinks.name','\"drinks\"'),('fs.drinks.settings.path','\"@webroot/images/dranken\"'),('fs.drinks.type','\"craft\\\\fs\\\\Local\"'),('fs.drinks.url','\"@web/images/dranken\"'),('fs.home.hasUrls','true'),('fs.home.name','\"home\"'),('fs.home.settings.path','\"@webroot/images/Frontpage\"'),('fs.home.type','\"craft\\\\fs\\\\Local\"'),('fs.home.url','\"@web/images/Frontpage\"'),('imageTransforms.4228d972-2762-4d4c-b1a6-d69ac37ceefa.fill','null'),('imageTransforms.4228d972-2762-4d4c-b1a6-d69ac37ceefa.format','null'),('imageTransforms.4228d972-2762-4d4c-b1a6-d69ac37ceefa.handle','\"drinksversion\"'),('imageTransforms.4228d972-2762-4d4c-b1a6-d69ac37ceefa.height','200'),('imageTransforms.4228d972-2762-4d4c-b1a6-d69ac37ceefa.interlace','\"none\"'),('imageTransforms.4228d972-2762-4d4c-b1a6-d69ac37ceefa.mode','\"crop\"'),('imageTransforms.4228d972-2762-4d4c-b1a6-d69ac37ceefa.name','\"drinksVersion\"'),('imageTransforms.4228d972-2762-4d4c-b1a6-d69ac37ceefa.position','\"center-center\"'),('imageTransforms.4228d972-2762-4d4c-b1a6-d69ac37ceefa.quality','null'),('imageTransforms.4228d972-2762-4d4c-b1a6-d69ac37ceefa.upscale','true'),('imageTransforms.4228d972-2762-4d4c-b1a6-d69ac37ceefa.width','null'),('meta.__names__.06fe3a33-66ad-4be8-9254-a3271ae424ed','\"about Us\"'),('meta.__names__.18e745c4-9c85-4f4c-9219-09e2ba15599c','\"Store Categories\"'),('meta.__names__.224b5a40-80ce-447d-8be5-4e349e553bcd','\"header1\"'),('meta.__names__.2fdf6f3c-8796-4125-a22a-392fe3486fef','\"introduction\"'),('meta.__names__.312c1641-3732-473d-82d8-212a18bc8443','\"Default\"'),('meta.__names__.387b84cf-e0f9-41a7-976d-9a2d94c8ee4d','\"Drank Webshop\"'),('meta.__names__.3d1094d4-9576-466e-8f54-d264d7286642','\"Info about\"'),('meta.__names__.3d9e1db9-d8e4-4a7c-9a47-ca0b0dac0261','\"Common\"'),('meta.__names__.4228d972-2762-4d4c-b1a6-d69ac37ceefa','\"drinksVersion\"'),('meta.__names__.4e90476a-1613-447e-9942-30d691eec5b1','\"drinks\"'),('meta.__names__.51b05e04-81a8-4074-bb1c-64f3090a35c6','\"Alcohol percentage\"'),('meta.__names__.597ef37d-ecf5-4ed9-92ef-7b0f956184dd','\"home\"'),('meta.__names__.6b5f5717-efc9-40c6-9d68-97b86792a46c','\"Default\"'),('meta.__names__.892e899e-bc4d-426a-abb8-850855a6fc7c','\"Drinks\"'),('meta.__names__.8edf0eb0-db84-407e-8941-f20dada533ee','\"store categories\"'),('meta.__names__.9c58ac58-2bbb-49cf-8e49-c1f4f9364f6a','\"enkel alcohol\"'),('meta.__names__.9c722366-6570-4938-b9ff-9f3d55620afe','\"store Categories\"'),('meta.__names__.a092b4e1-f8a1-411a-8964-8779a4da42f7','\"home\"'),('meta.__names__.a0cd8b19-e1b7-4968-86c8-25f1345172a0','\"drinks\"'),('meta.__names__.a16af4de-9170-42ba-9340-97ad4abfb3b2','\"home\"'),('meta.__names__.a3ea80b4-e1b2-40ba-9389-ad406905a942','\"Drank Webshop\"'),('meta.__names__.a5b7d0fb-075f-4551-ab53-c7a37d7ea905','\"Information Drinks\"'),('meta.__names__.b4927f39-21eb-487f-9819-47b121ed4ca8','\"home\"'),('meta.__names__.b957af1b-f8d8-43a7-9958-98856e4707c6','\"what we are all about\"'),('meta.__names__.bdfa53af-e91a-4d84-824e-a115eec9cd04','\"Page coppy\"'),('meta.__names__.c0d44cc8-1c83-47d4-9b83-9ba94e0224dc','\"About us\"'),('meta.__names__.cbc6efb9-07dd-46a7-8965-d8c5bf50cd40','\"drinkImageSmall\"'),('meta.__names__.e1d95b86-a3f8-45e9-b985-8605dde5b9d4','\"ons assortiment\"'),('meta.__names__.e5ae6272-fc40-4a83-ae00-6f7847500ae8','\"About us\"'),('meta.__names__.e671db06-f0c3-45b9-a032-192145ab9bc5','\"About us\"'),('meta.__names__.e9c3a8c7-917d-4e97-9b9b-c9113fac435a','\"test\"'),('meta.__names__.f0f0a2ff-68fd-4217-93b1-7318025da83b','\"Price drinks\"'),('plugins.abm-tinymce.edition','\"standard\"'),('plugins.abm-tinymce.enabled','true'),('plugins.abm-tinymce.schemaVersion','\"1.0.0\"'),('plugins.cookie-consent-banner.edition','\"standard\"'),('plugins.cookie-consent-banner.enabled','true'),('plugins.cookie-consent-banner.schemaVersion','\"1.0.1\"'),('plugins.cookie-consent-banner.settings.allow','\"Allow cookies\"'),('plugins.cookie-consent-banner.settings.async_js','\"1\"'),('plugins.cookie-consent-banner.settings.auto_inject','\"\"'),('plugins.cookie-consent-banner.settings.decline','\"Decline\"'),('plugins.cookie-consent-banner.settings.defer_js','\"1\"'),('plugins.cookie-consent-banner.settings.disable_in_live_preview','\"\"'),('plugins.cookie-consent-banner.settings.dismiss','\"Got it!\"'),('plugins.cookie-consent-banner.settings.dismiss_on_scroll','\"1000\"'),('plugins.cookie-consent-banner.settings.dismiss_on_timeout','\"300\"'),('plugins.cookie-consent-banner.settings.excluded_categories','null'),('plugins.cookie-consent-banner.settings.excluded_entry_types','null'),('plugins.cookie-consent-banner.settings.expiry_days','\"1\"'),('plugins.cookie-consent-banner.settings.honour_do_not_track_header','\"\"'),('plugins.cookie-consent-banner.settings.layout','\"block\"'),('plugins.cookie-consent-banner.settings.learn','\"Learn More\"'),('plugins.cookie-consent-banner.settings.learn_more_link','\"http://cookiesandyou.com/\"'),('plugins.cookie-consent-banner.settings.message','\"This website uses cookies to ensure you get the best experience on our website.\"'),('plugins.cookie-consent-banner.settings.palette','\"default\"'),('plugins.cookie-consent-banner.settings.palette_banner','\"000\"'),('plugins.cookie-consent-banner.settings.palette_banner_text','\"ffffff\"'),('plugins.cookie-consent-banner.settings.palette_button','\"f1d600\"'),('plugins.cookie-consent-banner.settings.palette_button_text','\"000000\"'),('plugins.cookie-consent-banner.settings.palette_left_button_bg','\"f1d600\"'),('plugins.cookie-consent-banner.settings.palette_left_button_text','\"000000\"'),('plugins.cookie-consent-banner.settings.palette_link','\"ffffff\"'),('plugins.cookie-consent-banner.settings.position','\"bottom-left\"'),('plugins.cookie-consent-banner.settings.preload_css','\"\"'),('plugins.cookie-consent-banner.settings.revokable','\"\"'),('plugins.cookie-consent-banner.settings.secure_only','\"1\"'),('plugins.cookie-consent-banner.settings.target','\"_blank\"'),('plugins.cookie-consent-banner.settings.type','\"info\"'),('plugins.cookies.edition','\"standard\"'),('plugins.cookies.enabled','true'),('plugins.cookies.schemaVersion','\"1.0.0\"'),('plugins.element-api.edition','\"standard\"'),('plugins.element-api.enabled','true'),('plugins.element-api.schemaVersion','\"1.0.0\"'),('plugins.geoaddress.edition','\"standard\"'),('plugins.geoaddress.enabled','true'),('plugins.geoaddress.schemaVersion','\"1.0.1\"'),('plugins.geoaddress.settings.googleApiKey','\"AIzaSyDFY0QkI8ohMzEUWK373CvpOI9SRSmGFeo\"'),('plugins.redactor.edition','\"standard\"'),('plugins.redactor.enabled','true'),('plugins.redactor.schemaVersion','\"2.3.0\"'),('sections.18e745c4-9c85-4f4c-9219-09e2ba15599c.defaultPlacement','\"end\"'),('sections.18e745c4-9c85-4f4c-9219-09e2ba15599c.enableVersioning','true'),('sections.18e745c4-9c85-4f4c-9219-09e2ba15599c.handle','\"storeCategories\"'),('sections.18e745c4-9c85-4f4c-9219-09e2ba15599c.name','\"Store Categories\"'),('sections.18e745c4-9c85-4f4c-9219-09e2ba15599c.propagationMethod','\"all\"'),('sections.18e745c4-9c85-4f4c-9219-09e2ba15599c.siteSettings.387b84cf-e0f9-41a7-976d-9a2d94c8ee4d.enabledByDefault','true'),('sections.18e745c4-9c85-4f4c-9219-09e2ba15599c.siteSettings.387b84cf-e0f9-41a7-976d-9a2d94c8ee4d.hasUrls','true'),('sections.18e745c4-9c85-4f4c-9219-09e2ba15599c.siteSettings.387b84cf-e0f9-41a7-976d-9a2d94c8ee4d.template','\"store-categories/_entry\"'),('sections.18e745c4-9c85-4f4c-9219-09e2ba15599c.siteSettings.387b84cf-e0f9-41a7-976d-9a2d94c8ee4d.uriFormat','\"store-categories/{slug}\"'),('sections.18e745c4-9c85-4f4c-9219-09e2ba15599c.structure.maxLevels','null'),('sections.18e745c4-9c85-4f4c-9219-09e2ba15599c.structure.uid','\"af4055c1-347e-4246-b763-a3d5a7188dee\"'),('sections.18e745c4-9c85-4f4c-9219-09e2ba15599c.type','\"structure\"'),('sections.4e90476a-1613-447e-9942-30d691eec5b1.defaultPlacement','\"end\"'),('sections.4e90476a-1613-447e-9942-30d691eec5b1.enableVersioning','true'),('sections.4e90476a-1613-447e-9942-30d691eec5b1.handle','\"drinks\"'),('sections.4e90476a-1613-447e-9942-30d691eec5b1.name','\"drinks\"'),('sections.4e90476a-1613-447e-9942-30d691eec5b1.propagationMethod','\"all\"'),('sections.4e90476a-1613-447e-9942-30d691eec5b1.siteSettings.387b84cf-e0f9-41a7-976d-9a2d94c8ee4d.enabledByDefault','true'),('sections.4e90476a-1613-447e-9942-30d691eec5b1.siteSettings.387b84cf-e0f9-41a7-976d-9a2d94c8ee4d.hasUrls','true'),('sections.4e90476a-1613-447e-9942-30d691eec5b1.siteSettings.387b84cf-e0f9-41a7-976d-9a2d94c8ee4d.template','\"drinks/_entry\"'),('sections.4e90476a-1613-447e-9942-30d691eec5b1.siteSettings.387b84cf-e0f9-41a7-976d-9a2d94c8ee4d.uriFormat','\"drinks/{slug}\"'),('sections.4e90476a-1613-447e-9942-30d691eec5b1.type','\"channel\"'),('sections.b4927f39-21eb-487f-9819-47b121ed4ca8.defaultPlacement','\"end\"'),('sections.b4927f39-21eb-487f-9819-47b121ed4ca8.enableVersioning','true'),('sections.b4927f39-21eb-487f-9819-47b121ed4ca8.handle','\"home\"'),('sections.b4927f39-21eb-487f-9819-47b121ed4ca8.name','\"home\"'),('sections.b4927f39-21eb-487f-9819-47b121ed4ca8.propagationMethod','\"all\"'),('sections.b4927f39-21eb-487f-9819-47b121ed4ca8.siteSettings.387b84cf-e0f9-41a7-976d-9a2d94c8ee4d.enabledByDefault','true'),('sections.b4927f39-21eb-487f-9819-47b121ed4ca8.siteSettings.387b84cf-e0f9-41a7-976d-9a2d94c8ee4d.hasUrls','true'),('sections.b4927f39-21eb-487f-9819-47b121ed4ca8.siteSettings.387b84cf-e0f9-41a7-976d-9a2d94c8ee4d.template','null'),('sections.b4927f39-21eb-487f-9819-47b121ed4ca8.siteSettings.387b84cf-e0f9-41a7-976d-9a2d94c8ee4d.uriFormat','\"__home__\"'),('sections.b4927f39-21eb-487f-9819-47b121ed4ca8.type','\"single\"'),('sections.c0d44cc8-1c83-47d4-9b83-9ba94e0224dc.defaultPlacement','\"end\"'),('sections.c0d44cc8-1c83-47d4-9b83-9ba94e0224dc.enableVersioning','true'),('sections.c0d44cc8-1c83-47d4-9b83-9ba94e0224dc.handle','\"aboutUs\"'),('sections.c0d44cc8-1c83-47d4-9b83-9ba94e0224dc.name','\"About us\"'),('sections.c0d44cc8-1c83-47d4-9b83-9ba94e0224dc.propagationMethod','\"all\"'),('sections.c0d44cc8-1c83-47d4-9b83-9ba94e0224dc.siteSettings.387b84cf-e0f9-41a7-976d-9a2d94c8ee4d.enabledByDefault','true'),('sections.c0d44cc8-1c83-47d4-9b83-9ba94e0224dc.siteSettings.387b84cf-e0f9-41a7-976d-9a2d94c8ee4d.hasUrls','true'),('sections.c0d44cc8-1c83-47d4-9b83-9ba94e0224dc.siteSettings.387b84cf-e0f9-41a7-976d-9a2d94c8ee4d.template','\"aboutUs/_entry.twig\"'),('sections.c0d44cc8-1c83-47d4-9b83-9ba94e0224dc.siteSettings.387b84cf-e0f9-41a7-976d-9a2d94c8ee4d.uriFormat','\"aboutUs/{slug}\"'),('sections.c0d44cc8-1c83-47d4-9b83-9ba94e0224dc.type','\"single\"'),('siteGroups.a3ea80b4-e1b2-40ba-9389-ad406905a942.name','\"Drank Webshop\"'),('sites.387b84cf-e0f9-41a7-976d-9a2d94c8ee4d.baseUrl','\"$PRIMARY_SITE_URL\"'),('sites.387b84cf-e0f9-41a7-976d-9a2d94c8ee4d.handle','\"default\"'),('sites.387b84cf-e0f9-41a7-976d-9a2d94c8ee4d.hasUrls','true'),('sites.387b84cf-e0f9-41a7-976d-9a2d94c8ee4d.language','\"en-US\"'),('sites.387b84cf-e0f9-41a7-976d-9a2d94c8ee4d.name','\"Drank Webshop\"'),('sites.387b84cf-e0f9-41a7-976d-9a2d94c8ee4d.primary','true'),('sites.387b84cf-e0f9-41a7-976d-9a2d94c8ee4d.siteGroup','\"a3ea80b4-e1b2-40ba-9389-ad406905a942\"'),('sites.387b84cf-e0f9-41a7-976d-9a2d94c8ee4d.sortOrder','1'),('system.edition','\"solo\"'),('system.live','true'),('system.name','\"Drank Webshop\"'),('system.schemaVersion','\"4.5.3.0\"'),('system.timeZone','\"America/Los_Angeles\"'),('users.allowPublicRegistration','false'),('users.defaultGroup','null'),('users.photoSubpath','null'),('users.photoVolumeUid','null'),('users.requireEmailVerification','true'),('volumes.06fe3a33-66ad-4be8-9254-a3271ae424ed.fieldLayouts.1dea624a-e24b-4dfd-b31b-c5ec1d364999.tabs.0.elementCondition','null'),('volumes.06fe3a33-66ad-4be8-9254-a3271ae424ed.fieldLayouts.1dea624a-e24b-4dfd-b31b-c5ec1d364999.tabs.0.elements.0.autocapitalize','true'),('volumes.06fe3a33-66ad-4be8-9254-a3271ae424ed.fieldLayouts.1dea624a-e24b-4dfd-b31b-c5ec1d364999.tabs.0.elements.0.autocomplete','false'),('volumes.06fe3a33-66ad-4be8-9254-a3271ae424ed.fieldLayouts.1dea624a-e24b-4dfd-b31b-c5ec1d364999.tabs.0.elements.0.autocorrect','true'),('volumes.06fe3a33-66ad-4be8-9254-a3271ae424ed.fieldLayouts.1dea624a-e24b-4dfd-b31b-c5ec1d364999.tabs.0.elements.0.class','null'),('volumes.06fe3a33-66ad-4be8-9254-a3271ae424ed.fieldLayouts.1dea624a-e24b-4dfd-b31b-c5ec1d364999.tabs.0.elements.0.disabled','false'),('volumes.06fe3a33-66ad-4be8-9254-a3271ae424ed.fieldLayouts.1dea624a-e24b-4dfd-b31b-c5ec1d364999.tabs.0.elements.0.elementCondition','null'),('volumes.06fe3a33-66ad-4be8-9254-a3271ae424ed.fieldLayouts.1dea624a-e24b-4dfd-b31b-c5ec1d364999.tabs.0.elements.0.id','null'),('volumes.06fe3a33-66ad-4be8-9254-a3271ae424ed.fieldLayouts.1dea624a-e24b-4dfd-b31b-c5ec1d364999.tabs.0.elements.0.inputType','null'),('volumes.06fe3a33-66ad-4be8-9254-a3271ae424ed.fieldLayouts.1dea624a-e24b-4dfd-b31b-c5ec1d364999.tabs.0.elements.0.instructions','null'),('volumes.06fe3a33-66ad-4be8-9254-a3271ae424ed.fieldLayouts.1dea624a-e24b-4dfd-b31b-c5ec1d364999.tabs.0.elements.0.label','null'),('volumes.06fe3a33-66ad-4be8-9254-a3271ae424ed.fieldLayouts.1dea624a-e24b-4dfd-b31b-c5ec1d364999.tabs.0.elements.0.max','null'),('volumes.06fe3a33-66ad-4be8-9254-a3271ae424ed.fieldLayouts.1dea624a-e24b-4dfd-b31b-c5ec1d364999.tabs.0.elements.0.min','null'),('volumes.06fe3a33-66ad-4be8-9254-a3271ae424ed.fieldLayouts.1dea624a-e24b-4dfd-b31b-c5ec1d364999.tabs.0.elements.0.name','null'),('volumes.06fe3a33-66ad-4be8-9254-a3271ae424ed.fieldLayouts.1dea624a-e24b-4dfd-b31b-c5ec1d364999.tabs.0.elements.0.orientation','null'),('volumes.06fe3a33-66ad-4be8-9254-a3271ae424ed.fieldLayouts.1dea624a-e24b-4dfd-b31b-c5ec1d364999.tabs.0.elements.0.placeholder','null'),('volumes.06fe3a33-66ad-4be8-9254-a3271ae424ed.fieldLayouts.1dea624a-e24b-4dfd-b31b-c5ec1d364999.tabs.0.elements.0.readonly','false'),('volumes.06fe3a33-66ad-4be8-9254-a3271ae424ed.fieldLayouts.1dea624a-e24b-4dfd-b31b-c5ec1d364999.tabs.0.elements.0.requirable','false'),('volumes.06fe3a33-66ad-4be8-9254-a3271ae424ed.fieldLayouts.1dea624a-e24b-4dfd-b31b-c5ec1d364999.tabs.0.elements.0.size','null'),('volumes.06fe3a33-66ad-4be8-9254-a3271ae424ed.fieldLayouts.1dea624a-e24b-4dfd-b31b-c5ec1d364999.tabs.0.elements.0.step','null'),('volumes.06fe3a33-66ad-4be8-9254-a3271ae424ed.fieldLayouts.1dea624a-e24b-4dfd-b31b-c5ec1d364999.tabs.0.elements.0.tip','null'),('volumes.06fe3a33-66ad-4be8-9254-a3271ae424ed.fieldLayouts.1dea624a-e24b-4dfd-b31b-c5ec1d364999.tabs.0.elements.0.title','null'),('volumes.06fe3a33-66ad-4be8-9254-a3271ae424ed.fieldLayouts.1dea624a-e24b-4dfd-b31b-c5ec1d364999.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\"'),('volumes.06fe3a33-66ad-4be8-9254-a3271ae424ed.fieldLayouts.1dea624a-e24b-4dfd-b31b-c5ec1d364999.tabs.0.elements.0.uid','\"29b73afa-abc7-46de-9545-bf728b43346c\"'),('volumes.06fe3a33-66ad-4be8-9254-a3271ae424ed.fieldLayouts.1dea624a-e24b-4dfd-b31b-c5ec1d364999.tabs.0.elements.0.userCondition','null'),('volumes.06fe3a33-66ad-4be8-9254-a3271ae424ed.fieldLayouts.1dea624a-e24b-4dfd-b31b-c5ec1d364999.tabs.0.elements.0.warning','null'),('volumes.06fe3a33-66ad-4be8-9254-a3271ae424ed.fieldLayouts.1dea624a-e24b-4dfd-b31b-c5ec1d364999.tabs.0.elements.0.width','100'),('volumes.06fe3a33-66ad-4be8-9254-a3271ae424ed.fieldLayouts.1dea624a-e24b-4dfd-b31b-c5ec1d364999.tabs.0.name','\"Content\"'),('volumes.06fe3a33-66ad-4be8-9254-a3271ae424ed.fieldLayouts.1dea624a-e24b-4dfd-b31b-c5ec1d364999.tabs.0.uid','\"5c975bba-4d1c-4ebd-ba80-865cfd5a8c19\"'),('volumes.06fe3a33-66ad-4be8-9254-a3271ae424ed.fieldLayouts.1dea624a-e24b-4dfd-b31b-c5ec1d364999.tabs.0.userCondition','null'),('volumes.06fe3a33-66ad-4be8-9254-a3271ae424ed.fs','\"aboutUs\"'),('volumes.06fe3a33-66ad-4be8-9254-a3271ae424ed.handle','\"aboutUs\"'),('volumes.06fe3a33-66ad-4be8-9254-a3271ae424ed.name','\"about Us\"'),('volumes.06fe3a33-66ad-4be8-9254-a3271ae424ed.sortOrder','4'),('volumes.06fe3a33-66ad-4be8-9254-a3271ae424ed.titleTranslationKeyFormat','null'),('volumes.06fe3a33-66ad-4be8-9254-a3271ae424ed.titleTranslationMethod','\"site\"'),('volumes.06fe3a33-66ad-4be8-9254-a3271ae424ed.transformFs','\"\"'),('volumes.06fe3a33-66ad-4be8-9254-a3271ae424ed.transformSubpath','\"\"'),('volumes.a092b4e1-f8a1-411a-8964-8779a4da42f7.fieldLayouts.81516ae8-d3f5-4f39-802c-63a89a4b21b9.tabs.0.elementCondition','null'),('volumes.a092b4e1-f8a1-411a-8964-8779a4da42f7.fieldLayouts.81516ae8-d3f5-4f39-802c-63a89a4b21b9.tabs.0.elements.0.autocapitalize','true'),('volumes.a092b4e1-f8a1-411a-8964-8779a4da42f7.fieldLayouts.81516ae8-d3f5-4f39-802c-63a89a4b21b9.tabs.0.elements.0.autocomplete','false'),('volumes.a092b4e1-f8a1-411a-8964-8779a4da42f7.fieldLayouts.81516ae8-d3f5-4f39-802c-63a89a4b21b9.tabs.0.elements.0.autocorrect','true'),('volumes.a092b4e1-f8a1-411a-8964-8779a4da42f7.fieldLayouts.81516ae8-d3f5-4f39-802c-63a89a4b21b9.tabs.0.elements.0.class','null'),('volumes.a092b4e1-f8a1-411a-8964-8779a4da42f7.fieldLayouts.81516ae8-d3f5-4f39-802c-63a89a4b21b9.tabs.0.elements.0.disabled','false'),('volumes.a092b4e1-f8a1-411a-8964-8779a4da42f7.fieldLayouts.81516ae8-d3f5-4f39-802c-63a89a4b21b9.tabs.0.elements.0.elementCondition','null'),('volumes.a092b4e1-f8a1-411a-8964-8779a4da42f7.fieldLayouts.81516ae8-d3f5-4f39-802c-63a89a4b21b9.tabs.0.elements.0.id','null'),('volumes.a092b4e1-f8a1-411a-8964-8779a4da42f7.fieldLayouts.81516ae8-d3f5-4f39-802c-63a89a4b21b9.tabs.0.elements.0.inputType','null'),('volumes.a092b4e1-f8a1-411a-8964-8779a4da42f7.fieldLayouts.81516ae8-d3f5-4f39-802c-63a89a4b21b9.tabs.0.elements.0.instructions','null'),('volumes.a092b4e1-f8a1-411a-8964-8779a4da42f7.fieldLayouts.81516ae8-d3f5-4f39-802c-63a89a4b21b9.tabs.0.elements.0.label','null'),('volumes.a092b4e1-f8a1-411a-8964-8779a4da42f7.fieldLayouts.81516ae8-d3f5-4f39-802c-63a89a4b21b9.tabs.0.elements.0.max','null'),('volumes.a092b4e1-f8a1-411a-8964-8779a4da42f7.fieldLayouts.81516ae8-d3f5-4f39-802c-63a89a4b21b9.tabs.0.elements.0.min','null'),('volumes.a092b4e1-f8a1-411a-8964-8779a4da42f7.fieldLayouts.81516ae8-d3f5-4f39-802c-63a89a4b21b9.tabs.0.elements.0.name','null'),('volumes.a092b4e1-f8a1-411a-8964-8779a4da42f7.fieldLayouts.81516ae8-d3f5-4f39-802c-63a89a4b21b9.tabs.0.elements.0.orientation','null'),('volumes.a092b4e1-f8a1-411a-8964-8779a4da42f7.fieldLayouts.81516ae8-d3f5-4f39-802c-63a89a4b21b9.tabs.0.elements.0.placeholder','null'),('volumes.a092b4e1-f8a1-411a-8964-8779a4da42f7.fieldLayouts.81516ae8-d3f5-4f39-802c-63a89a4b21b9.tabs.0.elements.0.readonly','false'),('volumes.a092b4e1-f8a1-411a-8964-8779a4da42f7.fieldLayouts.81516ae8-d3f5-4f39-802c-63a89a4b21b9.tabs.0.elements.0.requirable','false'),('volumes.a092b4e1-f8a1-411a-8964-8779a4da42f7.fieldLayouts.81516ae8-d3f5-4f39-802c-63a89a4b21b9.tabs.0.elements.0.size','null'),('volumes.a092b4e1-f8a1-411a-8964-8779a4da42f7.fieldLayouts.81516ae8-d3f5-4f39-802c-63a89a4b21b9.tabs.0.elements.0.step','null'),('volumes.a092b4e1-f8a1-411a-8964-8779a4da42f7.fieldLayouts.81516ae8-d3f5-4f39-802c-63a89a4b21b9.tabs.0.elements.0.tip','null'),('volumes.a092b4e1-f8a1-411a-8964-8779a4da42f7.fieldLayouts.81516ae8-d3f5-4f39-802c-63a89a4b21b9.tabs.0.elements.0.title','null'),('volumes.a092b4e1-f8a1-411a-8964-8779a4da42f7.fieldLayouts.81516ae8-d3f5-4f39-802c-63a89a4b21b9.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\"'),('volumes.a092b4e1-f8a1-411a-8964-8779a4da42f7.fieldLayouts.81516ae8-d3f5-4f39-802c-63a89a4b21b9.tabs.0.elements.0.uid','\"fdb68d94-03a3-42d8-9311-1f38ea94cd2c\"'),('volumes.a092b4e1-f8a1-411a-8964-8779a4da42f7.fieldLayouts.81516ae8-d3f5-4f39-802c-63a89a4b21b9.tabs.0.elements.0.userCondition','null'),('volumes.a092b4e1-f8a1-411a-8964-8779a4da42f7.fieldLayouts.81516ae8-d3f5-4f39-802c-63a89a4b21b9.tabs.0.elements.0.warning','null'),('volumes.a092b4e1-f8a1-411a-8964-8779a4da42f7.fieldLayouts.81516ae8-d3f5-4f39-802c-63a89a4b21b9.tabs.0.elements.0.width','100'),('volumes.a092b4e1-f8a1-411a-8964-8779a4da42f7.fieldLayouts.81516ae8-d3f5-4f39-802c-63a89a4b21b9.tabs.0.name','\"Content\"'),('volumes.a092b4e1-f8a1-411a-8964-8779a4da42f7.fieldLayouts.81516ae8-d3f5-4f39-802c-63a89a4b21b9.tabs.0.uid','\"62e31e6a-94a0-4d0f-bd41-adc1916f8e06\"'),('volumes.a092b4e1-f8a1-411a-8964-8779a4da42f7.fieldLayouts.81516ae8-d3f5-4f39-802c-63a89a4b21b9.tabs.0.userCondition','null'),('volumes.a092b4e1-f8a1-411a-8964-8779a4da42f7.fs','\"home\"'),('volumes.a092b4e1-f8a1-411a-8964-8779a4da42f7.handle','\"home\"'),('volumes.a092b4e1-f8a1-411a-8964-8779a4da42f7.name','\"home\"'),('volumes.a092b4e1-f8a1-411a-8964-8779a4da42f7.sortOrder','3'),('volumes.a092b4e1-f8a1-411a-8964-8779a4da42f7.titleTranslationKeyFormat','null'),('volumes.a092b4e1-f8a1-411a-8964-8779a4da42f7.titleTranslationMethod','\"site\"'),('volumes.a092b4e1-f8a1-411a-8964-8779a4da42f7.transformFs','\"\"'),('volumes.a092b4e1-f8a1-411a-8964-8779a4da42f7.transformSubpath','\"\"'),('volumes.a0cd8b19-e1b7-4968-86c8-25f1345172a0.fieldLayouts.e3587594-ffc4-4e9d-bffd-8a3e848cf461.tabs.0.elementCondition','null'),('volumes.a0cd8b19-e1b7-4968-86c8-25f1345172a0.fieldLayouts.e3587594-ffc4-4e9d-bffd-8a3e848cf461.tabs.0.elements.0.autocapitalize','true'),('volumes.a0cd8b19-e1b7-4968-86c8-25f1345172a0.fieldLayouts.e3587594-ffc4-4e9d-bffd-8a3e848cf461.tabs.0.elements.0.autocomplete','false'),('volumes.a0cd8b19-e1b7-4968-86c8-25f1345172a0.fieldLayouts.e3587594-ffc4-4e9d-bffd-8a3e848cf461.tabs.0.elements.0.autocorrect','true'),('volumes.a0cd8b19-e1b7-4968-86c8-25f1345172a0.fieldLayouts.e3587594-ffc4-4e9d-bffd-8a3e848cf461.tabs.0.elements.0.class','null'),('volumes.a0cd8b19-e1b7-4968-86c8-25f1345172a0.fieldLayouts.e3587594-ffc4-4e9d-bffd-8a3e848cf461.tabs.0.elements.0.disabled','false'),('volumes.a0cd8b19-e1b7-4968-86c8-25f1345172a0.fieldLayouts.e3587594-ffc4-4e9d-bffd-8a3e848cf461.tabs.0.elements.0.elementCondition','null'),('volumes.a0cd8b19-e1b7-4968-86c8-25f1345172a0.fieldLayouts.e3587594-ffc4-4e9d-bffd-8a3e848cf461.tabs.0.elements.0.id','null'),('volumes.a0cd8b19-e1b7-4968-86c8-25f1345172a0.fieldLayouts.e3587594-ffc4-4e9d-bffd-8a3e848cf461.tabs.0.elements.0.inputType','null'),('volumes.a0cd8b19-e1b7-4968-86c8-25f1345172a0.fieldLayouts.e3587594-ffc4-4e9d-bffd-8a3e848cf461.tabs.0.elements.0.instructions','null'),('volumes.a0cd8b19-e1b7-4968-86c8-25f1345172a0.fieldLayouts.e3587594-ffc4-4e9d-bffd-8a3e848cf461.tabs.0.elements.0.label','null'),('volumes.a0cd8b19-e1b7-4968-86c8-25f1345172a0.fieldLayouts.e3587594-ffc4-4e9d-bffd-8a3e848cf461.tabs.0.elements.0.max','null'),('volumes.a0cd8b19-e1b7-4968-86c8-25f1345172a0.fieldLayouts.e3587594-ffc4-4e9d-bffd-8a3e848cf461.tabs.0.elements.0.min','null'),('volumes.a0cd8b19-e1b7-4968-86c8-25f1345172a0.fieldLayouts.e3587594-ffc4-4e9d-bffd-8a3e848cf461.tabs.0.elements.0.name','null'),('volumes.a0cd8b19-e1b7-4968-86c8-25f1345172a0.fieldLayouts.e3587594-ffc4-4e9d-bffd-8a3e848cf461.tabs.0.elements.0.orientation','null'),('volumes.a0cd8b19-e1b7-4968-86c8-25f1345172a0.fieldLayouts.e3587594-ffc4-4e9d-bffd-8a3e848cf461.tabs.0.elements.0.placeholder','null'),('volumes.a0cd8b19-e1b7-4968-86c8-25f1345172a0.fieldLayouts.e3587594-ffc4-4e9d-bffd-8a3e848cf461.tabs.0.elements.0.readonly','false'),('volumes.a0cd8b19-e1b7-4968-86c8-25f1345172a0.fieldLayouts.e3587594-ffc4-4e9d-bffd-8a3e848cf461.tabs.0.elements.0.requirable','false'),('volumes.a0cd8b19-e1b7-4968-86c8-25f1345172a0.fieldLayouts.e3587594-ffc4-4e9d-bffd-8a3e848cf461.tabs.0.elements.0.size','null'),('volumes.a0cd8b19-e1b7-4968-86c8-25f1345172a0.fieldLayouts.e3587594-ffc4-4e9d-bffd-8a3e848cf461.tabs.0.elements.0.step','null'),('volumes.a0cd8b19-e1b7-4968-86c8-25f1345172a0.fieldLayouts.e3587594-ffc4-4e9d-bffd-8a3e848cf461.tabs.0.elements.0.tip','null'),('volumes.a0cd8b19-e1b7-4968-86c8-25f1345172a0.fieldLayouts.e3587594-ffc4-4e9d-bffd-8a3e848cf461.tabs.0.elements.0.title','null'),('volumes.a0cd8b19-e1b7-4968-86c8-25f1345172a0.fieldLayouts.e3587594-ffc4-4e9d-bffd-8a3e848cf461.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\"'),('volumes.a0cd8b19-e1b7-4968-86c8-25f1345172a0.fieldLayouts.e3587594-ffc4-4e9d-bffd-8a3e848cf461.tabs.0.elements.0.uid','\"e1af96a8-8fa8-4ac6-ac6a-fbf57459099f\"'),('volumes.a0cd8b19-e1b7-4968-86c8-25f1345172a0.fieldLayouts.e3587594-ffc4-4e9d-bffd-8a3e848cf461.tabs.0.elements.0.userCondition','null'),('volumes.a0cd8b19-e1b7-4968-86c8-25f1345172a0.fieldLayouts.e3587594-ffc4-4e9d-bffd-8a3e848cf461.tabs.0.elements.0.warning','null'),('volumes.a0cd8b19-e1b7-4968-86c8-25f1345172a0.fieldLayouts.e3587594-ffc4-4e9d-bffd-8a3e848cf461.tabs.0.elements.0.width','100'),('volumes.a0cd8b19-e1b7-4968-86c8-25f1345172a0.fieldLayouts.e3587594-ffc4-4e9d-bffd-8a3e848cf461.tabs.0.name','\"Content\"'),('volumes.a0cd8b19-e1b7-4968-86c8-25f1345172a0.fieldLayouts.e3587594-ffc4-4e9d-bffd-8a3e848cf461.tabs.0.uid','\"b1aa57b7-fd1f-4432-9b4e-1d0a125a6ced\"'),('volumes.a0cd8b19-e1b7-4968-86c8-25f1345172a0.fieldLayouts.e3587594-ffc4-4e9d-bffd-8a3e848cf461.tabs.0.userCondition','null'),('volumes.a0cd8b19-e1b7-4968-86c8-25f1345172a0.fs','\"drinks\"'),('volumes.a0cd8b19-e1b7-4968-86c8-25f1345172a0.handle','\"drinks\"'),('volumes.a0cd8b19-e1b7-4968-86c8-25f1345172a0.name','\"drinks\"'),('volumes.a0cd8b19-e1b7-4968-86c8-25f1345172a0.sortOrder','2'),('volumes.a0cd8b19-e1b7-4968-86c8-25f1345172a0.titleTranslationKeyFormat','null'),('volumes.a0cd8b19-e1b7-4968-86c8-25f1345172a0.titleTranslationMethod','\"site\"'),('volumes.a0cd8b19-e1b7-4968-86c8-25f1345172a0.transformFs','\"\"'),('volumes.a0cd8b19-e1b7-4968-86c8-25f1345172a0.transformSubpath','\"\"');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `queue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int NOT NULL,
  `ttr` int NOT NULL,
  `delay` int NOT NULL DEFAULT '0',
  `priority` int unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int DEFAULT NULL,
  `progress` smallint NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `idx_tszjuqnjbgpxafxrkfhcfaqvbhzozavuzuyw` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_vgqtqxsbfageaigztkutajkozezbvlwpldgu` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=689 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `relations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `sourceId` int NOT NULL,
  `sourceSiteId` int DEFAULT NULL,
  `targetId` int NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_izrbxzxjyvswekxkuvnleljecvsfbphriasw` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_mveaklyzxuupyqfiggrykhqhzjczkeosdotd` (`sourceId`),
  KEY `idx_fpfzuphxaajwfvfhvaorktsueqkuollfrbll` (`targetId`),
  KEY `idx_ikvuzyqwikbyhazsrislihyjeardafzfhfzy` (`sourceSiteId`),
  CONSTRAINT `fk_ifblorspwnlnnjkngrshdvnamwnrdkeysmsq` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rfowqkxrgmsjelnireswgorpixljulkemgoa` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tcofsdhelfvqgwfvslkpghuhfddlojufliwl` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
INSERT INTO `relations` VALUES (2,14,117,NULL,170,1,'2024-01-06 00:07:35','2024-01-06 00:07:35','2a6a4b2b-f29a-42c1-93b6-adf486664dec'),(3,14,174,NULL,170,1,'2024-01-06 00:07:35','2024-01-06 00:07:35','dc1a2ad1-2157-4018-a054-5d438267abca'),(5,14,113,NULL,143,1,'2024-01-06 00:07:45','2024-01-06 00:07:45','d06406f3-c928-4315-a2a0-9f24344ac5ee'),(6,14,176,NULL,143,1,'2024-01-06 00:07:45','2024-01-06 00:07:45','63342cb2-d609-40f1-8ba7-ad20da68582c'),(8,14,111,NULL,172,1,'2024-01-06 00:08:00','2024-01-06 00:08:00','1eb0a54c-2ddb-46ad-b882-c07abead7028'),(9,14,178,NULL,172,1,'2024-01-06 00:08:00','2024-01-06 00:08:00','ee552212-0549-4b16-9345-91f7a90c0d8b'),(11,14,102,NULL,171,1,'2024-01-06 00:08:10','2024-01-06 00:08:10','44e1b480-ee3d-413d-a3d5-044d742850b4'),(12,14,180,NULL,171,1,'2024-01-06 00:08:10','2024-01-06 00:08:10','aecdb084-d635-42f4-87e1-39e565081c30'),(14,14,94,NULL,169,1,'2024-01-06 00:08:21','2024-01-06 00:08:21','c6463108-41c5-4f97-ad5f-929d4aaa77dd'),(15,14,182,NULL,169,1,'2024-01-06 00:08:21','2024-01-06 00:08:21','9139d46d-40b5-4da6-b8ee-ec4922ae4825'),(18,14,92,NULL,173,1,'2024-01-06 00:08:43','2024-01-06 00:08:43','50ef21df-1199-4749-8220-41598ca610f7'),(19,14,184,NULL,173,1,'2024-01-06 00:08:43','2024-01-06 00:08:43','49c137c6-a503-438d-8227-be62a73b1af2'),(21,14,196,NULL,170,1,'2024-01-06 16:51:36','2024-01-06 16:51:36','10f57d48-e9c1-4b18-a381-a7b5d6886fa7'),(24,15,117,NULL,203,1,'2024-01-10 22:12:43','2024-01-10 22:12:43','7525051d-e664-43e2-a734-94ec59089262'),(25,15,208,NULL,203,1,'2024-01-10 22:12:43','2024-01-10 22:12:43','2d0c7afa-9455-4808-b428-a7b95527e828'),(26,14,208,NULL,170,1,'2024-01-10 22:12:43','2024-01-10 22:12:43','6f4eacdd-460b-4893-8d24-06a29abd036f'),(29,15,113,NULL,203,1,'2024-01-10 22:12:57','2024-01-10 22:12:57','05aa4a99-de8f-4370-bb0d-9d94f9fed415'),(30,15,210,NULL,203,1,'2024-01-10 22:12:57','2024-01-10 22:12:57','d5b8dadf-f5b1-4ad1-b452-5cfad67f01e5'),(31,14,210,NULL,143,1,'2024-01-10 22:12:57','2024-01-10 22:12:57','6ba08d3d-ceab-4923-9351-1b22e437d307'),(34,15,111,NULL,201,1,'2024-01-10 22:13:09','2024-01-10 22:13:09','84a3a60a-728f-4a2c-8e5a-f29f68c5806b'),(35,15,212,NULL,201,1,'2024-01-10 22:13:09','2024-01-10 22:13:09','794e217d-1844-4419-9bd8-0daf3d9ffb41'),(36,14,212,NULL,172,1,'2024-01-10 22:13:09','2024-01-10 22:13:09','fda75c66-dd3f-47e2-a62c-280d404b8422'),(39,15,102,NULL,201,1,'2024-01-10 22:13:23','2024-01-10 22:13:23','00fb239e-ce5b-4511-a27b-5ab2a8516db4'),(40,15,214,NULL,201,1,'2024-01-10 22:13:23','2024-01-10 22:13:23','7dd17493-38eb-444a-84cd-52b6c6d349af'),(41,14,214,NULL,171,1,'2024-01-10 22:13:23','2024-01-10 22:13:23','cae41df9-7a54-4912-a477-9c56d5b30214'),(44,15,94,NULL,201,1,'2024-01-10 22:13:37','2024-01-10 22:13:37','5d1c6a34-d33f-4823-bbbe-a544d447bc7f'),(45,15,216,NULL,201,1,'2024-01-10 22:13:37','2024-01-10 22:13:37','d3a0b46b-ea1d-40f1-a95a-7ea7a67ab77f'),(46,14,216,NULL,169,1,'2024-01-10 22:13:37','2024-01-10 22:13:37','eed2d05b-03d1-4978-8fe2-0072e16a2b90'),(49,15,92,NULL,201,1,'2024-01-10 22:13:51','2024-01-10 22:13:51','361099f1-3f08-41af-b9c4-aa936808c24f'),(50,15,218,NULL,201,1,'2024-01-10 22:13:51','2024-01-10 22:13:51','0cedadb3-455a-4e86-b8bc-9704d10ba146'),(51,14,218,NULL,173,1,'2024-01-10 22:13:51','2024-01-10 22:13:51','68c4cc49-117c-45c2-a938-13b7674569b4'),(52,15,219,NULL,203,1,'2024-01-10 22:50:58','2024-01-10 22:50:58','c91ff03c-7255-4e4e-a7bc-eb13f11c4536'),(53,14,219,NULL,170,1,'2024-01-10 22:50:58','2024-01-10 22:50:58','eda41311-858c-4222-bb69-cbf82af5e207'),(54,15,220,NULL,201,1,'2024-01-11 16:54:20','2024-01-11 16:54:20','ae80c188-1663-4ceb-82b6-33d70275e31a'),(55,14,220,NULL,172,1,'2024-01-11 16:54:20','2024-01-11 16:54:20','75d2a0c3-afec-40a4-ba43-7dd168b30419'),(56,15,221,NULL,201,1,'2024-01-11 16:54:20','2024-01-11 16:54:20','8d871e7a-e559-47b0-a810-dd6310a579d4'),(57,14,221,NULL,172,1,'2024-01-11 16:54:20','2024-01-11 16:54:20','bb890bbc-f108-4332-b792-51a81c670fdb'),(60,15,223,NULL,201,1,'2024-01-11 16:56:51','2024-01-11 16:56:51','8bd7e6f3-1579-49fc-8d7b-a4f1992baa61'),(61,14,223,NULL,172,1,'2024-01-11 16:56:51','2024-01-11 16:56:51','1235dea3-4190-4a84-90a1-6f2454ea57e4'),(64,15,225,NULL,201,1,'2024-01-11 16:57:22','2024-01-11 16:57:22','f85184f8-d6ee-4d82-aa63-f99a36e2ec3d'),(65,14,225,NULL,171,1,'2024-01-11 16:57:22','2024-01-11 16:57:22','30eacacf-092c-4a04-ab31-6a4f352468e7'),(68,15,227,NULL,201,1,'2024-01-11 16:57:38','2024-01-11 16:57:38','006d1bf3-5b2a-44a2-80fc-1a945ebcc46f'),(69,14,227,NULL,169,1,'2024-01-11 16:57:38','2024-01-11 16:57:38','eb1aba03-dd46-4843-a22e-16f75f001637'),(72,15,229,NULL,201,1,'2024-01-11 16:57:59','2024-01-11 16:57:59','03161829-7159-4fc6-9b3e-9f71a4154340'),(73,14,229,NULL,173,1,'2024-01-11 16:57:59','2024-01-11 16:57:59','a8d05764-ba66-4db2-afe4-59486813427c');
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resourcepaths`
--

LOCK TABLES `resourcepaths` WRITE;
/*!40000 ALTER TABLE `resourcepaths` DISABLE KEYS */;
INSERT INTO `resourcepaths` VALUES ('11dfc373','@craft/web/assets/craftsupport/dist'),('11f7fb8b','@craft/web/assets/xregexp/dist'),('13932c4f','@craft/web/assets/craftsupport/dist'),('13bb14b7','@craft/web/assets/xregexp/dist'),('153db637','@craft/web/assets/timepicker/dist'),('16b26a1a','@adigital/cookieconsentbanner/assetbundles/cookieconsentbanner/dist'),('1803a9b7','@craft/web/assets/picturefill/dist'),('19d974be','@craft/web/assets/login/dist'),('1a4f468b','@craft/web/assets/picturefill/dist'),('1b959b82','@craft/web/assets/login/dist'),('21cf71de','@craft/web/assets/velocity/dist'),('23839ee2','@craft/web/assets/velocity/dist'),('240bac0b','@craft/web/assets/jquerytouchevents/dist'),('24587369','@craft/web/assets/jquerypayment/dist'),('26149c55','@craft/web/assets/jquerypayment/dist'),('26474337','@craft/web/assets/jquerytouchevents/dist'),('281f1592','@craft/web/assets/datepickeri18n/dist'),('2a53faae','@craft/web/assets/datepickeri18n/dist'),('2c86110b','@craft/web/assets/feed/dist'),('2c89f2b0','@craft/web/assets/edittransform/dist'),('2ecafe37','@craft/web/assets/feed/dist'),('35efa985','@craft/web/assets/vue/dist'),('37a346b9','@craft/web/assets/vue/dist'),('37fbb6e6','@craft/web/assets/editsection/dist'),('4113b54f','@craft/web/assets/htmx/dist'),('549f29ae','@craft/redactor/assets/redactor/dist'),('55c537c0','@craft/web/assets/dashboard/dist'),('5789d8fc','@craft/web/assets/dashboard/dist'),('6177d64e','@vendor/tinymce/tinymce'),('64267120','@craft/web/assets/fileupload/dist'),('666a9e1c','@craft/web/assets/fileupload/dist'),('6c146896','@craft/web/assets/updates/dist'),('6e5887aa','@craft/web/assets/updates/dist'),('6fae5249','@craft/web/assets/prismjs/dist'),('70ba379d','@bower/jquery/dist'),('72f6d8a1','@bower/jquery/dist'),('755a2875','@craft/web/assets/elementresizedetector/dist'),('7716c749','@craft/web/assets/elementresizedetector/dist'),('781148b7','@craft/web/assets/jqueryui/dist'),('7a5da78b','@craft/web/assets/jqueryui/dist'),('810a314b','@craft/web/assets/updater/dist'),('8346de77','@craft/web/assets/updater/dist'),('88c97714','@craft/web/assets/recententries/dist'),('8902f07c','@craft/web/assets/conditionbuilder/dist'),('8a859828','@craft/web/assets/recententries/dist'),('903ce24d','@craft/web/assets/axios/dist'),('92700d71','@craft/web/assets/axios/dist'),('93235d13','@abmat/tinymce/assets/field/dist'),('9d62a4f5','@config/tinymce/resources'),('a0454ea3','@craft/web/assets/selectize/dist'),('a171b73d','@craft/web/assets/installer/dist'),('a209a19f','@craft/web/assets/selectize/dist'),('a51c1bbd','@craft/web/assets/tailwindreset/dist'),('a576dc96','@craft/web/assets/pluginstore/dist'),('a73a33aa','@craft/web/assets/pluginstore/dist'),('a750f481','@craft/web/assets/tailwindreset/dist'),('ac0deceb','@craft/web/assets/cp/dist'),('ae4103d7','@craft/web/assets/cp/dist'),('b43fda46','@craft/web/assets/updateswidget/dist'),('b474259e','@craft/web/assets/d3/dist'),('b638caa2','@craft/web/assets/d3/dist'),('b673357a','@craft/web/assets/updateswidget/dist'),('b97cf91f','@craft/web/assets/fieldsettings/dist'),('bd108e1d','@craft/web/assets/generalsettings/dist'),('bd59c315','@craft/web/assets/iframeresizer/dist'),('bf152c29','@craft/web/assets/iframeresizer/dist'),('c1930237','@craft/redactor/assets/field/dist'),('cc2b9a34','@craft/web/assets/garnish/dist'),('ce677508','@craft/web/assets/garnish/dist'),('d48b211e','@craft/web/assets/fields/dist'),('dda5d9cb','@craft/web/assets/admintable/dist'),('e499ad23','@craft/web/assets/fabric/dist'),('e6d5421f','@craft/web/assets/fabric/dist'),('f4b33b1d','@craft/web/assets/utilities/dist'),('f6ffd421','@craft/web/assets/utilities/dist');
/*!40000 ALTER TABLE `resourcepaths` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `revisions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int NOT NULL,
  `creatorId` int DEFAULT NULL,
  `num` int NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_mxaoxiauwvyqmzjurbqvdwggofjxpmrmybfo` (`canonicalId`,`num`),
  KEY `fk_uufuhrgwswtmyticpypsmmkukzkxufqhuyhh` (`creatorId`),
  CONSTRAINT `fk_iuasasjhfnsufypnmmhakllsfgbamwycuolp` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uufuhrgwswtmyticpypsmmkukzkxufqhuyhh` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=129 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
INSERT INTO `revisions` VALUES (1,3,1,1,NULL),(2,3,1,2,NULL),(3,3,1,3,NULL),(4,3,1,4,NULL),(5,3,1,5,NULL),(6,3,1,6,NULL),(7,3,1,7,NULL),(8,3,1,8,NULL),(9,3,1,9,NULL),(10,3,1,10,NULL),(11,3,1,11,NULL),(17,16,1,6,NULL),(18,16,1,7,NULL),(19,16,1,8,'Applied “Draft 1”'),(20,16,1,9,''),(21,16,1,10,'Applied “Draft 1”'),(22,16,1,11,''),(23,16,1,12,'Applied “Draft 1”'),(24,16,1,13,'Applied “Draft 1”'),(25,16,1,14,''),(26,16,1,15,'Applied “Draft 1”'),(27,16,1,16,''),(28,16,1,17,''),(29,16,1,18,''),(30,16,1,19,''),(31,16,1,20,''),(32,16,1,21,''),(33,16,1,22,''),(34,16,1,23,''),(35,16,1,24,'Applied “Draft 1”'),(36,16,1,25,'Applied “Draft 1”'),(37,16,1,26,'Applied “Draft 1”'),(38,16,1,27,''),(39,16,1,28,'Applied “Draft 1”'),(40,16,1,29,NULL),(41,16,1,30,'Applied “Draft 1”'),(42,16,1,31,'Applied “Draft 1”'),(43,16,1,32,''),(44,16,1,33,'Applied “Draft 1”'),(45,16,1,34,'Applied “Draft 1”'),(46,16,1,35,'Applied “Draft 1”'),(47,16,1,36,''),(48,16,1,37,'Applied “Draft 1”'),(49,16,1,38,''),(50,16,1,39,'Applied “Draft 1”'),(51,16,1,40,'Applied “Draft 1”'),(52,16,1,41,'Applied “Draft 1”'),(53,16,1,42,'Applied “Draft 1”'),(54,16,1,43,''),(55,16,1,44,'Applied “Draft 1”'),(56,16,1,45,'Applied “Draft 1”'),(57,92,1,1,''),(58,94,1,1,''),(59,94,1,2,'Applied “Draft 1”'),(60,92,1,2,'Applied “Draft 1”'),(61,94,1,3,'Applied “Draft 1”'),(62,102,1,1,''),(63,102,1,2,'Applied “Draft 1”'),(64,94,1,4,''),(65,92,1,3,''),(66,94,1,5,''),(67,111,1,1,''),(68,113,1,1,''),(69,113,1,2,'Applied “Draft 1”'),(70,117,1,1,''),(71,111,1,2,'Applied “Draft 1”'),(72,111,1,3,''),(73,102,1,3,'Applied “Draft 1”'),(74,92,1,4,'Applied “Draft 1”'),(75,102,1,4,''),(76,92,1,5,''),(77,111,1,4,''),(78,102,1,5,''),(79,94,1,6,'Applied “Draft 1”'),(80,117,1,2,''),(81,117,1,3,'Applied “Draft 1”'),(82,134,1,1,NULL),(83,16,1,46,NULL),(84,16,1,47,NULL),(85,16,1,48,NULL),(86,16,1,49,NULL),(87,16,1,50,NULL),(88,16,1,51,NULL),(89,3,1,12,NULL),(90,3,1,13,'Applied “Draft 1”'),(91,3,1,14,NULL),(92,3,1,15,'Applied “Draft 1”'),(93,3,1,16,''),(94,3,1,17,NULL),(95,3,1,18,NULL),(96,3,1,19,'Applied “Draft 1”'),(97,3,1,20,'Applied “Draft 1”'),(98,16,1,52,''),(99,3,1,21,'Applied “Draft 1”'),(100,3,1,22,'Applied “Draft 1”'),(101,16,1,53,''),(102,3,1,23,'Applied “Draft 1”'),(103,16,1,54,''),(104,3,1,24,'Applied “Draft 1”'),(105,117,1,4,'Applied “Draft 1”'),(106,113,1,3,'Applied “Draft 1”'),(107,111,1,5,'Applied “Draft 1”'),(108,102,1,6,'Applied “Draft 1”'),(109,94,1,7,'Applied “Draft 1”'),(110,92,1,6,'Applied “Draft 1”'),(111,117,1,5,''),(112,16,1,55,NULL),(113,3,1,25,NULL),(114,201,1,1,''),(115,203,1,1,''),(116,203,1,2,'Applied “Draft 1”'),(117,117,1,6,'Applied “Draft 1”'),(118,113,1,4,'Applied “Draft 1”'),(119,111,1,6,'Applied “Draft 1”'),(120,102,1,7,'Applied “Draft 1”'),(121,94,1,8,'Applied “Draft 1”'),(122,92,1,7,'Applied “Draft 1”'),(123,117,1,7,''),(124,220,1,1,NULL),(125,111,1,7,'Applied “Draft 1”'),(126,102,1,8,'Applied “Draft 1”'),(127,94,1,9,'Applied “Draft 1”'),(128,92,1,8,'Applied “Draft 1”');
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindex` (
  `elementId` int NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int NOT NULL,
  `siteId` int NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_dsakfpfatovwohnhnqxqjfjlntpykejenxio` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
INSERT INTO `searchindex` VALUES (1,'email',0,1,' r0906880 student thomasmore be '),(1,'firstname',0,1,''),(1,'fullname',0,1,''),(1,'lastname',0,1,''),(1,'slug',0,1,''),(1,'username',0,1,' admin '),(2,'slug',0,1,' temp yccfmnohgbxsdxixrndefrewcwqzcygtijop '),(2,'title',0,1,''),(3,'slug',0,1,' about us '),(3,'title',0,1,' about us '),(6,'slug',0,1,' temp ukrlfiddpssvoadhelohcilswohdsgzrcnhi '),(6,'title',0,1,''),(16,'slug',0,1,' home '),(16,'title',0,1,' home '),(92,'slug',0,1,' smirnoff vodka '),(92,'title',0,1,' smirnoff vodka '),(94,'slug',0,1,' absolut vodka '),(94,'title',0,1,' absolut vodka '),(102,'slug',0,1,' jack daniels '),(102,'title',0,1,' jack daniels '),(111,'slug',0,1,' the famous grouse '),(111,'title',0,1,' the famous grouse '),(113,'slug',0,1,' coca cola '),(113,'title',0,1,' coca cola '),(117,'slug',0,1,' fanta blueberry 12 '),(117,'title',0,1,' fanta blueberry 12 '),(134,'slug',0,1,' the famous grouse 2 '),(134,'title',0,1,' the famous grouse '),(143,'alt',0,1,''),(143,'extension',0,1,' jpg '),(143,'filename',0,1,' coca cola jpg '),(143,'kind',0,1,' image '),(143,'slug',0,1,''),(143,'title',0,1,' coca cola '),(169,'alt',0,1,''),(169,'extension',0,1,' webp '),(169,'filename',0,1,' absolut vodka webp '),(169,'kind',0,1,' image '),(169,'slug',0,1,''),(169,'title',0,1,' absolut vodka '),(170,'alt',0,1,''),(170,'extension',0,1,' jpg '),(170,'filename',0,1,' fanta bb jpg '),(170,'kind',0,1,' image '),(170,'slug',0,1,''),(170,'title',0,1,' fanta bb '),(171,'alt',0,1,''),(171,'extension',0,1,' webp '),(171,'filename',0,1,' jack daniels webp '),(171,'kind',0,1,' image '),(171,'slug',0,1,''),(171,'title',0,1,' jack daniels '),(172,'alt',0,1,''),(172,'extension',0,1,' webp '),(172,'filename',0,1,' the famous grouse webp '),(172,'kind',0,1,' image '),(172,'slug',0,1,''),(172,'title',0,1,' the famous grouse '),(173,'alt',0,1,''),(173,'extension',0,1,' webp '),(173,'filename',0,1,' smirnof vodka webp '),(173,'kind',0,1,' image '),(173,'slug',0,1,''),(173,'title',0,1,' smirnof vodka '),(185,'alt',0,1,''),(185,'extension',0,1,' jpg '),(185,'filename',0,1,' about frontpage jpg '),(185,'kind',0,1,' image '),(185,'slug',0,1,''),(185,'title',0,1,' about frontpage '),(186,'alt',0,1,''),(186,'extension',0,1,' png '),(186,'filename',0,1,' apperitief png '),(186,'kind',0,1,' image '),(186,'slug',0,1,''),(186,'title',0,1,' apperitief '),(187,'alt',0,1,''),(187,'extension',0,1,' jpg '),(187,'filename',0,1,' assortiment jpg '),(187,'kind',0,1,' image '),(187,'slug',0,1,''),(187,'title',0,1,' assortiment '),(188,'alt',0,1,''),(188,'extension',0,1,' jpg '),(188,'filename',0,1,' bottle jack jpg '),(188,'kind',0,1,' image '),(188,'slug',0,1,''),(188,'title',0,1,' bottle jack '),(189,'alt',0,1,''),(189,'extension',0,1,' jpg '),(189,'filename',0,1,' drinking orange jpg '),(189,'kind',0,1,' image '),(189,'slug',0,1,''),(189,'title',0,1,' drinking orange '),(190,'alt',0,1,''),(190,'extension',0,1,' png '),(190,'filename',0,1,' tvgd logo png '),(190,'kind',0,1,' image '),(190,'slug',0,1,''),(190,'title',0,1,' tvgd logo '),(191,'alt',0,1,''),(191,'extension',0,1,' avif '),(191,'filename',0,1,' led us her avif '),(191,'kind',0,1,' image '),(191,'slug',0,1,''),(191,'title',0,1,' led us her '),(192,'alt',0,1,''),(192,'extension',0,1,' jpg '),(192,'filename',0,1,' ons verhaal jpg '),(192,'kind',0,1,' image '),(192,'slug',0,1,''),(192,'title',0,1,' ons verhaal '),(193,'alt',0,1,''),(193,'extension',0,1,' avif '),(193,'filename',0,1,' vereniging avif '),(193,'kind',0,1,' image '),(193,'slug',0,1,''),(193,'title',0,1,' vereniging '),(194,'alt',0,1,''),(194,'extension',0,1,' jpg '),(194,'filename',0,1,' about frontpage jpg '),(194,'kind',0,1,' image '),(194,'slug',0,1,''),(194,'title',0,1,' about frontpage '),(199,'alt',0,1,''),(199,'extension',0,1,' jpg '),(199,'filename',0,1,' passion led us here jpg '),(199,'kind',0,1,' image '),(199,'slug',0,1,''),(199,'title',0,1,' passion led us here '),(200,'alt',0,1,''),(200,'extension',0,1,' jpg '),(200,'filename',0,1,' ons vereniging jpg '),(200,'kind',0,1,' image '),(200,'slug',0,1,''),(200,'title',0,1,' ons vereniging '),(201,'slug',0,1,' drinks '),(201,'title',0,1,' drinks '),(203,'slug',0,1,' nonalcolische '),(203,'title',0,1,' nadrinks '),(220,'slug',0,1,' the famous grouse 2 '),(220,'title',0,1,' the famous grouse ');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vhkcyocvefmqyldtkgngpqmxtezihzeyhvgp` (`handle`),
  KEY `idx_royaqmgltuxdrmfqevbplahyohzrfrbcqjdk` (`name`),
  KEY `idx_kmtrqgxetdvpqcbhrqrzyocdjqhirkglbdem` (`structureId`),
  KEY `idx_ejcvqrmfdrfhvgzisaggtgydnyiqmbhxeatu` (`dateDeleted`),
  CONSTRAINT `fk_vwdnloycilgmqmefwqjcpwpouzsellcxedfc` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` VALUES (1,NULL,'drinks','drinks','channel',1,'all','end',NULL,'2024-01-05 15:13:17','2024-01-06 16:18:00',NULL,'4e90476a-1613-447e-9942-30d691eec5b1'),(2,NULL,'About us','aboutUs','single',1,'all','end',NULL,'2024-01-05 15:47:11','2024-01-05 17:07:36',NULL,'c0d44cc8-1c83-47d4-9b83-9ba94e0224dc'),(3,NULL,'Alcohol','alcohol','channel',1,'all','end',NULL,'2024-01-05 17:14:11','2024-01-05 17:14:11','2024-01-05 17:38:01','87403ad2-349f-4e36-983e-4c823e331824'),(4,NULL,'home','home','single',1,'all','end',NULL,'2024-01-05 17:43:07','2024-01-05 22:38:56',NULL,'b4927f39-21eb-487f-9819-47b121ed4ca8'),(5,1,'drink','drink','structure',1,'all','end',NULL,'2024-01-05 21:36:57','2024-01-05 21:36:57','2024-01-05 21:37:18','9c567da1-2250-490c-a601-eb0f7253f727'),(6,3,'drinks_entry','drinksEntry','structure',1,'all','end',NULL,'2024-01-06 15:29:25','2024-01-06 15:29:25','2024-01-06 15:29:36','1af57166-c1ce-4773-b690-267855687c29'),(7,4,'filters','filters','structure',1,'all','end',NULL,'2024-01-06 18:03:43','2024-01-06 18:04:00','2024-01-06 18:05:32','6eec36ff-e385-4101-b316-5b071a19b3a8'),(8,5,'Store Categories','storeCategories','structure',1,'all','end',NULL,'2024-01-10 22:00:06','2024-01-10 22:03:40',NULL,'18e745c4-9c85-4f4c-9219-09e2ba15599c');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_mefcektarmnreukasordvgtxlknkfczuqquh` (`sectionId`,`siteId`),
  KEY `idx_jhlldcyjsonozazrenyaotxrlywgnajkiuep` (`siteId`),
  CONSTRAINT `fk_igknguexlcwvgjzlobzbkmstbfuzpruvfnym` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_jmjfbujkazwjdcsuvtwfasazwrdhcdatskne` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
INSERT INTO `sections_sites` VALUES (1,1,1,1,'drinks/{slug}','drinks/_entry',1,'2024-01-05 15:13:17','2024-01-06 16:20:59','0c0098f8-d069-4e67-aeb3-53850ed9c0f9'),(2,2,1,1,'aboutUs/{slug}','aboutUs/_entry.twig',1,'2024-01-05 15:47:11','2024-01-05 17:09:15','86009f9b-7e1a-4c6e-a64d-b368046fd3d6'),(3,3,1,1,'alcohol/{slug}','alcohol/_entry',1,'2024-01-05 17:14:11','2024-01-05 17:14:11','9d998601-4fd2-4925-8fa5-c252df36d998'),(4,4,1,1,'__home__',NULL,1,'2024-01-05 17:43:07','2024-01-05 22:38:35','49796cb3-72c1-46f5-9d1c-8d8f28e0ee3b'),(5,5,1,1,'drink/{slug}','drink/_entry',1,'2024-01-05 21:36:57','2024-01-05 21:36:57','5169ba82-bae9-4c64-be78-dca44a62f7a9'),(6,6,1,1,'drinks-entry/{slug}','drinks-entry/_entry',1,'2024-01-06 15:29:25','2024-01-06 15:29:25','eceb80eb-5bce-46d6-9f3c-0eb66768382d'),(7,7,1,1,'filters/{slug}','filters/_entry',1,'2024-01-06 18:03:43','2024-01-06 18:03:43','8fb23116-8168-4a71-919d-e111ac5fc6de'),(8,8,1,1,'store-categories/{slug}','store-categories/_entry',1,'2024-01-10 22:00:06','2024-01-10 22:03:40','b895f0db-ba70-4c62-90dc-8e02e42cfc08');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_utynmbqxzhnamirurrkmpunvdklyuducwosp` (`uid`),
  KEY `idx_mdtifqpetngxdmsbdaycwzbnpuhbrqurogge` (`token`),
  KEY `idx_hjaqyqujkxxtwxumgiygemaqvjoazrhrfodz` (`dateUpdated`),
  KEY `idx_hqpirtbaieedpddnnqjnaeyircterguzdlhx` (`userId`),
  CONSTRAINT `fk_frznadesapygbjasfryjxbnieofqqmedmxov` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES (2,1,'YFrIqsUNTL9uoFZ5lI_A3puYx64baGpyhf5XX-PlAy14SnTu7rMeMuHhVtkiEUcbGxZoBnsWJNXIUWiA5N13ySlgp_GJiANwxp_W','2024-01-04 15:46:14','2024-01-04 16:15:21','6d81ad60-393a-4ffd-8da6-26ef69253818'),(4,1,'R7mfWZPVmGXwCvlN-qTcjgAdESkwAFhGZ3Dr-9q_FiT2SPtUDtN5L3TxFtcob3qbNJDcDl9wgcBQ6WMJXFOJc6BcvQRq51lYHYJD','2024-01-04 20:50:29','2024-01-04 22:26:52','436144ba-0d1d-4ba0-8246-d25fd7c503be'),(5,1,'5y_5dgswvVS37YNfXbDbiYYHks2eHLgm7LBSEae1NNDu5tQvyVPRSOb7ZtjX3p6SMODOZdTdJ8tAwJOH8uaycKOlvWTIGHGdFFwF','2024-01-05 15:06:04','2024-01-05 16:25:42','a821f07e-3664-4e76-897d-9b8f424e248b'),(6,1,'9mg2sA9nOSKwbgqeicaF8qm-LWb4VppPKpCsm1ATa0Maz02fM79_p1aKD18-tE64GP5eUO4dZY8Bm92DhPQ5jTyOeBsxfoNP56fZ','2024-01-05 16:25:42','2024-01-05 18:27:02','513191dc-7188-4b48-9abe-a04c28e058cd'),(8,1,'l7xFPp4RSEeMXi1tGsLsISjEkEoygKGfYWLNoXt2WcFlSMz9wZnF1ml_AyWSYlGZcpKIt2XNCOIEDlxKV1s_FL7Noi9mBZDTd-tA','2024-01-05 21:34:04','2024-01-05 23:06:24','d9b09d4b-86a3-4266-a652-6b1fa9de3d70'),(9,1,'QaPJGRoOS1zDnOeYHtPunMd7kXuMqxcQLUyLupBjL7wC7q9eHX-TAAYwRtgGjIHkcHNaqYuv-leyptmDmMOxSGESRqyuHwLOqN7_','2024-01-05 23:06:24','2024-01-06 01:22:09','bb5f315f-ee71-4f2a-b530-8e03c07c1e7a'),(10,1,'6Hbis_CzPiw7zjpmu4d6UatcAbaDB59UisGlceS9OiS6gZ-9g0iC8KdOu5yFGZrYdRQsRnkeVsq2D2LLAmWvoCH54jvyqEngI_vi','2024-01-06 15:27:40','2024-01-06 16:59:02','43e780cd-da98-4cdd-90b9-2b6e144b86f4'),(11,1,'o8p_1KCQt4o0HWn1kvfVip372p8pTxaPe9FEJ23AmKIaUth_2hCf9WnpNiaJjmWdjsgJUvdudJMOlYwKY9mN1wqtJR4wLWqUTc5W','2024-01-06 17:17:48','2024-01-06 18:25:56','6edc981b-184d-412c-807e-2c2d96393c92'),(12,1,'2q_EMe7TcZEiRgEkRHPhBNFySwiAu2GKshrENjLCJWS_9Vh40oyx_h3EaCmIw_vNVvHEzJIxPDC11I3rzMX1ajM1j0xAgJpwXFGC','2024-01-06 18:25:56','2024-01-06 19:43:10','f0990e35-9706-4a96-96f5-b735335fdeec'),(13,1,'yR6GXIQNp0tSDn3f3Kk0UfbxTraoSRKJC3Xsc75AfsoOOaB8ZJYQ8VkQPD3YxJdUiSTuVEpiqWs4f397jvdGnyExtqsdFAz3arZ-','2024-01-10 20:49:14','2024-01-10 23:52:21','550d1ebe-319b-46c0-9df9-b461e35b224a'),(14,1,'CfxmOLspR_1bIMYGO_-kWRFLQm5tI1t0l5SHYUVcbFf4IUcoeR5wnSQIKz2jMsrBp6jUtzvZk8UVf081wgZeEEN3gVCnIOJCilE_','2024-01-11 15:02:17','2024-01-11 15:08:53','a8409f0b-3f98-4b8e-9666-f48b4c8306ff'),(15,1,'mQiy_gYhM6FsLMrtJ7pg8xLwJ5hwRPr5i9DKiLKkLkD1Jz4wWrHvHEqYgVevBCOW3mb8HnnyFven07bbOd0pdnPdM9_RVZmvmGMf','2024-01-11 16:52:06','2024-01-11 18:40:50','0bb22b8b-2c24-4cbc-b56b-b064f02e81ee'),(16,1,'UVJ8XAKoRalKKdXZReWWKmG4LQhJyyOBtphCyXclNOpLtmTGGrC9rmlV31XT4ikq89o71fhWyIDAUUo_dJ9X7VVL7wagB3zlMCQT','2024-01-11 18:40:50','2024-01-11 18:40:51','5b2ea79f-1d13-43e1-911a-cc757440c75f');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shunnedmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ysesalfodadecgkkohnzqmmrcsdrqevymljv` (`userId`,`message`),
  CONSTRAINT `fk_loigtjtmvxbysrcpljbtoytplhaxiqdthoaj` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sitegroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vlgwuwiegkpftlwqvofetnrgalfaadhyfzxv` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
INSERT INTO `sitegroups` VALUES (1,'Drank Webshop','2023-12-26 19:45:34','2023-12-26 19:45:34',NULL,'a3ea80b4-e1b2-40ba-9389-ad406905a942');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(12) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_sylvlgujjspvunlryphrwbtqsrlpaiuwydcu` (`dateDeleted`),
  KEY `idx_japqoxrxjmzggugdvjwxcgglnewszoorczwp` (`handle`),
  KEY `idx_odjcdsrbyvgbbemlarntevlvkilqtokikkoh` (`sortOrder`),
  KEY `fk_ywbbghpszwvnufwapirlaolsmcellmpoazqc` (`groupId`),
  CONSTRAINT `fk_ywbbghpszwvnufwapirlaolsmcellmpoazqc` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
INSERT INTO `sites` VALUES (1,1,1,'true','Drank Webshop','default','en-US',1,'$PRIMARY_SITE_URL',1,'2023-12-26 19:45:34','2023-12-26 19:45:34',NULL,'387b84cf-e0f9-41a7-976d-9a2d94c8ee4d');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structureelements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `elementId` int DEFAULT NULL,
  `root` int unsigned DEFAULT NULL,
  `lft` int unsigned NOT NULL,
  `rgt` int unsigned NOT NULL,
  `level` smallint unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tnuakjlkfvirijigverqflytifonkjeyvyxi` (`structureId`,`elementId`),
  KEY `idx_rfegnvxgjtruytdnkkhajwdngxgtucgmmrod` (`root`),
  KEY `idx_ixtsgfqutxvyefsymevagbafldnpupfrvpfv` (`lft`),
  KEY `idx_priamxrpnaeyjydqcxqznhqudctrvfbglpvv` (`rgt`),
  KEY `idx_tlyldvuejyrfeobltlbvvzjegytmqopzpuyi` (`level`),
  KEY `idx_awtlagwkytwsunehgheykecdrujiqzumgcri` (`elementId`),
  CONSTRAINT `fk_vdphctklftexmzxjlsfkjoyrmpitxlvqqpok` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
INSERT INTO `structureelements` VALUES (1,2,NULL,1,1,14,0,'2024-01-06 00:32:55','2024-01-06 00:34:14','9a54061e-3734-4c92-8d07-e19769ad6da0'),(4,2,92,1,2,3,1,'2024-01-06 00:32:55','2024-01-06 00:34:14','762d8e80-77da-45bf-b0f6-c88b9dab2886'),(5,2,94,1,4,5,1,'2024-01-06 00:32:55','2024-01-06 00:34:14','8c70c51b-99ef-4c11-bec6-94582ea2f4c6'),(6,2,102,1,6,7,1,'2024-01-06 00:32:55','2024-01-06 00:34:14','e72c0f15-4ab5-481c-82f9-60eda6a24e7e'),(7,2,111,1,8,9,1,'2024-01-06 00:32:55','2024-01-06 00:34:14','d2b14d95-0a66-46eb-804a-4e7cd7b994aa'),(8,2,113,1,10,11,1,'2024-01-06 00:32:55','2024-01-06 00:34:14','0ad1e6fc-bf40-49b4-8f0c-e4dcb92c53b6'),(9,2,117,1,12,13,1,'2024-01-06 00:32:55','2024-01-06 00:34:14','7c01640e-3a7d-4bbf-ade2-3536c5d7ee26'),(10,5,NULL,10,1,6,0,'2024-01-10 22:10:29','2024-01-10 22:10:43','dd6b1e2e-d619-45aa-9a50-37d41fe6f90e'),(11,5,201,10,2,3,1,'2024-01-10 22:10:29','2024-01-10 22:10:29','85d0c8d9-17f8-4aef-899f-3e6c61cba511'),(12,5,203,10,4,5,1,'2024-01-10 22:10:43','2024-01-10 22:10:43','5a905a02-f6cf-4960-8771-d7db31805c04');
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_zcyrejoxspjrquxufhnwycfljeukndhoeisb` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
INSERT INTO `structures` VALUES (1,NULL,'2024-01-05 21:36:57','2024-01-05 21:36:57','2024-01-05 21:37:18','d3f2d062-389c-4803-bd76-afeb10ba772b'),(2,NULL,'2024-01-06 00:32:55','2024-01-06 00:32:55','2024-01-06 16:18:00','72e66023-d26d-4d2d-8b4d-3b4d3c95eae5'),(3,NULL,'2024-01-06 15:29:25','2024-01-06 15:29:25','2024-01-06 15:29:36','d2332ff4-c74f-404c-96bf-7c03332557fb'),(4,NULL,'2024-01-06 18:04:00','2024-01-06 18:04:00','2024-01-06 18:05:32','e30e27f0-a3cd-4056-8952-7d7dcc3b2488'),(5,NULL,'2024-01-10 22:00:06','2024-01-10 22:00:06',NULL,'af4055c1-347e-4246-b763-a3d5a7188dee');
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `systemmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_wmopyecbnettwpmuyyhzszsyrtgxvfiuqyvv` (`key`,`language`),
  KEY `idx_vyezmrwxxtfluehgpusshxgtufjaflnkciug` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `taggroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_aqknsmcgitsarptpotfmnnsigrhtgqovmoks` (`name`),
  KEY `idx_clpbmnblzhaamuexxhugwrekiznwtvemowoh` (`handle`),
  KEY `idx_vednltzpmutgcqtgoycqbgfpkcwdqnpbwuby` (`dateDeleted`),
  KEY `fk_mpmnrwbbthwwxmacbyhkltuafhstvrgsnurf` (`fieldLayoutId`),
  CONSTRAINT `fk_mpmnrwbbthwwxmacbyhkltuafhstvrgsnurf` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_bmyuttwbipmbqeaubwxmsqhrlobdnhcmlzub` (`groupId`),
  CONSTRAINT `fk_auuyvsuhnvnwyfezaznpmkmruqccpychfhcn` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_etsosewjkrpqqghftkddbxlctdkpojqiluum` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint unsigned DEFAULT NULL,
  `usageCount` tinyint unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tgakhsgumecoanxoyplbluxrsdkdsctetcit` (`token`),
  KEY `idx_smooqmrnlcxkgygyldtvkwcjbinuolpupdcw` (`expiryDate`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
INSERT INTO `tokens` VALUES (1,'sXxkBFe7l9wIXokeLNQL32xcDubZ7YFm','[\"preview\\/preview\",{\"elementType\":\"craft\\\\elements\\\\Entry\",\"canonicalId\":117,\"siteId\":1,\"draftId\":null,\"revisionId\":null,\"userId\":1}]',NULL,NULL,'2024-01-06 22:03:48','2024-01-05 22:03:48','2024-01-05 22:03:48','3b889739-c947-492d-a22b-f08d705d7e8a'),(2,'AHgmxhvbPUaEhcvPm2RKRFk-jdxC2Yz3','[\"preview\\/preview\",{\"elementType\":\"craft\\\\elements\\\\Entry\",\"canonicalId\":117,\"siteId\":1,\"draftId\":null,\"revisionId\":null,\"userId\":1}]',NULL,NULL,'2024-01-06 22:31:27','2024-01-05 22:31:27','2024-01-05 22:31:27','03865e6b-470c-4e47-88bb-d32fe3a46058');
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xhiozuwvhpxmhgxfrobhjlrmaejzwhnhtdxp` (`handle`),
  KEY `idx_gcyxvimtlaxixxgbvyxpwmmqlyzpduyxyvbu` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_qssgjxohcpnfwkkrjhboivefhhnuvnmprzss` (`groupId`,`userId`),
  KEY `idx_moyfwznhovvytkoyvqmypljqsjdsgvntexlt` (`userId`),
  CONSTRAINT `fk_hgkzozaluoeqwmpfoykzdsfnfqxqqlvfbboo` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rwrhtwmqtjoqpyjdeulsstaatkenmdewcelz` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_mayomzerihbwmafdpodtbsirhnjpxqkxavra` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `groupId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_nnyerywazdrannqxlhuqpeamsalibatpoxno` (`permissionId`,`groupId`),
  KEY `idx_rsfpeyfbecaebmcygaixvywhzommgalpmlfg` (`groupId`),
  CONSTRAINT `fk_qokddzzxabimykxfwobjdszhsfgvumolhgzv` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xbtwygdnuydtcbuedmfjravdtslnylftcanj` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_xlvywubdgxxuruthweetgkezobutozfwgrtf` (`permissionId`,`userId`),
  KEY `idx_zaaomsbnvpsurfvsfptplvapgubkbwmygdfu` (`userId`),
  CONSTRAINT `fk_gxkohyhuaghbqbxcrxxhmocyhvajjvbmidyw` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_udgzuzksbxupopobvahftbutrhtzofrlektq` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpreferences` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `preferences` text,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_mujdpdxyzqafopsnqaeljflickkesvgfkski` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
INSERT INTO `userpreferences` VALUES (1,'{\"language\":\"en-US\"}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL,
  `photoId` int DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `username` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_srsuaxxoyosblaadtitowkyshgkjvqybcsap` (`active`),
  KEY `idx_xkuyreqphnrbnmjffrmfyjdaifrrgpurlwax` (`locked`),
  KEY `idx_ijuwyabdbamyfjdpxylovundecdcsyajbmmp` (`pending`),
  KEY `idx_rjczbjqkatrvcxmaiyyvalqidpffdcrcsuii` (`suspended`),
  KEY `idx_tduwcojgtmybxlfndjdnwrpkuwgjqfgxwtop` (`verificationCode`),
  KEY `idx_izlvbjqabchcrgpmelmsbpzymyigyzesmvxq` (`email`),
  KEY `idx_irsdbgogtwjhawjjxxwilbpveosiqrztltyy` (`username`),
  KEY `fk_bsekwwewihdehhkxwiwqebbzfyqghvssfdot` (`photoId`),
  CONSTRAINT `fk_bsekwwewihdehhkxwiwqebbzfyqghvssfdot` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_imfdcgzrppcvdnopbuawsxfzgqbdqluchymh` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,NULL,1,0,0,0,1,'admin',NULL,NULL,NULL,'r0906880@student.thomasmore.be','$2y$13$Qw2U0lwx091PdlG6jF6A8OBOnwfmjPKRtB0EChwvgrWjJuWG.qFF.','2024-01-11 18:40:50',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,'2023-12-26 19:45:34','2023-12-26 19:45:34','2024-01-11 18:40:50');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumefolders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `volumeId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_cfglphdngfhzemjtuvruqltmtqjmzjxvqdth` (`name`,`parentId`,`volumeId`),
  KEY `idx_inccbudypyzczdyujgbpvxukaczsvrwplstr` (`parentId`),
  KEY `idx_qhheigxdzlmtgwhbylqiodzvcxkqnlbaoxdu` (`volumeId`),
  CONSTRAINT `fk_hgsxsawidmaapdxidvxcwibycpieggecgifm` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zazndtndtbblgreihtkqrctsfmqicxgvpeod` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
INSERT INTO `volumefolders` VALUES (1,NULL,1,'drinks','','2024-01-05 23:17:14','2024-01-05 23:17:14','7479e6c7-350a-4170-99de-9b816f7f544a'),(2,NULL,2,'drinks','','2024-01-05 23:19:52','2024-01-05 23:19:52','5a0ab6e1-3f5c-41a5-b756-c1ae57a997a8'),(3,NULL,NULL,'Temporary filesystem',NULL,'2024-01-05 23:20:44','2024-01-05 23:20:44','4f205073-9592-4023-aa3c-2f695a07a36e'),(4,3,NULL,'user_1','user_1/','2024-01-05 23:20:44','2024-01-05 23:20:44','25ce8604-4067-4d2e-9fae-33a5e2d66ea2'),(5,NULL,3,'home','','2024-01-06 00:16:23','2024-01-06 00:16:23','a5735cc4-4f90-4fe3-8f88-4fc96567ea0f'),(6,NULL,4,'about Us','','2024-01-06 00:19:49','2024-01-06 00:19:49','6191834f-5c2a-4a1f-9cbc-4fd8e06cf0c7');
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fs` varchar(255) NOT NULL,
  `transformFs` varchar(255) DEFAULT NULL,
  `transformSubpath` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_tlqvnudvxckyyakwtfmsxswrizvbbtsdtabu` (`name`),
  KEY `idx_huektegmeerkqrqnzhkhxyovcfzmxfjtvjdn` (`handle`),
  KEY `idx_oblrmhyipbbkitnbqocblzzjadqlssnpwkou` (`fieldLayoutId`),
  KEY `idx_ybmpdlekziyzjoieorlznxllyhibsqfqxsdh` (`dateDeleted`),
  CONSTRAINT `fk_dvaxaauluwmpflbzapptczeogkgidgxdsbct` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
INSERT INTO `volumes` VALUES (1,7,'drinks','drinks','drinks','','','site',NULL,1,'2024-01-05 23:17:14','2024-01-05 23:17:14','2024-01-05 23:18:24','887a70ec-ae6b-4aaf-a657-0666b5ac4788'),(2,8,'drinks','drinks','drinks','','','site',NULL,2,'2024-01-05 23:19:52','2024-01-05 23:19:52',NULL,'a0cd8b19-e1b7-4968-86c8-25f1345172a0'),(3,9,'home','home','home','','','site',NULL,3,'2024-01-06 00:16:23','2024-01-06 00:16:23',NULL,'a092b4e1-f8a1-411a-8964-8779a4da42f7'),(4,10,'about Us','aboutUs','aboutUs','','','site',NULL,4,'2024-01-06 00:19:49','2024-01-06 00:19:49',NULL,'06fe3a33-66ad-4be8-9254-a3271ae424ed');
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `widgets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `colspan` tinyint DEFAULT NULL,
  `settings` text,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_wuewxxwfylfpuabwumyacmdfekexbyxcizvh` (`userId`),
  CONSTRAINT `fk_issqpnniqgjytpunyszooisxiouxizsqglpq` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
INSERT INTO `widgets` VALUES (1,1,'craft\\widgets\\RecentEntries',1,NULL,'{\"siteId\":1,\"section\":\"*\",\"limit\":10}',1,'2023-12-26 20:06:26','2023-12-26 20:06:26','2e36f43a-55be-4d58-b8e2-bb9fcfd3aa9e'),(2,1,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2023-12-26 20:06:26','2023-12-26 20:06:26','60c64b53-4c10-4fc2-829c-81de2befe900'),(3,1,'craft\\widgets\\Updates',3,NULL,'[]',1,'2023-12-26 20:06:26','2023-12-26 20:06:26','0c92066e-03cf-41b0-baeb-7f3cccf7d6d1'),(4,1,'craft\\widgets\\Feed',4,NULL,'{\"url\":\"https:\\/\\/craftcms.com\\/news.rss\",\"title\":\"Craft News\",\"limit\":5}',1,'2023-12-26 20:06:26','2023-12-26 20:06:26','c70a218f-9578-44b3-b29f-7775458affde');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-01-11 18:41:31
